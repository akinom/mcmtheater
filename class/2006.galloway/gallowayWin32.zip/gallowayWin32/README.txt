================================================================================
Copyright � 2005 Monika Mevenkamp 
http://www.qsoptsolver.com/mcmTheater

This screensaver is based on Sun Microsystems' SaverBeans Screensaver Pack
see https://screensavers.dev.java.net/ and Monika Mevenkamp's mcmTheater 
package, see http://www.qsoptsolver.com/mcmTheater. Both APIs are contained 
in saverbeans-api.jar.
================================================================================

mcmTheater screensaver README 
================================================================================

Requirements:
  * Administrator access, to copy screensaver to Windows system directory
  * Windows ME/NT/2000/XP/2003
  * Java VM 1.4.2 or higher (Get at http://java.com/)
    You can check whether you have a JRE on the list generated 
    by 'Add Remove Programs', which you can call from the 'Control Panel'.
  

To Install:
  * Copy all files in this directory (except for this README) to
    your Windows system directory (e.g. c:\windows\system32).
  * Configure the screensaver by clicking on gallowaySaver.scr and 
    choosing the 'Configure' option from the pop up menu. 

To Run:
  * Go to screensaver settings - the new screensavers will appear there.
    Use the settings option button to choose parameters.

    Screensaver settings can be found by going to the Start menu, choosing 
    the Control Panel. On the Control Panel, choose 'Appearance and Themes'. 
    Choose Display, then click the Screensaver tab, Choose galloway2006 from
    the screensaver drop down list. 
    
 
