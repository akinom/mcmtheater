================================================================================
Copyright � 2005 Monika Mevenkamp 
http://www.qsoptsolver.com/mcmTheater

This screensaver is based on Sun Microsystems' SaverBeans Screensaver Pack
see https://screensavers.dev.java.net/ and Monika Mevenkamp's mcmTheater 
package, see see http://www.qsoptsolver.com/mcmTheater. Both APIs are contained 
in saverbeans-api.jar.
================================================================================

mcmTheater screensaver README 
================================================================================

Requirements:
  * Administrator access, to copy screensaver to Windows system directory
  * Windows ME/NT/2000/XP/2003
  * Java VM 1.4.2 or higher (Get at http://java.com/)

To Install:
  * Copy all files in this directory (except for this README) to
    your Windows system directory (e.g. c:\windows\system32).

To Run:
  * Go to screensaver settings - the new screensavers will appear there.
  