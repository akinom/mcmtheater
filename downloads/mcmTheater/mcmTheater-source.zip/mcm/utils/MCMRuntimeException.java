package mcm.utils;

/**
 * MCMRuntimeExceptions are thrown by classes in the mcm packages. 
 * Methods in mcm packages test their parameters and in some cases more 
 * general state invariants and throw MCMRuntimeExceptions, 
 * if results are unsatisfactory.
 * 
 * @author Monika Mevenkamp
 */
public class MCMRuntimeException extends RuntimeException {

    /**
	 * used in serialization
	 */
	private static final long serialVersionUID = 3833818571225666249L;

	/** 
	 * Constructs a MCMRuntimeException with the specified detail message.
	 * This constructor has the same effect as MCMRuntimeException(message, null). 
	 * 
	 * @param   message   the detail message. 
	 */
	public MCMRuntimeException(String message) {
		this(message, null);
	}

	/**
     * Constructs a new MCMRuntimeException with the specified detail message and
     * cause.  
     *
     * @param  message the detail message 
     * @param  cause the cause 
     * 
     * @see  RuntimeException#RuntimeException(java.lang.String, java.lang.Throwable)
     */
	public MCMRuntimeException(String message, Throwable cause) {
		super(message, cause);
		Assert.check (message != null);
		Trace.global.traceMsg(Thread.currentThread().getName(), message);
	}

	/**
	 * Returns a short description of this throwable. 
	 * 
	 * Returns the unqualified class name of this exception, followed by ':',  
	 * followed by the results of {@link Throwable#getMessage()} method for this exception. 
	 */
	public String toString() {
		return Utils.shortClassName(this) + ": " + getMessage();
	}
}
