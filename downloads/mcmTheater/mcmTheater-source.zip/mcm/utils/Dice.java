
package mcm.utils;

import java.awt.Color;

import mcm.graphics.Drawable;
import mcm.graphics.Point;

/**  
 * Dice contains convenience methods to generate random numbers/colors/points/... 
 * All methods are based on the Math.random() method from the java.lang package.
 * 
 * @author Monika Mevenkamp
 */
public class Dice {

	static void main(String qrgv[]) {
		{
			int hits[] = new int[256];

			for (int i = 0; i < 100000; i++) {
				double d = throwDouble(100, 255);
				int n = (int) (d);
				//System.out.println("" + i + ": " + d + " -> " + n);
				hits[n]++;

			}
			for (int i = 0; i < 256; i++) {
				System.out.println("" + i + ": " + hits[i]);
			}
		}

		{
			int hits[] = new int[10];

			for (int i = 0; i < 100000; i++) {
				int n = throwInt(9);
				//System.out.println("" + i + ": " + d + " -> " + n);
				hits[n]++;

			}
			for (int i = 0; i < 10; i++) {
				System.out.println("" + i + ": " + hits[i]);
			}
		}
	}

	/**
	 * Chooses a random opaque RGB Color. 
	 * 
	 * @return the chosen Color
	 */
	public static Color throwColor() {
		return new Color(Dice.throwInt(256), Dice.throwInt(255), Dice
				.throwInt(256));
	}

	/**
	 * Chooses a random opaque RGB Color other than <code>notThis</code> 
	 * 
	 * @param notThis the 'forbidden' Color
	 * @return return a ramly chosen Color other than notThis
	 */
	public static Color throwColor(Color notThis) {
		Color c = throwColor();
		if (c.equals(notThis)) {
			return throwColor(notThis);
		}
		return c;
	}
	
	/**
	 * Chooses a random double value between zero and <code>max</code>.
	 * Note that <code>max</code> is never  chosen.
	 * 
	 * @param max upper interval bound 
	 * @return a random number from
	 *         <UL>
	 *         <LI>the interval  [0 - max-1] if max &gt; 0</LI>
	 *         <LI>ths interval  [0 - max +1] if max &lt; 0</LI>
	 *         </UL>
	 *         return 0 if max = 0
	 */
	public static double throwDouble(double max) {
		return Math.random() * max;
	}

	/**
 	 * Chooses a random double value  from the interval 
 	 * [min, max)  if <code>min</code> &lt; <code>max</code>. 
 	 * Note that in this case <code>max</code> is never  chosen.
 	 * <BR>
 	 * If   <code>min</code> = <code>max</code> return 
 	 * <code>min</code>.
 	 * <BR>
	 * Throws a {@link MCMRuntimeException} if <code>min</code> &gt; <code>max</code>.  
 	 * 
	 * @param min  lower bound of number range 
	 * @param max  upper bound of number range
	 * @return a random number from the interval [min, max)
	 */
	public static double throwDouble(double min, double max) {
		if (min > max) 
			throw new MCMRuntimeException("Minimum value (" + min + ") " + 
					"greater than maximum value (" + max + ")."); 
		return min + throwDouble(max - min);
	}

	/**
	 * Chooses a random int value between zero and <code>max</code>.
	 * Note that <code>max</code> is never  chosen.
	 * 
	 * @param max upper  bound
	 * @return a random number 
	 *         <UL>
	 *         <LI>the set 0, 1, 2, ..., max-1 if max &gt; 0</LI>
	 *         <LI>ths set 0, -1, -2, ..., max +1 if max &lt; 0</LI>
	 *         </UL>
	 *         return 0 if max = 0
	 */
	public static int throwInt(int max) {
		return (int) (Math.random() * max);
	}

	/**
 	 * Chooses a random integer value  from the interval 
 	 * [min, max)  if <code>min</code> &lt; <code>max</code>. 
 	 * Note that in this case <code>max</code> is never  chosen.
 	 * <BR>
 	 * If   <code>min</code> = <code>max</code> return 
 	 * <code>min</code>.
 	 * <BR>
 	 * Throws a {@link MCMRuntimeException} if <code>min</code> &gt; <code>max</code>.  
 	 *  
	 * @param min  lower bound of number range 
	 * @param max  upper bound of number range
	 * @return a random number from the interval [min, max)
	 */
	public static int throwInt(int min, int max) {
		if (min > max) 
			throw new MCMRuntimeException("Minimum value (" + min + ") " + 
					"greater than maximum value (" + max + ")."); 

		return min + (int) (throwDouble(max - min) + 0.5);
	}

	/**
	 * Chooses a random Point on the given Drawable. 
	 * The returned point's x,y coordinates are greater equal zero and
	 * smaller than s.getWidth() and s.getHeight() respectively.
	 * 
	 * @param s the Drawable for which a random Point is chosen
	 * @return randomly chosen Point
	 * 
	 * @see Drawable#getHeight()
	 * @see Drawable#getWidth()
	 */
	public static Point throwPoint(Drawable s) {
		Point ptr = new Point();  
		if (s != null) {
		  ptr.setLocation((int) Dice.throwDouble(s.getWidth()), 
		  		(int) Dice.throwDouble(s.getHeight()));
		} 
		return ptr;
	}

	private Dice() {
	}

}
