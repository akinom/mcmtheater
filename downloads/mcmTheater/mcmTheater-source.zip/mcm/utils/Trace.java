package mcm.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

/**
 * Trace offers various printing methods that can be (de-)activated at runtime.
 * 
 * Some methods prefix output lines with information about the currently executing
 * thread and the current time, given in milliseconds.
 * 
 * @author Monika Mevenkamp
 */
public class Trace {

	/** 
	 * Globally available Trace instance that is
	 * initialized to use  {@link System#err} as its output stream. 
	 * Its trace level is set to zero, its traceThreadNames  and 
	 * traceTime modes are set to <code>false</code>. 
	 * Thus unless its trace level is changed calls to trace and traceln will 
	 * not produce any output. 
	 */
	public static Trace global = new Trace(); 
	
	/**
	 * Prints the given exception's stack trace to {@link Trace#global} as well as System.err.
	 * If global's output stream is {@link System#err} it prints the exception only once. 
	 * 
	 * @param e exception whose stack trace is printed
	 * 
	 * @see Trace#global
	 */
	public static void report(Exception e) {
		if (e == null)
			throw new NullPointerException("Null Exception parameter");
		if (Trace.global.getStream() != System.err) {
			Trace.global.getStream().print(Trace.global.prefix()); 
			e.printStackTrace(Trace.global.getStream());
			Trace.global.getStream().println();
		}
		System.err.print(Trace.global.prefix()); 
		e.printStackTrace(System.err);
		System.err.println(); 
	}

	/**
	 * Prints the given message to {@link Trace#global} as well as System.err.
	 * If global's output stream is {@link System#err} it prints the message only once. 
	 * 
	 * @param message the message
	 * 
	 * @see Trace#global
	 */
	public static void report(String message) {
		Trace.global.println(message);
		if (Trace.global.getStream() != System.err) 
			System.err.println(message);
	}
	
	private PrintStream stream;
	
	private int traceLevel;

	private boolean traceThreadNames;

	private boolean traceTime;

   /**
	 * Allocates a new Trace object. This constructor has the same effect as
	 * Trace({@link System#err})
	 */
	public Trace() {
		this(System.err);
	}

	/**
	 * Allocates a new Trace object. 
	 * The new Trace object uses the given stream as output stream and has 
	 * a trace level of zero.
	 * 
	 * @param out the PrintStreem used for output 
	 */
	public Trace(PrintStream out) {
		stream = out;
		traceLevel = 0;
	}

	/** 
	 * Allocates a new Trace object. 
	 * The new Trace object has a trace level of zero. 
	 * The constructor creates a PrintStream for the given file name and assigns 
	 * it as output stream.
	 * If it can't create the PrintStream it prints an error message and 
	 * assigns {@link System#err} as output stream.
	 */
	public Trace(String fname) {
		stream = System.err;
		try {
			stream = new PrintStream(new FileOutputStream(new File(fname)));
		} catch (FileNotFoundException e) {
			System.err.println("Could not open " + fname + "; using System.err.");
			e.printStackTrace();
		}
		traceLevel = 0;
	}

	/**
	 * Assume the same tracing options as the given parameter.
	 * @param tracer Trace instance whose options are copied
	 */
	public void setOptions(Trace tracer) {
		traceLevel = tracer.traceLevel;
		traceThreadNames = tracer.traceThreadNames;
		traceTime = tracer.traceTime;		
	}
	
	/** 
	 * The same as doTraceLevel(0);
	 * 
	 * @return <code>true</code> if the trace level is greater 0;
	 * <code>false</code> otherwise
	 */
	public boolean doTrace() {
		return traceLevel > 0;
	}

	/** 
	 * Determines whether messages should be printed given a trace level of
	 * <code>lvl</code>.
	 * 
	 * @return <code>true</code> if this Trace's trace level is greater <code>lvl</code>; 
	 * <code>false</code> otherwise
	 */
	public boolean doTraceLevel(int lvl) {
		return ((traceLevel) >= lvl);
	}

	/**
	 * Returns this Trace objects traceThreadNames mode. 
	 * 
	 * @return <code>true</code> if output is prefixed with the name of the current thread; 
	 * <code>false</code> otherwise.
	 */
	public boolean doTraceThreadNames() {
		return traceThreadNames;
	}

	/**
	 * Returns this Trace object's traceTime mode. 
	 * 
	 * @return the value of this Trace object'ss traceTime mode
	 */
	public boolean doTraceTime() {
		return traceTime;
	}
	
	/** 
	 * Returns the print stream used for output messages.
	 */
	public PrintStream getStream() {
		return stream;
	}

	/** 
	 * Returns this Trace's trace level value. 
	 * The  trace level value governs which messages are actually send to 
	 * the output stream by the trace and traceln methods. The higher the level 
	 * the more traces are printed.
	 * 
	 * @return the global trace level value 
	 */
	public int getTraceLevel() {
		return traceLevel;
	}

	/**
	 * Prints and flushes the given string to its output stream. 
	 * 
	 * @param s the message to be printed
	 */
	public void print(String s) {
		stream.print(s);
		stream.flush();
	}

	/**
	 * The same as calling println(""); 
	 */
	public void println() {
		stream.println();
		stream.flush();
	}

	private String prefix() 
	{
		String pre = ""; 
		if (traceTime) {
				pre += "(" + (System.currentTimeMillis() % 1000000 )+ ") ";
		}
		if (traceThreadNames) {
			pre += (Thread.currentThread().getName() + ": ");
		}
		return pre;
	}
	
	/**
	 * Prints and flushes the given string followed by a newline character to its output stream.
	 * 
	 * If this trace object's traceTime is set to <code>true</code> 
	 * it prefixes the line with the current time measured in milliseconds.
	 * It this Trace object's traceThreadNames mode is <code>true</code> 
	 * it prefixes  
	 * output with the name of the currently exceuting thread.
	 * 
	 * @param s the message to be printed
	 */
	public void println(String s) {
		String line = prefix(); 
		line += s + "\n"; 
		stream.print(line);
		stream.flush();
	}
 
	/** 
	 * The same as calling println(o + ":: " + msg);
	 * 
	 * @param o     any non null object 
	 * @param msg   any non null String message
	 */
	public void printMsg(Object o, String msg) {
		println(((o == null) ? "null" : o) + ":: " + msg);
	}
	
	/** 
	 * Sets this Trace's trace level value to the given number. 
	 * The  trace level value governs which messages are actually send to 
	 * the output stream by trace and traceln methods as well as the result 
	 * of doTrace and doTraceLevel method calls.
	 * 
	 * @param doTrace the new trace level
	 */
	public void setTraceLevel(int doTrace) {
		this.traceLevel = doTrace;
	}

	/**
	 * Sets this Trace's <code>traceThreadNames</code> mode. 
	 * traceln and println methods prefix output with the name of the currently executing thread 
	 * while the  <code>traceThreadNames</code> mode is true. 
	 * 
	 * @param traceThreadNames the new traceThreadNames mode.
	 */
	public void setTraceThreadNames(boolean traceThreadNames) {
		this.traceThreadNames = traceThreadNames;
	}

	/**
	 * Sets this Trace's <code>traceTime</code> mode. 
	 * traceln and println methods prefix output with the current time 
	 * while the <code>traceTime</code> mode is true.
	 * 
	 * @param traceTime the new traceTime mode.
	 */
	public void setTraceTime(boolean traceTime) {
		this.traceTime = traceTime;
	}
	
	/**
	 * Prints and flushes the given string to the output stream if its trace
	 * level is greater zero. 
	 * 
	 * @param s
	 *            the string to be printed if trace level &gt; 0
	 */
	public void trace(String s) {
		if (s == null)
			throw new NullPointerException("Null String parameter");
		if (doTrace()) {
			stream.print(s);
			stream.flush();
		}
	}	

	/** 
	 * Same as traceln(""); 
	 */
	public void traceln() {
		traceln(""); 
	}
	
	/** 
	 * Prints to its output stream if its trace level is greater zero. 
	 * If it does print it adds a new line character after the given string.
	 *  
	 * @param s the string to be printed if trace level &gt; 0
	 */
	public void traceln(String s) {
		if (s == null)
			throw new NullPointerException("Null String parameter");
		if (doTrace()) {
			stream.print(s + "\n");
			stream.flush();
		}
	}
		
	/**
	 * Calls printMsg(o, msg) if its trace
	 * level is greater zero.
	 * 
	 * @param o
	 *            any object 
	 * @param msg
	 *            any String 
	 */
	public void traceMsg(Object o, String msg) {
		if (doTrace()) {
			printMsg(o, msg);
		}
	}
	
	private static void main(String[] argv) {
		Trace t = new Trace(System.out); 
		t.printMsg(null, "print"); 
		t.printMsg(null, null); 
		
		t.setTraceThreadNames(true); 
		t.setTraceTime(true); 
		t.printMsg(null, "print"); 
		t.printMsg(null, null); 
		
		
		t.println(null);
		
	}


}
