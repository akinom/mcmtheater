/*
 * Created on Jan 16, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package mcm.utils;

import java.awt.Color;

/**
 * @author Monika Mevenkamp
 */
public class Utils {
	
	/** 
	 * Returns the given object's class name stripped of its package prefix.
	 * Returns the string "null" if the given object is <code>null</code>.
	 * 
	 * @param object any object
	 * @return the object's class name stripped of package information.
	 */
	public static String shortClassName(Object object) {
	 	if (object == null) {
	 		return "null"; 
	 	}
		String n = object.getClass().getName(); 
		int i = n.lastIndexOf('.');
		if (i != -1) {
			n = n.substring(i+1); 
		}
		return n;
	}
	
	private static final int alphaMask = (1 << 24) - 1; 
	
	public static boolean equal(Color c, Color b) {
		if (c == b) return true; 
		if (c == null || b == null) return false;
		int crgb = c.getRGB();
		crgb = crgb & alphaMask; 
		int brgb = b.getRGB(); 
		brgb = brgb & alphaMask; 
		return crgb == brgb; 
	}
}
