package mcm.utils;


/** 
 * Provides a few static functions for assertion checking that can not be turned off. 
 *  
 * @see java.lang.AssertionError
 */
public class Assert {
	
	/**
	 * Throws an AssertionError if b is <code>false</code>.
	 * @param b assertion value
	 */
	public static void check(boolean b) 
	{
		check(b, "assertion failed");
	}
	
	/** 
	 * Throws an AssertionError with the given msg if b is <code>false</code>.
	 * @param b assertion value
	 * @param msg detail message of generated Error 
	 */
	public static void check(boolean b, String msg) 
	{
		if (!b) {
			throw new AssertionError(msg); 
		}
	}
	
	/** 
	 * Throws an AssertionError with the given msg if msg  is not <code>null</code>.
	 * @param msg null or detail message of generated Error 
	 */
	public static void check(String msg) 
	{
		if (msg != null) {
			throw new AssertionError(msg); 
		}
	}
}
