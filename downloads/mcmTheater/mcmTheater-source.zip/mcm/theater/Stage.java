package mcm.theater;

import java.awt.*;
import java.awt.geom.AffineTransform;

import mcm.graphics.Drawable;
import mcm.graphics.Point;
import mcm.utils.Assert;
import mcm.utils.Trace;

/**
 * A stage manages the painting of its actors onto its component.
 * <p>
 * Each stage provides a coordinate system with the origin (0,0) at its lower
 * left corner. The coordinates of its upper right corner are (width-1 ,
 * height-1), where width and height are the stage's current width and height.
 * </p>
 * <p>
 * A stage provides the place for actors to 'act' on, see
 * {@link Actor#start(Stage)}. Actors move about the stage possibly leaving a
 * colored movement trail behind. Actors with visible shapes display their
 * shapes at their current locations. The stage takes care of scheduling the
 * actors so that each active actor executes one timed step within one clock
 * tick on the stage's clock. Actors are responsible for informing the stage they
 * are acting on when they finish a timed step, see
 * {@link mcm.theater.Actor#move(double)}and {@link mcm.theater.Actor#sleep}.
 * </p>
 * <p> 
 * A stage has two layers. Actors paint  movement trails onto the background layer. 
 * They may also use their stamp method to paint their current shapes at their 
 * current positions onto the stage's background.  A stage's clear method overwrites 
 * the background layer with the stage's color. 
 * When a stage updates itself it copies its 
 * background layer to its double buffer before it adds the shapes of its visible actors. 
 * </p>
 * 
 * @author Monika Mevenkamp
 */
public class Stage extends Drawable {

	/**
	 * default color used in constructor
	 */
	static final Color DEFAULT_COLOR = Color.BLACK;

	/**
	 * Ease-of-use constant for {@link #setMode(int)}.
	 */
	public static final int FENCE = 3;

	/**
	 * Ease-of-use constant for {@link #setMode(int)}.
	 */
	public static final int LEAVE = 2;

	/**
	 * Ease-of-use constant for {@link #setMode(int)}.
	 */
	static final int WRAP = 1;

	/**
	 * default mapMode used in constructor
	 */
	static final int DEFAULT_MODE = FENCE;

	private ScheduledThread[] actors = null;

	/**
	 * reference to runtime arguments
	 */
	private Arguments args;

	// private final Component component;

	//final Director director;

	/**
	 * LEAVE or FENCE
	 */
	private int mapMode;

	/**
	 * The scheduler is responsible for scheduling this stage's actors.
	 */
	final Scheduler scheduler;

	/**
	 * The minimum trace level at which Stage methods print messages to its {@link Stage#tracer}. 
	 */
	protected int traceLevel = 5;

	/**
	 * Stage methods use tracer to print execution traces.
	 * 
	 * By default tracer refers to {@link Trace#global}.
	 */
	protected Trace tracer;

	private Drawable backgroundImage;

	/**
	 * Constructs a new Stage object. The new stage uses the given component as
	 * its drawing surface. The given arguments are the stage's runtime
	 * arguments, which the stage applies to itself and the default actor, see 
	 * {@link Actor#getDefault()}. Its mode is set to FENCE. Its tracer is
	 * set to refer to {@link Trace#global}.
	 * 
	 * @param c
	 *            the stage's drawing surface
	 * @param as
	 *            runtimr arguments that are applied to the stage
	 */
	public Stage(Component c, Arguments as) {
		super(c);
		tracer = Trace.global;
		args = as;
		scheduler = new Scheduler();
		mapMode = DEFAULT_MODE; // FENCE or LEAVE 
		backgroundImage = new Drawable(c);
		setColor(DEFAULT_COLOR); 
		if (args != null) {
			args.apply(this);
		}
		if (tracer.doTraceLevel(traceLevel))
			tracer.traceMsg(this, "new");
	}

	/**
	 * Clears this stage by redrawing it in its background color.
	 */
	public synchronized void clear() {
		resize();
		super.clear();
	}

	/**
	 * Returns an array with all actors on stage.
	 * 
	 * Beware that the array contents may be misleading since concurrently
	 * executing actors may start or terminate other actors within the same
	 * stage clock tick but after this method assembles the array.
	 * 
	 * @return actor array
	 */
	public Actor[] getActors() {
		ScheduledThread[] threads = scheduler
				.getThreads(new ScheduledThread[0]);
		Actor[] as = new Actor[threads.length];
		for (int i = 0, j = 0; i < threads.length; i++) {
			tracer.printMsg(this, "thread " + i + ": " + threads[i]);
			if (threads[i] != null)
				as[j++] = threads[i].getActor();
		}
		return (Actor[]) as;
	}

	/**
	 * Returns a reference to runtime arguments. The runtime arguments wrap the
	 * commandline or applet arguments which were passed at the start of
	 * execution.
	 * 
	 * @return this stage's arguments
	 */
	public Arguments getArgs() {
		return args;
	}

	/**
	 * Returns the center point of this stage.
	 * 
	 * @return the center point
	 */
	public Point getCenter() {
		Point ctr = new Point();
		ctr.setLocation(0.5 * getWidth(), 0.5 * getHeight());
		return ctr;
	}

	/**
	 * Returns the stage's background color.
	 * 
	 * @return the background color
	 */
	public synchronized Color getColor() {
		return backgroundImage.getColor();
	}

	//	/**
	//	 * Returns the component that this stage uses as drawing surface. 
	//	 * 
	//	 * @return this stage's component
	//	 */
	//	public Component getComponent() {
	//		return component;
	//	}

	/** 
	 * Returns the graphics context for the background  layer.
	 * Reinitializes whenever the associated component resizes.
	 * 
	 * @return null or a valid graphics context
	 */
	synchronized public Graphics2D getGraphics() {
		resize();
		return backgroundImage.getGraphics();
	}

	/**
	 * Returns the current height of this stage.
	 * 
	 * @return the height
	 */
	public int getHeight() {
		resize();
		return super.getHeight();
	}

	public boolean resize() {
		if (super.resize()) {
			if (backgroundImage != null) {
				backgroundImage.resize();
			}
			return true;
		}
		return false;
	}

	/**
	 * Returns the current width of this stage.
	 * 
	 * @return the width
	 */
	public int getWidth() {
		resize();
		return super.getWidth();
	}

	/**
	 * Returns the current stage mode. By default a stage's mode is FENCE.
	 * 
	 * @return the current stage mode
	 */
	public int getMode() {
		return mapMode;
	}

	/**
	 * Returns the number of actors currently on stage.
	 * 
	 * Beware that the actor count may be misleading since concurrently
	 * executing actors may start or terminate other actors within the same
	 * stage clock tick but after this method calculates the number of actors on
	 * stage.
	 * 
	 * @return number of actors on stage
	 */
	public int getNumberOfActors() {
		if (scheduler != null) 
			return scheduler.getThreadCount();
		else 
			return 0;
	}

	Scheduler getScheduler() {
		return scheduler;
	}

	/**
	 * Returns the current time on this stage's clock.
	 * 
	 * The stage's time progresses from 0 forward. Whenever all active actors
	 * have performed one execution step the time is increased by one clock
	 * tick. The clock is reset to zero when all actors have finished.
	 * 
	 * @return the current time on this stage's clock counted in clock ticks.
	 */
	public int getTime() {
		return getScheduler().getRound();
	}

	/**
	 * Determines whether the given point lies within this stage's boundaries. A
	 * poinit insisde the stage must have an x coordiniate greater or equal zero
	 * and smaller than the stage's current width. Its y coordinate must be
	 * greater equal zero and smaller than the stage's current height.
	 * 
	 * @return <code>true</code> if <code>pt</code> lies within this stage's
	 *         boundaries; <code>false</code> otherwise
	 */
	public boolean isInside(Point pt) {
		resize();
		return backgroundImage.isInside(pt.x, pt.y);
	}

	void listActors(Trace tracer) {
		scheduler.listAll(tracer, "Actors n Stage");
	}

	/**
	 * Stes the stage's background color. This stage is cleared as a side effect
	 * to this method call.
	 * 
	 * @param c
	 *            the new background color
	 */
	public synchronized void setColor(Color c) {
		super.setColor(c);
		backgroundImage.setColor(c);
		backgroundImage.clear(); 
	}

	/**
	 * A stage's mode determines what happens when an actor moves beyond it's
	 * boundaries. When an actor's position moves outside the rectangle defined
	 * by the stage's width and height it either moves off or is stopped at the
	 * stage's sides.
	 * <p>
	 * If the mode is set to LEAVE actors move off the stage into the 'unseen'.
	 * This mode can be useful if actors eventually return to the stage's area
	 * or if they influence the visible movements of other actors.
	 * </p>
	 * <p>
	 * If the stage mode is set to FENCE actors are shown as if they are stopped
	 * by an imaginary fence build around the sides of the stage. Thus actors
	 * appear to be located at the stage's sides although their positions lie
	 * outside the stage's boundaries.
	 * </p>
	 * 
	 * @param mode
	 *            the new mode, either LEAVE or FENCE
	 */
	public void setMode(int mode) {
		Assert.check((mode == LEAVE) || (mode == FENCE));
		mapMode = mode;
	}

	/**
	 * Returns a string representation for this stage. Returns the string
	 * "Stage(#actors=&lt;id&gt;)", where &lt;id&gt; is the value returned ny
	 * {@link Stage#getNumberOfActors()}.
	 * 
	 * @return a short string representation
	 */
	public String toString() {
		return "Stage(#actors=" + getNumberOfActors() + ")";
	}

	synchronized void updateGraphics() {
		// renew doubleBuffer with current situation
		// assume that all Actor threads are halted right now

		if (getGraphics() == null) return;  // stage not ready 
		resize();

		Actor a;
		int nActors = scheduler.getThreadCount();
		if (actors == null || actors.length < nActors + 1
				|| actors.length > 3 * nActors) {
			actors = new ScheduledThread[nActors + 20];
		}
		
		if (tracer.doTraceLevel(traceLevel))
			tracer.printMsg(this, "> updateGraphics #actors: " + nActors);

		if (tracer.doTraceLevel(traceLevel + 10)) {
			scheduler.listAll(tracer, "updateGraphics: Actors ");
			//				tracer.printMsg(this, "flush tg=" + tg.hashCode()
			//						+ " dg=" + dg.hashCode());
		}
		// copy tracerImage to double buffer
		draw(backgroundImage, 0, 0);

		Graphics2D dg = super.getGraphics();
		scheduler.getThreads(actors);
		int i;
		for (i = 0; actors[i] != null; i++) {
			a = actors[i].getActor();
			if (a.isActing() && a.isVisible()) {
				a.draw(dg);
			}
		}
		if (tracer.doTraceLevel(traceLevel))
			tracer.printMsg(this, "< updateGraphics");
	}

	/** 
	 * draw the given shape on the tracer graphics layer 
	 * 
	 * @param shape the shape to draw 
	 * @param pos the position at which to draw
	 */
	AffineTransform stampTrans = new AffineTransform();


	/** 
	 * Paints the given shape relative to the given body's position and rotation. 
	 * @param shape the shape that is painted 
	 * @param a the actor that defined the shape's position and rotation 
	 */
//	void paint(Shape shape, Body a) {
//		a.draw(getGraphics()); 
//	}			

}