package mcm.theater;

import java.io.PrintStream;
import java.io.PrintWriter;

import mcm.utils.MCMRuntimeException;
import mcm.utils.Trace;

/**
 * RuntimeException indicating that an Actor must terminate.
 * 
 * @author Monika Mevenkamp
 */
public class ActorDeath extends MCMRuntimeException {

	/**
	 * used in serialization
	 */
	private static final long serialVersionUID = -178532243700138736L;

	/**
	 * Constructs a new ActorDeath object with the given message. 
	 * 
	 * @param message
	 *            the exception''s message
	 * 
	 * @see Trace#global
	 */
	public ActorDeath(String message) {
		super("DIE " + message);
		if (Trace.global.doTraceLevel(3)) {
			Trace.report(this);
		}
	}

	/**
	 * Prints the stack trace to the given PrintStream. Prefixes the output with
	 * the name of the current thread.
	 */
	public void printStackTrace(PrintStream s) {
		s.print("Thread=" + Thread.currentThread().getName() + ":: ");
		super.printStackTrace(s);
		s.flush();
	}

	/**
	 * Prints the stack trace to the given PrintWriter. Prefixes the output with
	 * the name of the current thread.
	 */
	public void printStackTrace(PrintWriter s) {
		s.print("Thread=" + Thread.currentThread().getName() + ":: ");
		super.printStackTrace(s);
		s.flush();
	}
}