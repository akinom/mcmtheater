package mcm.theater;

import java.awt.Color;
import java.awt.Component;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.StringTokenizer;

import javax.swing.JApplet;

import mcm.graphics.FillableShape;
import mcm.graphics.ImageShape;
import mcm.utils.Utils;
import mcm.utils.MCMRuntimeException;
import mcm.utils.Trace;

/**
 * Arguments bundle runtime arguments relevant to Actors and Stage.
 * 
 * An Arguments instance contains a mapping of Strings to Values, 
 * that is of argumentnames to argument values. 
 * Argument names are strings that are case
 * insensitive. For example "VIS" and "vis" are considered to be the same.
 * Values are typed. There are Boolean, Integer, Double, Color, and String
 * arguments.
 * 
 * Upon instanciation Arguments initiate their argument map to the following default 
 * name, value mapping:
 * <UL>
 *  	<LI> ACTORVISIBLE=&gt; true </li> 
 *		<LI> ACTORDEBUG =&gt; false </LI> 
 *      <LI> SHAPEFILLED =&gt; true </LI> 
 *      <LI> TRAILWIDTH =&gt; 1 </LI> 
 *      <LI> STEPSIZE =&gt; 5 </LI> 
 *      <LI> WINCOLOR =&gt;  Color.BLACK; </LI> 
 *      <LI> LEAVE =&gt; false </LI> 
 *      
 *      <LI> HEIGHT =&gt; 500 </li> 
 *      <LI> WIDTH =&gt; 809 (the golden ratio) </li> 
 *      <LI> DUMPNAME  =&gt; null </LI> 
 *      <LI> DUMPDELAY =&gt; 100 </LI> 
 *      <LI> FRAMEDELAY =&gt; 45 </LI> 
 *      
 *      <LI> TRACEINC =&gt; 0 </LI> 
 *      <LI> TRACETHREADS =&gt; false </LI> 
 *      <LI> TRACETIME =&gt; false </LI>  
 * </UL> 

 * @author Monika Mevenkamp
 */
public class Arguments {
	
	private static final int defaultHeight = 500;

	private static final int defaultWidth = 809; // the golden ratio



	/**
	 * Ease-of-use constant for getting and setting initial actor's class name
	 * 
	 * @see Actor
	 * @see Play
	 */
	public final static String ACTORCLASS = "ACTOR";

	/**
	 * Ease-of-use constant to determine whether execution is inside APPLET
	 * 
	 * @see Actor
	 * @see Play
	 */
	public final static String APPLET = "APPLET";

	/**
	 * Ease-of-use constant for getting and setting default Actor properties
	 * 
	 * @see Actor#setDebugMode(boolean)
	 */
	public final static String ACTORDEBUG = "DEBUG";

	/**
	 * Ease-of-use constant for getting and setting default Actor properties
	 * 
	 * @see Actor#setVisible(boolean)
	 */
	public final static String ACTORVISIBLE = "VIS";

	/**
	 * Ease-of-use constant for getting and setting the delay in stage clock
	 * ticks between dumping images.
	 * 
	 * The setting is effective only iff DUMPNAME is non empty.
	 * 
	 * @see mcm.theater.actor.StageDump
	 */
	public final static String DUMPDELAY = "DDELAY";

	/**
	 * Ease-of-use constant for getting and setting the name of the image dump
	 * file.
	 * 
	 * A StageDump actor is started if DUMPNAME is set to filename.
	 * 
	 * @see mcm.theater.actor.StageDump
	 */
	public final static String DUMPNAME = "DUMP";

	final static String FRAMEDELAY = "DELAY";

	/**
	 * Ease-of-use constant for getting and setting window height
	 */
	public final static String HEIGHT = "HEIGHT";

	/**
	 * Ease-of-use constant for getting and setting Stage mode
	 * 
	 * @see Stage#setMode(int)
	 */
	public final static String LEAVE = "LEAVE";

	/**
	 * Ease-of-use constant for getting and setting default Actor properties
	 */
	public final static String SHAPECOLOR = "SC";

	/**
	 * Ease-of-use constant for getting and setting default Actor properties
	 * 
	 * @see FillableShape#setFilled(boolean)
	 */
	public final static String SHAPEFILLED = "SF";

	private static String std[][];

	/**
	 * Ease-of-use constant for getting and setting default Actor properties
	 * 
	 * @see Actor#setStepSize(double)
	 */
	public final static String STEPSIZE = "STP";

	/**
	 * Ease-of-use constant to control the destination of traces
	 * 
	 * @see Trace
	 */
	public final static String TRACEFILE = "TRACEFILE";

	/**
	 * Ease-of-use constant to control the amount of tracing done
	 * 
	 * @see Trace
	 */
	public final static String TRACEINC = "TRACE";

	/**
	 * Ease-of-use constant to cntrol whether thread names are included in trace
	 * 
	 * @see Trace
	 */
	public final static String TRACETHREADS = "TRACENAMES";

	/**
	 * Ease-of-use constant to cntrol whether stage's clock time is included in
	 * trace
	 * 
	 * @see Trace
	 */
	public final static String TRACETIME = "TRACETIME";

	/**
	 * Ease-of-use constant for getting and setting default Actor properties
	 * 
	 * @see Actor#setTrailColor(Color)
	 */
	public final static String TRAILCOLOR = "TC";

	/**
	 * Ease-of-use constant for getting and setting default Actor
	 * propertiesperties
	 * 
	 * @see Actor#setTrailVisible(boolean)
	 */
	public final static String TRAILNOTSHOWN = "TNS";

	/**
	 * Ease-of-use constant for getting and setting default Actor properties
	 * 
	 * @see Actor#setTrailWidth(int)
	 */
	public final static String TRAILWIDTH = "TW";

	/**
	 * Ease-of-use constant for getting and setting window width
	 */
	public final static String WIDTH = "WIDTH";

	/**
	 * Ease-of-use constant for getting and setting Stage color
	 * 
	 * @see Stage#setColor(Color)
	 */
	public final static String WINCOLOR = "BG";

	static String[] makeArray(String cmdLine) {
		StringTokenizer st = new StringTokenizer(cmdLine);
		String args[] = new String[st.countTokens()];
		int i = 0;
		while (st.hasMoreElements()) {
			args[i++] = st.nextToken();
		}
		return args;
	}

	static String makeLine(String args[]) {
		String line = "";
		for (int i = 0; i < args.length; i++) {
			line += args[i] + " ";
		}
		Trace.global.println("arguments: " + line);
		return line;
	}

	/**
	 * @param className
	 * @return
	 */
	static Object newInst(String className) {
		Object o = null;
		try {
			if (className == null)
				throw new NullPointerException();
			ClassLoader c = Play.class.getClassLoader();
			Trace.global.traceln("ClassLoader " + c);
			Class cls = c.loadClass(className);
			Trace.global.traceln("Class " + cls);
			Constructor constr = cls.getConstructor(null);
			Trace.global.traceln("constr " + constr.toString());
			o = constr.newInstance(null);
		} catch (Exception e) {
			throw new MCMRuntimeException("Could not instantiate " + className,
					e);
		}
		return o;
	}

	Hashtable arguments;

	private boolean frameMode;

	private Trace tracer;

	Trace getTrace() {
		return tracer;
	}

	/**
	 * Reset argument name, value map to defaults.
	 */
	public void reset() {
		tracer = Trace.global;
		arguments = new Hashtable();

		setStringVal(ACTORVISIBLE, new Boolean(Actor.DEFAULT_VISIBLE)
				.toString());
		setStringVal(ACTORDEBUG, new Boolean(Actor.DEFAULT_DEBUG).toString());
		setStringVal(SHAPEFILLED, new Boolean(Actor.DEFAULT_FILLED).toString());
		setStringVal(TRAILWIDTH, new Integer(Actor.DEFAULT_TRAIL_WIDTH)
				.toString());
		setStringVal(STEPSIZE, new Double(Actor.DEFAULT_STEP).toString());
		setStringVal(WINCOLOR, new Integer(Stage.DEFAULT_COLOR.getRGB())
				.toString());
		setStringVal(LEAVE, new Boolean(Stage.DEFAULT_MODE == Stage.LEAVE)
				.toString());
		// golden ratio
		setStringVal(HEIGHT, new Integer(defaultHeight).toString());
		setStringVal(WIDTH, new Integer(defaultWidth).toString());
		setStringVal(DUMPNAME, null);
		setStringVal(DUMPDELAY, new Integer(100).toString());
		setStringVal(FRAMEDELAY, new Integer(45).toString());

		setStringVal(TRACEINC, new Integer(0).toString());
		// put(TRACEFILE, "TRACE"); // FORCE TRACING
		setStringVal(TRACETHREADS, new Boolean(true).toString()); // CHANGE
		setStringVal(TRACETIME, new Boolean(false).toString());
	}

	/** 
	 * Creates instance reading argument values from Applet. 
	 * 
	 * Uses default argument values where the given applet has no parameter setting.
	 * 
	 * @param applet applet whose parameters are used fro argument values
	 */
	public Arguments(JApplet applet) {
		reset();
		setBoolVal(APPLET, new Boolean(true).toString());

		setBoolVal(TRAILNOTSHOWN, applet.getParameter(TRAILNOTSHOWN));
		setColor(TRAILCOLOR, applet.getParameter(TRAILCOLOR));
		setColor(SHAPECOLOR, applet.getParameter(SHAPECOLOR));
		setBoolVal(SHAPEFILLED, applet.getParameter(SHAPEFILLED));
		setBoolVal(ACTORVISIBLE, applet.getParameter(ACTORVISIBLE));
		setBoolVal(ACTORDEBUG, applet.getParameter(ACTORDEBUG));
		setColor(WINCOLOR, applet.getParameter(WINCOLOR));
		setBoolVal(LEAVE, applet.getParameter(LEAVE));
		setIntVal(TRAILWIDTH, applet.getParameter(TRAILWIDTH),
				Actor.DEFAULT_TRAIL_WIDTH);
		setDoubleVal(STEPSIZE, applet.getParameter(STEPSIZE), Actor.DEFAULT_STEP);
		setIntVal(HEIGHT, applet.getParameter(HEIGHT), 1);
		setIntVal(WIDTH, applet.getParameter(HEIGHT), 1);
		setString(DUMPNAME, applet.getParameter(DUMPNAME));
		setIntVal(DUMPDELAY, applet.getParameter(DUMPDELAY), 1);
		setIntVal(TRACEINC, applet.getParameter(TRACEINC), 0);
		setBoolVal(TRACETHREADS, applet.getParameter(TRACETHREADS));
		setBoolVal(TRACETIME, applet.getParameter(TRACETIME));
		setIntVal(FRAMEDELAY, applet.getParameter(FRAMEDELAY), 30);
		setString(ACTORCLASS, applet.getParameter(ACTORCLASS));
		String tfile = applet.getParameter(TRACEFILE);
		if (tfile != null) {
			tracer = new Trace(tfile);
		} else {
			tracer = Trace.global;
		}
	}

	/** 
	 * Creates instance reading argument values from command line. 
	 * 
	 * Uses default argument values where command line does not contain a setting.
	 * 
	 * @param cmdLine command line given as -<PARAM-NAME> <PARAM-VALUE>
	 */
	public Arguments(String cmdLine) {
		this(makeArray(cmdLine));
	}

	private Arguments(String args[]) {
		reset();

		setBoolVal(APPLET, new Boolean(false).toString());

		tracer = Trace.global;
		String propName = null;
		String propValue = null;
		for (int i = 0; i < args.length;) {
			propName = args[i];
			propValue = "true";
			i++;
			if (i < args.length) {
				if (args[i].charAt(0) != '-') {
					propValue = args[i];
					i++;
				}
			}
			propName = propName.substring(1);
			if (propName.equalsIgnoreCase(TRACEFILE)) {
				tracer = new Trace(propValue);
			} else {
				setStringVal(propName, propValue);
			}
		}
		tracer.setTraceThreadNames(getBoolean(TRACETHREADS));
		tracer.setTraceTime(getBoolean(TRACETIME));
		tracer.setTraceLevel(getInt(TRACEINC));
		frameMode = true;
	}

	private void apply(Actor def) {
		def.copyProps(null);
		def.setTrailColor(getColor(TRAILCOLOR));
		def.setTrailWidth(getInt(TRAILWIDTH));
		def.setStepSize(getDouble(STEPSIZE));
		Color sc = getColor(SHAPECOLOR);
		def.setColor(sc);
		((FillableShape) def.getShape()).setFilled(getBoolean(SHAPEFILLED));
		// def.setStepWait(getDouble(STEPWAIT));
		def.setTrailVisible(!getBoolean(TRAILNOTSHOWN));
		def.setVisible(getBoolean(ACTORVISIBLE));
		def.setDebugMode(getBoolean(ACTORDEBUG));
	}

	void apply(Stage s) {
		s.tracer.printMsg(this, "apply " + s + " def="
				+ Actor.getDefault().hashCode());

		apply(Actor.getDefault()); // apply args to default actor
		tracer.printMsg(Actor.getDefault(), " stp="
				+ Actor.getDefault().getStepSize());
		// apply args to stage
		s.setColor(getColor(WINCOLOR));
		s.setMode(getBoolean(LEAVE) ? Stage.LEAVE : Stage.FENCE);
		Trace.global.setTraceThreadNames(getBoolean(TRACETHREADS));
		Trace.global.setTraceTime(getBoolean(TRACETIME));
		Trace.global.setTraceLevel(getInt(TRACEINC));
	}

	/**
	 * Get the Value for the given parameter as a String.
	 * 
	 * @param argName
	 *            name of the parameter whose value is retrieved
	 * @return the parameter value or null if parameter does not exist
	 */
	public String get(String argName) {
		String value = (String) arguments.get(argName);
		// assert value != null;
		return value;
	}

	/**
	 * Get the Value for the given parameter as a Boolean value.
	 * 
	 * @param prop
	 *            name of the parameter whose value is retrieved
	 * @return the parameter value or false if parameter does not exist or is
	 *         not a Boolean value.
	 */
	public boolean getBoolean(String prop) {
		String val = get(prop);
		boolean ret = false;
		if (val != null) {
			try {
				return val.equalsIgnoreCase("true");
			} catch (Exception em) {
				Trace.report("Could not interperet " + prop + " value \"" + val
						+ "\" as boolean value");
			}
		}
		return ret;
	}

	Class getClass(String prop) {
		String val = get(prop);
		Class ret = null;
		if (val != null) {
			try {
				return Class.forName(val);
			} catch (Exception em) {
				Trace.report("Could not interperet " + prop + " value \"" + val
						+ "\" as class name");
			}
		}
		return ret;
	}

	/**
	 * Get the Value for the given parameter as a Color value. Values are
	 * expected to be in #rrggbb format.
	 * 
	 * @param argName
	 *            name of the parameter whose value is retrieved
	 * @return the parameter value or Color.WHITE if parameter does not exist or
	 *         is not a Color value.
	 */
	public Color getColor(String argName) {
		String val = get(argName);
		Color ret = Actor.DEFAULT_COLOR;
		if (val != null) {
			try {
				return Color.decode(val);
			} catch (Exception em) {
				Trace.report("Could not interprete " + argName + " value \""
						+ val + "\" as color value");
			}
		}
		return ret;
	}

	/**
	 * Get the Value for the given parameter as a Double value.
	 * 
	 * @param argName
	 *            name of the parameter whose value is retrieved
	 * @return the parameter value or 0.0 if parameter does not exist or is not
	 *         a Double value.
	 */
	public double getDouble(String argName) {
		String val = get(argName);
		double ret = 0.0;
		if (val != null) {
			try {
				return Double.parseDouble(val);
			} catch (Exception em) {
				Trace.report("Could not interperet " + argName + " value \""
						+ val + "\" as double value");
			}
		}
		return ret;
	}

	/**
	 * Get the Value for the given parameter as a int value.
	 * 
	 * @param argName
	 *            name of the parameter whose value is retrieved
	 * @return the parameter value or 0 if parameter does not exist or is not a
	 *         int value.
	 */
	public int getInt(String argName) {
		String val = get(argName);
		int ret = 0;
		if (val != null) {
			try {
				return Integer.parseInt(val);
			} catch (Exception em) {
				Trace.report("Could not interperet " + argName + " value \""
						+ val + "\" as integer value");
			}
		}
		return ret;
	}

	String[][] getParameterInfo() {
		if (std == null) {
			std = new String[][] {
					{
							TRAILNOTSHOWN,
							"true or false",
							"whether actor's paints a line along its movement trail, default "
									+ (Actor.DEFAULT_DO_TRAIL ? "true"
											: "false") },
					{
							TRAILWIDTH,
							"pos integer",
							"width of actor's trail, default "
									+ Actor.DEFAULT_TRAIL_WIDTH },
					{
							TRAILCOLOR,
							"#rrbbgg",
							"RGB definition of actor's trail color, default "
									+ Actor.DEFAULT_COLOR.toString() },

					{
							SHAPEFILLED,
							"true or false",
							"whether default actor shape is solid "
									+ Actor.DEFAULT_FILLED },
					{
							SHAPECOLOR,
							"#rrbbgg",
							"RGB definition of actor's shape color, default "
									+ Actor.DEFAULT_COLOR.toString() },
					{
							STEPSIZE,
							"pos double",
							"number of pixels moved in each step, default "
									+ Actor.DEFAULT_STEP },
					{
							LEAVE,
							"true or false",
							"whether the stage's mode should be LEAVE (true) or FENCE (false), default FENCE" },

					{
							DUMPDELAY,
							"pos integer",
							"time delay between writing image files measured in stage's clock ticks, default 100" },
					{ DUMPNAME, "string",
							"name to be used for imagefile, default empty/no image writing" },
					{
							WINCOLOR,
							"#rrbbgg",
							"RGB definition of window's background color, default "
									+ Stage.DEFAULT_COLOR },
					{ HEIGHT, "pos integer",
							"the Stage height, default " + defaultHeight },
					{ WIDTH, "pos integer",
							"the Stage width, default " + defaultWidth },

			};
		}
		return std;
	}

	public String getString(String argName) {
		return get(argName);
	}

	Actor getActor(Stage s) {
		Actor initialActor = null;
		String cls = get(ACTORCLASS);
		try {
			if (cls == null) {
				initialActor = new Actor.ErrorActor("No initial actor argument");
				usage(Trace.global.getStream());
			} else {
				initialActor = (Actor) newInst(cls);
			}
		} catch (RuntimeException e) {
			System.err.println("Could not instantiate Actor " + cls + ".");
			if (e.getCause() != null) {
				System.err.println("\tReason: " + e.getCause());
			}
			initialActor = new Actor.ErrorActor(cls + " is an unknown class");
			usage(Trace.global.getStream());
		}
		tracer.println("cloned initial actor " + initialActor);
		return initialActor;
	}

	Director newDirector(Component c, Object creator) {
		Director d = new Director(creator, null, this, c);
		d.init();
		ImageShape.TheClassLoader = creator.getClass().getClassLoader();
		return d;
	}

	private void setStringVal(String argName, String argValue) {
		try {
			if (argValue != null) {
				argName = argName.toUpperCase();
				arguments.put(argName, argValue);
			}
		} catch (Exception e) {
			tracer.printMsg(e, "");
			Trace.report(e);
		}
	}

	private void setBoolVal(String prop, String value) {
		if (value == null)
			return;
		try {
			setStringVal(prop, new Boolean(value).toString());
		} catch (Exception e) {
			Trace.report(prop + ": " + value
					+ " is not a boolean value (true/false)");
		}
	}

	/**
	 * Set the value of the given parameter to the given String value.
	 * 
	 * @param prop
	 *            name of the parameter whose value is set
	 * @param value
	 *            the parameters new String value
	 */
	public void setColor(String prop, String value) {
		if (value == null)
			return;
		try {
			Color.decode(value);
			setStringVal(prop, value);
		} catch (Exception e) {
			Trace.report(prop + ": " + value
					+ " is not a color value in rgb format");
		}
	}

	/**
	 * Set the value of the given parameter to the Double value corresponding to
	 * the given value string. If the given value does not represent a Double
	 * value greater or equal the given minimum value an error message is
	 * printed and no action is taken.
	 * 
	 * @param prop
	 *            name of the parameter whose value is set
	 * @param value
	 *            string representing the parameter's new Double value
	 * @param minVal
	 *            the given value is required to be greater or equal to this
	 *            value
	 */
	public void setDoubleVal(String prop, String value, double minVal) {
		if (value != null) {
			try {
				double setVal = Double.parseDouble(value);
				if (setVal >= minVal) {
					setStringVal(prop, value);
				} else {
					Trace.report(value + " is not greater equal " + minVal);
				}
			} catch (Exception e) {
				Trace.report(value + " is not a double value");
			}
		}

	}

	/**
	 * Set the value of the given parameter to the int value corresponding to
	 * the given value string. If the given value does not represent an int
	 * value greater or equal the given minimum value an error message is
	 * printed and no action is taken.
	 * 
	 * @param prop
	 *            name of the parameter whose value is set
	 * @param value
	 *            string representing the parameter's new int value
	 * @param minVal
	 *            the given value is required to be greater or equal to this
	 *            value
	 */
	public void setIntVal(String prop, String value, int minVal) {
		if (value != null) {
			try {
				int setVal = Integer.parseInt(value);
				if (setVal >= minVal) {
					setStringVal(prop, value);
				} else {
					Trace.report(value + " is not greater equal " + minVal);
				}
			} catch (Exception e) {
				Trace.report(value + " is not an integer value");
			}
		}
	}

	/**
	 * Set the value of the given parameter to the given value string. No action
	 * is taken if value equals <code>null</code>
	 * 
	 * @param prop
	 *            name of the parameter whose value is set
	 * @param value
	 *            string representing the parameter's new value
	 */
	public void setString(String prop, String value) {
		setStringVal(prop, value);
	}

	public String toString() {
		return Utils.shortClassName(this);
	}

	/**
	 * Print list of this Argument's name, value pairs
	 * 
	 * @param tr
	 *            print destination
	 */
	public void trace(Trace tr) {
		if (!tr.doTrace())
			return;
		for (Enumeration e = this.arguments.keys(); e.hasMoreElements();) {
			String key = (String) e.nextElement();
			String value = (String) arguments.get(key);
			tr.println(key + "=" + value);
		}
	}

	public void usage(PrintStream s) {
		getParameterInfo();
		if (frameMode) {
			System.err
					.println("Usage: java mcm.theater.Play -actor ActorClass [OPTIONS]");
			System.err.println("   OPTIONS:");
			for (int i = 0; i < std.length; i++) {
				if (std[i][0].compareTo(ACTORCLASS) != 0)
					s.println("\t-" + std[i][0] + "\t" + std[i][1] + "\n\t\t"
							+ std[i][2]);
			}
		} else {
			System.err.println("Necessary Parameters:");
			System.err.println("\t<PARAM NAME=" + ACTORCLASS
					+ " VALUE=...ActorClassName...>\n");
			System.err.println("Optional Parameters:");
			for (int i = 0; i < std.length; i++) {
				if (std[i][0].compareTo(ACTORCLASS) != 0)
					s.println("\t<PARAM NAME=" + std[i][0] + " VALUE=..."
							+ std[i][1] + "...>\n" + "\t\t" + std[i][2]);
			}
		}
	}

	/**
	 * Return the tracer constructed from argument settings
	 */
	public Trace getTracer() {
		return tracer;
	}
}