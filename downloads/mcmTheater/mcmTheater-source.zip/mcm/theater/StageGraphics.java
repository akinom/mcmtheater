package mcm.theater;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Line2D;
import java.awt.Font;

import mcm.utils.Assert;

/**
 * StageGraphics manages graphics information and offers convenience drawing
 * methods.
 * 
 * {@link Actor}and {@link Shape}use StageGraphics.
 * 
 * @author Monika Mevenkamp
 */
class StageGraphics {

//	Color bgColor;

	Color fgColor;

	private int lineWidth;
	private BasicStroke stroke = new BasicStroke(); 

	Font font;

	private Line2D.Double line = new Line2D.Double(); 
	
	public int getLineWidth() {
		return lineWidth;
	}
	public void setLineWidth(int lineWidth) {
		this.lineWidth = lineWidth;
		stroke = new BasicStroke(lineWidth);
	}
	
	public StageGraphics() {
		resetToDefaults();
	}

	public StageGraphics(StageGraphics ag) {
		this();
		fgColor = ag.fgColor;
		lineWidth = ag.lineWidth;
		font = ag.font;
	}


	void drawLine(Stage stage, double x, double y, double X, double Y) {
		//				Trace.global.printMsg(this, "> drawLine stage="
		//						+ stage.hashCode());
		synchronized (stage) {
			line.x1 = x; 
			line.y1 = y; 
			line.x2 = X; 
			line.y2 = Y;
			drawShape(stage, line, false);
		}
	}

	public void drawShape(Stage stage, java.awt.Shape awtShape, boolean filled) {
		Assert.check(stage != null);
		Assert.check(awtShape != null);
		Graphics2D g2d = stage.getGraphics();
		Assert.check(g2d != null);
		synchronized (stage) {
			g2d.setColor(fgColor);
			g2d.setStroke(stroke);
			if (filled) {
				g2d.fill(awtShape);
			} else {
				g2d.draw(awtShape);
			}
		}
	}

	static final Font defaultFont = new Font("Serif", Font.BOLD, 14);
	
	void resetToDefaults() {
		fgColor = Color.RED;
		lineWidth = 1;
		font = defaultFont;
	}

	public BasicStroke getStroke() {
		return stroke;
	}
	void setStroke(BasicStroke stroke) {
		this.stroke = stroke;
	}
}