
package mcm.theater;

import mcm.graphics.Point;
import mcm.utils.Assert;

/**
 * Point is a wrapper for the {@link java.awt.geom.Point2D}.Double class. 
 * It provides various convenient constructors.
 *
 * @author Monika Mevenkamp
 * 
 */
class StagePoint extends mcm.graphics.Point {

	public StagePoint(Point p) {
		this(p.x, p.y);
	}
	
	/** 
	 * x + i * stage.width, y + j * stage.height is the real position
	 */
	int i, j; 
	
	void transPos(Stage stage, double x, double y){
		this.x = x;
		this.y = y;
		this.transPos(stage);
	}
	
	/** 
	 * 
	 * @param stage
	 * @param pos
	 */
	 void transPos(Stage stage) {
	 	if (stage == null) return; // GAMES 
		if (stage.getMode() == Stage.LEAVE) { 
			return; 
		} else if (stage.getMode() == Stage.WRAP) {
			i = (int) (x / stage.getWidth()); 
			x = x - i * stage.getWidth(); 
			j = (int) (y / stage.getHeight()); 
			y = y - j * stage.getHeight(); 
		} else {
			Assert.check(stage.getMode() == Stage.FENCE);
			i = 0; 
			if (x < 0) {
				x = 0; 
				i = -1; 
			} else if (x > stage.getWidth()) {
				x = stage.getWidth() - 1;
				i = +1; 
			}
			j = 0; 
			if (y < 0) {
				y = 0; 
				j = -1; 
			} else if (y > stage.getHeight()) {
				y = stage.getHeight() - 1;
				j = +1; 
			}
		}
	}

	/**
	 * Constructs and initializes a point with coordinates (0, 0).
	 */
	public StagePoint() {
		this(0.0, 0.0);
		i = 0; 
		j = 0; 
	}

	/**
	 * Constructs and initializes a point with coordinates (x, y)
	 */
	public StagePoint(double x, double y) {
		super(x, y);
	}

	/**
	 * Constructs and initializes a point with coordinates (x, y)
	 */
	public StagePoint(float x, float y) {
		super(x, y);
	}

	/**
	 * Constructs and initializes a point with coordinates (x, y)
	 */
	public StagePoint(int x, int y) {
		super(x, y);
	}

	/**
	 * Constructs and initializes a point with coordinates (p.x, p.y)
	 */
	public StagePoint(StagePoint p) {
		super(p.x, p.y);
	}
	
	/**
	 * Returns a String that represents the x and y coordinate values 
	 * of this point. 
	 * Coordinates values sare shown with at most two digits after the 
	 * decimal point.
	 * 
	 * @return the x and y coordinate values in braces
	 */
	public String toString() 
	{
		double xd  = ((int) x * 100) / 100; 
		double yd  = ((int) y * 100) / 100; 	
		return "(" + xd + "," + yd + ")"; 
	}
}
