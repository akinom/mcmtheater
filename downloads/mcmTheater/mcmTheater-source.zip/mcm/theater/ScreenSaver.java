package mcm.theater;

import java.awt.Component;

import org.jdesktop.jdic.screensaver.SimpleScreensaver;

import mcm.graphics.ImageShape;
import mcm.theater.Director;
import mcm.utils.Assert;
import mcm.utils.Utils;
import mcm.utils.Trace;

/**
 * A ScreenSaver animates a Stage, whose Actors are created by the Director
 * given to this Screensaver.
 * 
 * @author Monika Mevenkamp
 */
public class ScreenSaver extends SimpleScreensaver {
  
  private Arguments args;      // created on basis of ScreenSaver arguments 
  
  private AnimatedStage stage; // set in init on basis of TheaterArgs
  private Director director;   // set in init on basis of TheaterArgs
  private Actor initialActor;  // null (then args must define initial actor) or 
  // an initial actor supplied by constructor
  private boolean inited;
  
  private Thread animator;     // set to current thread in paint
  
  protected Trace tracer;
  
  protected Play play; 
  
  int traceLevel = 2;
  
  private long frameDelay; 
  
  
  public ScreenSaver() {
    this(new Play(), null); 
  }
  
  protected ScreenSaver(Play play, Actor initial) {
    super();
    this.play = play;
    initialActor = initial;
    tracer = Trace.global;
//  tracer = new Trace("trace"); 
//  tracer.setTraceLevel(1);
    args = null;
    stage = null;
    inited = false;
    animator = null;
  }
  
  protected void finalize() {
    if (stage != null) {
      tracer.printMsg(this, "finalize");
      stage.getScheduler().stop();
      stage = null;
    }
  }
  
  Arguments getArgs() 
  {
    if (args == null) {
      String line = getContext().getSettings().getNormalizedCommandline();
      args = new Arguments(line);
      Trace.global = args.getTrace(); 
      tracer = Trace.global;
      tracer.printMsg(this, "init: cmdLine " + ((line == null) ? "" : line));   
    }
    return args;
  }
  
  public void init() {
    try {
      if (!inited) {
        getArgs();
        tracer.printMsg(this, "init");
        Assert.check(args != null);
        
        args.trace(tracer);
        if (stage == null) {
          Component root = getContext().getComponent();
          director = new Director(this, initialActor, args, root); 
          director.init();
          ImageShape.TheClassLoader = root.getClass().getClassLoader();
          stage = director.getStage();
          Assert.check(stage != null);
        }
        
        frameDelay = args.getInt(Arguments.FRAMEDELAY);
        if (frameDelay < 30)
          frameDelay = 30;
        inited = true;
      }
    } catch (RuntimeException e) {
      tracer.printMsg(this, "Exception " + e);
      e.printStackTrace(tracer.getStream());
      throw e;
    }
  }
  
  public void paint(java.awt.Graphics g) {
    if (inited) {
      if (animator == null) {
        try {
          if (stage != null) {
            if (stage.isReady()) { 
              tracer.printMsg(this, "start");
              animator = Thread.currentThread();
              director.start(Thread.currentThread(), false);
            }
          }
        } catch (RuntimeException e) {
          System.err.println("Could not start director.");
          throw e;
          //     e.printStackTrace();
          //     System.exit(0);
        }
      }
    }
    if (animator != null) {
      long stepStart = System.currentTimeMillis();
      Scheduler scheduler = stage.getScheduler();
      scheduler.runThem();
      stage.updateGraphics();
      stage.paint(g);
      long delta = System.currentTimeMillis() - stepStart; 
      if (delta < frameDelay) {
        if (tracer.doTraceLevel(traceLevel+1))
          tracer.traceln("fast round: " + (frameDelay - delta));
        try {
          Thread.sleep(frameDelay - delta);
        } catch (InterruptedException e) {
          // never mind; just continue 
        } 
      } else {
        if (tracer.doTraceLevel(traceLevel+1))
          tracer.traceln("slow round: " + (frameDelay - delta));       
      }
      if (tracer.doTraceLevel(traceLevel+1)) {
        tracer.trace(".");
        if (stage.getTime() % 100 == 0) {
          tracer.traceln();
        }
      }
    }
  }
  
  Director getDirector() {
    return director;
  }
  
  public String toString() {
    return Utils.shortClassName(this) + " "
      + ((args == null) ? "args=null" : Utils.shortClassName(args));
    
  }
  
}