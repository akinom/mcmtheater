package mcm.theater;

import java.awt.Frame;
import java.lang.reflect.Constructor;
import mcm.utils.*;

/** 
 * <p>
 * Play initializes a Stage and starts an initial Actor to run on that Stage.
 * 
 * It can be executed as an Applet or a Java application that starts a frame
 * window. It animates the Stage on the applet's or frame's window. The class
 * name of the initial actor may be supplied through an applet or command line
 * parameter.
 * </p>
 * <p>
 * To start a Play with an initial actor of the class <code>Rectangle</code>
 * from the package <code>sample</code> as application from the command line
 * type:
 * 
 * <pre>
 *  java mcm.theater.Play -actor sample.Rectangle
 * </pre>
 * 
 * The above assumes that the CLASSPATH environment variable lists the
 * folders/directories where the jar files containing the mcm theater and
 * saverbeans packages reside.
 * </p>
 * <p>
 * To start the same actor in an applet define the following html file:
 * 
 * <pre>
 *  &lt;applet code=mcm.theater.Play.class width=&quot;200&quot; height=&quot;200&quot; 
 *          ARCHIVE=&quot;mcmTheater.jar&quot;&gt;
 *      &lt;param name=&quot;ACTOR&quot; value=&quot;sample.Rectangle&quot;&gt;
 *  &lt;/applet&gt;
 * </pre>
 * 
 * </p>
 * 
 * <p>
 * As a third option classes may include a main method using Play's main method
 * as follows:
 * <pre>
 * public class Starter {
 *    public static void main(String args[]) {
 *    Play.main(args, new sample.Rectangle());
 *    }
 * }
 * </pre>
 * 
 * @author Monika Mevenkamp
 */
public class Play extends MApplet {
  
  private static final long serialVersionUID = 1L;
  
  private ScreenSaver saver; // non-null <==>  run as application 
  
  Director getDirector() {
	    if (saver != null) {
	      return saver.getDirector(); // running as screensaver application 
	    } else {
	      return super.getDirector(); // running as applet 
	    }
	  }
	  
  public Actor getInitial() {
	    Director dir = getDirector();
	    Actor a = dir.waitForInitial(); 
	    tracer.println("Initial Actor has class: " + a.getClass()); 
	    return a;
  }  
  
  /** 
   * Returns the play's stage. 
   * The stage remains null until the stage area has been fully initialized.
   *  
   * @return null, or the play's stage
   */
  public Stage getStage() 
  {
    Director d= getDirector(); 
    if (d == null) return null;
    return d.getStage(); 
  }
  
  /**
   * Called by the Java interpreter when Play is executed as application.
   * 
   * The command line arguments must include "-actor &lt;actorClassName&gt;",
   * where &lt;actorClassName&gt;; is the name of an Actor class with a
   * default constructor. The main method creates a Play that instantiates and
   * displays a frame window which serves as Stage. It instantiates the given
   * actor class and starts that actor at the center of the stage.
   * 
   * @param argv
   *            command line arguments
   */
  public static void main(String argv[]) {
    main(argv, null); 
  }
  
  /**
   * This main method starts a Play with the given actor as initial actor.
   * 
   * The created Play instantiates and displays a frame window which 
   * serves as the stage. It creates a clone of the given Actor and starts that 
   * actor as the initial actor at the center of the stage.
   * 
   * The command line arguments passed may be used to set the stage's default color, 
   * colors used by actors, their default trail width, .... 
   * Calling a Play with -help prints all available options. 
   * 
   * @param argv command line arguments
   * @param a a template for the initial actor
   */
  public static void main(String argv[], Actor a) {
    start(argv, a);
  }
  
  /** 
   * Like the main method start starts a Play. 
   * It returns a reference to the Play it started. 
   * 
   * @param a a template for the initial actor
   * @return the play that was started 
   */
  public static Play start(Actor a) {
    return start(new String[0], a); 
  }

  /** 
   * Like the main method start starts a Play. 
   * It returns a reference to the Play it started.
   * The width and height parameters determine the size of the stage. 
   * 
   * @param width the width of the stage/window started for the play 
   * @param height the height of the stage/window started for the play 
   * @param a a template for the initial actor
   * @return the play that was started 
   */
  public static Play start(int width, int height, Actor a) {
    String[] argv = new String[6];
    argv[0] = "-width"; 
    argv[1] = "" + width; 
    argv[2] = "-height"; 
    argv[3] = "" + height; 
    argv[4] = "-trace"; 
    argv[5] = "" + Trace.global.getTraceLevel();
    return start(argv, a); 
  }

  /**
   * Like main starts a Play. 
   * 
   * @param argv command line arguments, @link Play#main(String[], Actor)
   * @param a a template for the initial actor
   * @return the play that was started 
   */
  public  static Play start(String argv[], Actor a) {
    Play play = new Play(); 
    play.saver = new ScreenSaver(play, a);
    Frame frame = newScreensaverFrame(play.saver, Arguments.makeLine(argv));
    
    int width = play.saver.getArgs().getInt(Arguments.WIDTH);
    int height = play.saver.getArgs().getInt(Arguments.HEIGHT);
    // add empiral pixel to make up for window frame.
    frame.setSize(width + 17, height + 34);  
    frame.show();
    return play;
  }
  
  /* don't want to explicitly refer to screensaver api so that it does not have to 
   * be added to theater jar file used with applets 
   */
  private static Frame newScreensaverFrame(ScreenSaver saver, String string) {
    try {
      ClassLoader c = Play.class.getClassLoader();
      Class ssCls =  c.loadClass("org.jdesktop.jdic.screensaver.ScreensaverFrame");
      Class ssbCls =  c.loadClass("org.jdesktop.jdic.screensaver.ScreensaverBase");
      Class[] types = { ssbCls, string.getClass() };
      Constructor constr = ssCls.getConstructor(types);
      Object[] params = { saver, string};
      Object o = constr.newInstance(params);
      Frame f = (Frame) o;
      if (f == null) {
        throw new NullPointerException("Can't cast " + o.getClass() + " to Frame"); 
      }
//   Frame f = new ScreensaverFrame(saver, string);
      return f;
    } catch (Exception e) {
      e.printStackTrace();
      System.exit(1); 
    }
    return null;
  }
}
