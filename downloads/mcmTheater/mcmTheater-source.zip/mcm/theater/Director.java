// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Director.java

package mcm.theater;

import java.awt.Component;
import mcm.theater.actor.StageDump;
import mcm.utils.Assert;
import mcm.utils.Utils;
import mcm.utils.Trace;

/**
 * A Director creeates, starts, and sends Actors onto its Stage.
 * 
 * @author Monika Mevenkamp
 */
class Director {

	Play creator;
	private Arguments args;

	private Component display;

	private AnimatedStage stage;

	private Actor initialActor; 
	
	protected Trace tracer;

	public Director(Object creatr, Actor actor, Arguments targs, Component c) {
		tracer = Trace.global;
		tracer.traceMsg(this, "new");
		if (creatr instanceof Play)
			creator = (Play) creatr;
		args = targs;
		initialActor = actor;
		display = c;
	}

	public AnimatedStage getStage() {
		return stage;
	}

	public void init() {
		tracer.traceMsg(this, "init");
		Assert.check(display != null);
		Assert.check(args != null);
		stage = new AnimatedStage(display, args);
		if (initialActor == null) {
			initialActor = args.getActor(stage); 
		}
	}

	public Actor waitForInitial() {
		while (true) {
			if (initialActor != null && initialActor.thread.hasStarted()) {
				return initialActor;
			}
			try {
				Thread.sleep(30);
			} catch (InterruptedException e) {
				// never mind
			}
		}
	}
	
	public void start(Thread thread, boolean start) {
		Assert.check(thread != null);
		stage.clear();
		stage.scheduler.startTicking(thread, start);
		String fname = args.getString(Arguments.DUMPNAME);
		if (fname != null && fname.length() > 0) {
			Actor d = new StageDump(fname, args.getInt(Arguments.DUMPDELAY));
			d.start(stage);
		}
		Actor a = initialActor.getClone();
		a.copyProps(initialActor);
		initialActor = a;
		tracer.printMsg(thread, "starting initial actor " + a);
		a.jumpTo(getStage().getCenter());
		a.start(stage);
	}

	/**
	 * Returns  abbbreviated class name of this istance 
	 * @return a string representation 
	 */
	public String toString() {
		return Utils.shortClassName(this);
	}

}