package mcm.theater;

import java.awt.Component;

class AnimatedStage extends Stage {

	AnimatedStage(Component c, Arguments as) {
		super(c, as);
	}

	/** 
	 * determines whether this stage is ready to be painted to 
	 * @return <code>true</code> if this stage is ready; <code>false</code> otherwise 
	 */
	public boolean isReady() {
		return getComponent().getWidth() != 0
				&& getComponent().getHeight() != 0;
	}

	public Scheduler getScheduler() 
	{
		return scheduler;
	}

}