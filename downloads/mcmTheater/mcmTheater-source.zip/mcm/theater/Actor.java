package mcm.theater;

import java.awt.Color;
import java.awt.geom.AffineTransform;

import mcm.graphics.Body;
import mcm.graphics.DirectionShape;
import mcm.graphics.Point;
import mcm.graphics.Shape;
import mcm.graphics.TextShape;
import mcm.theater.actor.ShowShape;
import mcm.utils.Assert;
import mcm.utils.MCMRuntimeException;

/**
 * <p>
 * Actor is the abstract base class that all actors are derived from.
 * 
 * Derived actors must implement the act() method. An actor's
 * {@link Actor#start(Stage)}method puts the actor on the given stage and
 * creates and starts a new thread. The thread executes the actor's
 * <code>act</code> method, which typically contains calls that change an
 * actor's position and/or appearance, that is its {@link Shape}.
 * </p>
 * <p>
 * The {@link Stage}'s scheduler makes sure that simultaneously executing
 * actors advance at the same rate. It provides a clock that advances one clock
 * tick as soon as all its actors finish their current step. Actors in turn
 * inform their stage that they finished a step by calling their
 * {@link Actor#sleep()}method, which suspends their excecution until the stage
 * advances the clock. Actors call <code>sleep()</code> either explicitly or
 * implicitly from within one of the move methods. If an actor's thread executes
 * in debug mode it uses the <code>sleep</code> method to animate their
 * direction changes, see {@link Actor#setDirection(double)}.
 * </p>
 * <p>
 * Actors travel about their stage using one of the {@link Actor#move},
 * {@link Body#jump}, or {@link Actor#line}methods. Movement is performed
 * incrementally in steps, the size of which is determined by the actor's
 * stepSize. Actors sleep for one clock tick between steps. An actor
 * instantaneously jumps to a new position by calling one of the jump or line
 * methods. Jumping does not take time and leaves no movement trail. Line
 * methods do not consume any time and always leave a trail behind.
 * </p>
 * <p>
 * A visible actor shows its shape at its current position on stage while
 * invisible actors do not. Whether an actor leaves a movement trail by drawing
 * a line along its paths is governed by its trail visibility setting. The
 * trail's color is determined by the actor's trail color and the trail's width
 * by the actor's trail width.
 * </p>
 * <p>
 * An Actor that moves along the sides of a equilateral triangle with sides 50 pixels long
 * can be programmed  as follows:
 * <hr width=100%>
 * 
 * <pre>
 * class TriangleActor extends Actor {
 * 	public void act() {
 * 		while (true) {
 * 		   move(50);
 * 		   right(120);
 * 		}
 * 	}
 * }
 * </pre>
 * 
 * <hr width=100%>
 * The following code creates a TriangleActor, positions it at the center of
 * Stage <code>stage</code>, and starts its execution:
 * 
 * <pre>
 * TriangleActor a = new TriangleActor();
 * a.jumpTo(stage.getCenter());
 * a.start(stage);
 * </pre>
 * 
 * <hr width=100%>
 * By default actors draw a line along their movement path. The following code
 * changes the color and line width that Actor a uses when drawing lines:
 * 
 * <pre>
 * a.setTrailColor(Color.GREEN);
 * a.setTrailWidth(3);
 * </pre>
 *  
 */
public abstract class Actor extends Body {

	/** 
	 * global to store default property values 
	 */
	static Actor defaults;

	static {
		DEFAULT_COLOR = new Color(1.0f, 0.0f, 0.0f, 0.8f);
		resetDefaults();
	}

	/**
	 * this <code>Actor</code>'s Stage
	 * @link Stage.
	 */
	Stage stage;

	/**
	 * <code>doTrailPaint</code> indicates whether this <code>Body</code> draws a
	 * trail along its path movement
	 */
	volatile boolean doPaintTrail;

	/** 
	 * indicates whether actor is currently executing its act() method 
	 */
	private boolean isInActing;

	/** 
	 * the Actor's thread; 
	 */
	ScheduledThread thread;

	/**
	 * number of pixels to go in one movement step
	 */
	double stepSize;

	/** 
	 * indicates whether the actor runs in debug mode
	 */
	private boolean debugMode;

	private StageGraphics actorGraphics;

	static final boolean DEFAULT_FILLED = true;

	static final Color DEFAULT_COLOR; // see static init: new Color(1.0f, 0.0f, 0.0f, 0.8f);

	static final boolean DEFAULT_VISIBLE = true;

	static final boolean DEFAULT_DEBUG = false;

	static final int DEFAULT_TRAIL_WIDTH = 1;

	static final double DEFAULT_STEP = 5;

	static final boolean DEFAULT_DO_TRAIL = true;

	/**
	 * Constructs a new Actor object. 
	 * This constructor copies properties such as lineWidth, visibility, ... from 
	 * the defaults actor. 
	 * 
	 * @see Actor#getDefault()
	 */
	public Actor() {
		this(defaults);
	}

	/**
	 * Creates an Actor copying properties from <code>copy</code>.
	 * <p>
	 * The constructor copies the following properties from to initialize
	 * properties from the given <code>template</code> actor. 
	 * If <code>template</code> is <code>null</code> the global defaults actor
	 * is used in its place. 
	 * 
	 * @param template
	 *            the Actor from which to copy properties
	 * 
	 * @see Actor#getDefault()
	 */
	public Actor(Actor template) {
		super(template);
		tracer.printMsg(this, "Actor.Actor(" + template + ")"); 
		isInActing = false;
		thread = new ScheduledThread(this);
		actorGraphics = new StageGraphics();
		stage = null;
		copyProps(template);
	}
	
	/** 
	 * Copies template actor's properties from the givem <code>template</code> actor. 
	 * The properties copied are those copied by {@link Body#copyProps(Body)} 
	 * as well as: 
	 * <UL>
	 * <LI> step size, see {@link  #setStepSize(double)}  </LI>
	 * <LI> debug mode, see {@link  #setDebugMode(boolean)} </LI>
	 * <LI> trail width, see {@link  #setTrailWidth(int)}  </LI>
	 * <LI> trail color, see {@link  #setTrailColor(Color)}  </LI>
	 * <LI> trail visibiliy, see {@link  #setTrailVisible(boolean)}  </LI>
	 * </UL>
	 * 
	 * copyProps is called by Actor constructors and must be implemented 
	 * by derived classes that wish to copy additional properties. 
	 * Implementations of copyProps must explicitly call the implementation 
	 * of super classes.
	 * 
	 * @param template the actor template from which to copy properties 
	 */
	public void copyProps(Actor template) {
		super.copyProps(template);
		if (template == null) {
			DirectionShape shape = new DirectionShape(20, 20);
			shape.setFilled(DEFAULT_FILLED);	
			shape.setColor(DEFAULT_COLOR);
			stepSize = DEFAULT_STEP;
			debugMode = DEFAULT_DEBUG;
			doPaintTrail = DEFAULT_DO_TRAIL; 
			setTrailColor(DEFAULT_COLOR);
			setTrailWidth(DEFAULT_TRAIL_WIDTH);
		} else {
			stepSize = template.stepSize;
			debugMode = template.debugMode;
			doPaintTrail = template.doPaintTrail;
			setTrailColor(template.getTrailColor());
			setTrailWidth(template.getTrailWidth());
			if (!template.thread.getScheduled()) {
				thread.setUnscheduled();
			}
		}
		//tracer.printMsg(this, "copyProps from " + template);
	}

	/**
	 * <p>
	 * An actor's act method is executed in its own thread once the actor is
	 * started. A typical act method contains method calls that change the
	 * position and/or the appearance of an actor.
	 * </p>
	 * <p>
	 * When an actor is started, see {@link Actor#start(Stage)}, it is added to
	 * the given stage and a new thread is started, which calls the actor's act
	 * method. While the thread executes the act method, calls to
	 * {@link Actor#isActing()}return <code>true</code> and calls to
	 * {@link Actor#getStage()}return a reference to the stage on which the
	 * actor was started. The actor's thread terminates once the act method
	 * finishes. The actor is removed from the stage, calls to
	 * {@link Actor#isActing()}return <code>false</code>, and calls to
	 * {@link Actor#getStage()}continue to return the stage on which the actor
	 * executed.
	 * </p>
	 * <p>
	 * act methods must explicitly or implicitly call the {@link Actor#sleep()}
	 * method frequently so that the stage can advance its clock and update its
	 * image regularly.
	 * </p>
	 */
	public void act() {
		setShape(new TextShape(getClass().getName() + ": has no act() method", 
				getStage()));
		setDebugMode(true);
	}
	
	/** 
	 * Tests whether the actor's thread is currently executing its act method. 
	 * 
	 * @return <code> true</code> if the answer is yes; <code>false</code> otherwise. 
	 * 
	 * @see Actor#act() 
	 */
	public boolean isActing() {
		return isInActing;
	}

	/** 
	 * Returns <code>null</code> or the body's stage.
	 * 
	 * @return <code>null</code> or the body's stage 
	 */
	public Stage getStage() {
		return stage;
	}

	void doit() {
		Assert.check(getStage() != null,
				"WHAT ? doit() is triggered by start(Stage) which sets stage");
		try {
//				tracer.traceMsg(this, "> doit"); 
			isInActing = true;
			if (thread.getScheduled()) {
				tracer.traceMsg(this, "> act");
				act();
				tracer.traceMsg(this, "< act");
				while (getDebugMode() && thread.getScheduled()) {
					sleep(1);
				}
			}
		} catch (RuntimeException e) {
			// stage == null or some programming error in act() metho
			throw e;
		} finally {
			tracer.traceMsg(this, "< act");
			if (thread.getScheduled())
				isInActing = false;
		}

//		if (tracer.doTraceLevel(traceLevel)) {
//			tracer.traceMsg(this, "< doit"); 
//		}
	}

	/** 
	 * Sets this actor's name. 
	 * @param name the new name
	 */
	public void SetName(String name) {
		super.setName(name);
		if (thread != null) {
			thread.setName(name);
		}
	}

	/**
	 * Sets the actor's debugMode.
	 * While an actor's debugMode is <code>true</code> it animates changes to its movement direction 
	 * and it stays on its stage even after finishing its act method. 
	 * 
	 * By default an actor is not in debug mode. 
	 * 
	 * @param mode <code> true</code> or <code>false</code>.
	 * 
	 * @see #setDirection(double)
	 */
	public void setDebugMode(boolean mode) {
		testForDeath();
		this.debugMode = mode;
	}

	/**
	 * Returns the actor's debug mode. 
	 *
	 * @return  <code> true</code> if the actor is in debug mode; <code>false</code> otherwise.
	 * 
	 * @see #setDirection(double)
	 */
	public boolean getDebugMode() {
		testForDeath();
		return this.debugMode;
	}

	//	-----------------------------------------------------------------------------------------
	// starting/stoppping ....
	//
	/**
	 * Starts the actor on the given stage. 
	 * <BR> This method has the same effect as calling start(s, 0); 
	 */
	public void start(Stage stage) {
		start(stage, 0);
	}

	/**
	 * Starts the actor on the given stage with the given delay.
	 * <code>start</code> enters this actor on the given stage. 
	 * It creates and starts a new thread which calls the actor's act method. 
	 * The thread starts after 
	 * the stage's clock advanced <code>delay</code> clock ticks if 
	 * <code>delay</code> is greater than zero. Otherwise it starts 
	 * immediately. 
	 * 
	 * @see Actor#sleep  
	 */
	public void start(Stage s, int delay) {
		if (stage != null) {
			throw new MCMRuntimeException("Actor " + getName()
					+ " has already been started.");
		}
		if (s == null) {
			throw new NullPointerException("Stage is null");
		}
		if (thread.isAlive()) {
			throw new MCMRuntimeException(getName()
					+ " has already been started.");
		}
		stage = s;
		thread.start(stage.getScheduler(), delay);
	}

	/**
	 * <p>
	 * Terminate the execution of this actor's thread. 
	 * The terminate method sets a flag indicating the request that this actor's thread should terminate.
	 * As soon as  this actor's thread calls one of the actor methods, that method throws 
	 * an {@link ActorDeath} exception thus terminating the thread.  
	 * </p> 
	 * <code>terminate</code> has no effect if this actor's thread is not executing.
	 */
	public void terminate() {
		thread.terminate();
	}

	/** 
	 * Tests whether this actor's thread is executing and  must terminate. 
	 * <code>testForDeath</code> returns <code>false</code> 
	 * if this actor's thread is not executing, that is has not started yet or has already finished 
	 * It throws an {@link ActorDeath} exception 
	 * if this actor's thread is executing, has been requested to terminate, and 
	 * testForDeath is called by this actor's thread. 
	 * In all other cases it returns <code>false</code>.

	 * @return <code> false</code> or throws ActorDeath exception
	 */
	boolean testForDeath() {
		if (thread != null)
			thread.testForDeath();
		return false;
	}
	
	/** 
	 * Tests whether this actor has a non null stage
	 * 
	 * @return <code>true</code> or throws MCMRuntimeException exception
	 */
	boolean testForStage() {
		if (stage == null)
			throw new MCMRuntimeException("Actor is not on a stage"); 
		return false;
	}

	/**
	 * Returns a reference to the global default actor. 
	 * 
	 * Actor constructors use the default actor's properties, such as its position, direction, stepSize
	 * to initialize the properties of newly constructed actors.
	 * Be aware that there is only one global default actor that is shared by all actors.
	 * 
	 * @return the default actor 
	 */
	static public Actor getDefault() {
		return defaults;
	}

	/**
	 * Resets the default body's properties.
	 * 
	 * The properties of the default Body are reset as follows: 
	 * <UL> 
	 * <LI> The position is set to (0, 0). </LI> 
	 * <LI> The direction is set to 0 degrees, that is the map direction EAST. </LI> 
	 * <LI> The step size is set to 5.0. </LI> 
	 * <LI> The visibility and trail visibilty are set to <code>true</code> </li>
	 * <LI> The shape is set to DirectionShape with a 20 pixel diagonal </LI>
	 * <LI> The trail color and shape's color is set RED </LI> 
	 * <LI> The trail width and shape's line width are set to 1 </LI>
	 * <LI> The debug mode is set to <code>false</code>
	 * </UL> 
	 */
	public static Actor resetDefaults() {
		synchronized (Actor.class) {
			if (defaults == null) {
				defaults = new ShowShape();
				defaults.setName("_DEFAULTS_");
			}
		}
		return defaults;
	}

	/** 
	 * Sets the actor's movement direction in degrees, {@link Body#setDirection(double)}.
	 * setDirection performs in one step unless the actor is in debugMode. 
	 * In that case it turns in 3 degree increments calling <code>sleep</code> in between.
	 * </p>
	 * @param angle the movement angle given in degrees 
	 */
	public void setDirection(double angle) {
		testForDeath();
		if (debugMode) {
			double directionAngle = getDirection();
			double inc = 3;
			if (directionAngle < angle) {
				for (double a = directionAngle; a < angle; a = a + inc) {
					super.setDirection(a);
					sleep(1);
				}
			} else {
				for (double a = directionAngle; a > angle; a = a - inc) {
					super.setDirection(a);
					sleep(1);
				}
			}
			super.setDirection(angle);
			if (directionAngle != angle) {
				sleep(1);
			}
		} else {
			super.setDirection(angle);
		}
	}

	/** 
	 * Paints the shape to the Stage's backgound. 
	 * @see Stage
	 */
	public void stamp() {
		testForDeath();
		testForStage();
		draw(stage.getGraphics()); 
	}

	/**
	 * <p> 
	 * Suspends the actor's thread for n ticks on its stage's clock.
	 * Sleep signals the end of one execution step to this actor's stage, which 
	 * advances its clock once all its actors finish their current execution step. 
	 * Sleep(1) returns when the stage advances the clock once, 
	 * Sleep(n) resumes after the stage advanced the clock n times. 
	 * </p> 
	 * <p> 
	 * sleep may only be called from within an actor's act() method amd on the actor itself.
	 * </p> 
	 */
	public void sleep(int n) {
		//tracer.printMsg(this, "> sleep " + n + " time=" + getStage().getTime()); 
		thread.sleep(n);
		//tracer.printMsg(this, "< sleep " + n + " time=" + getStage().getTime()); 
	}

	/**
	 *Suspends the actor's thread for n ticks on its stage's clock.
	 *<BR>This method has the same effect as sleep(1). 
	 */
	public void sleep() {
		sleep(1);
	}

	//---------------------------------------------------------------------------------------
	/* movement 
	 */

	/** 
	 * Returns the actor's step size. 
	 * @return the step size 
	 */
	public double getStepSize() {
		testForDeath();
		return stepSize;
	}

	/**
	 * Indicates that this actor is controlled from DrJava's Interactions pane. 
	 *
	 *  If a user wishes to control an actor by issuing method calls 
	 *  from <a href=javascript:top.location='http://drjava.sourceforge.net/';>DrJava</a>'s  Interactions pane, 
	 *  s/he must call setDrJava before starting that actor. 
	 */
	public void setDrJava() 
	{
		thread.setUnscheduled(); 
	}
	
	/** 
	 * Sets  the actor's step size. 
	 * @param stepSize  the new step size 
	 */
	public void setStepSize(double stepSize) {
		testForDeath();
		if (stepSize <= 0) {
			throw new MCMRuntimeException("Can't set stepSize to " + stepSize
					+ " for Acttor " + this.getName());
		}
		this.stepSize = stepSize;
	}

	private StagePoint cur = new StagePoint();
	private StagePoint next = new StagePoint();
	private StagePoint to = new StagePoint();

	private void doTheMove(double tox, double toy) {
		Assert.check(stepSize > 0.0);
		stage = getStage();
		if (stage == null) {
			throw new MCMRuntimeException("Actor " + getName()
					+ " can't move iff not on stage");
		}
		testForDeath();

		Point pos = getPos();
		double deltax = tox - pos.x;
		double deltay = toy - pos.y;
		double dist = Math.sqrt(deltax * deltax + deltay * deltay);

		if (dist == 0.0) {
			sleep(1);
			return;
		}
		double nSteps = dist / stepSize;
		//tracer.printMsg(this, "> doTheMove + " + tox + "," + toy + " dist=" + dist + " nSteps=" + nSteps);

		deltax = deltax / nSteps;
		deltay = deltay / nSteps;

		if (nSteps >= 1) {
			double curx, cury;
			curx = pos.x;
			cury = pos.y;
			cur.transPos(stage, curx, cury);
			for (int i = 1; i <= nSteps; i++) {
				next.transPos(stage, curx + i * deltax, cury + i * deltay);
				if (next.i != cur.i || next.j != cur.j) {
					cur.transPos(stage, curx + (i - 1) * deltax, cury + (i - 1)
							* deltay);
				}
				if (tracer.doTraceLevel(traceLevel + 1))
					tracer.traceMsg(this, "(" + cur.x + "," + cur.y + ") -> ("
							+ next.x + "," + next.y + ")");
				if (doPaintTrail) {
					actorGraphics.drawLine(stage, cur.x, cur.y, next.x, next.y);
				}
				jumpTo(next.x, next.y);
				pos.x = next.x;
				pos.y = next.y;
				sleep(1);
			}
		}
		
		to.transPos(stage, tox, toy); 
		if ((nSteps < 1)
				|| ((pos.x - to.x > 1 || pos.y - to.y > 1 || pos.x - to.x < -1 || pos.y
						- to.y < -1))) {

			if (tracer.doTraceLevel(traceLevel + 1))
				tracer.traceMsg(this, "(" + pos.x + "," + pos.y + ") -> ("
						+ tox + "," + toy + ")");
			if (doPaintTrail) {
				cur.transPos(stage, pos.x, pos.y);
				next.transPos(stage, tox, toy);
				actorGraphics.drawLine(stage, cur.x, cur.y, next.x, next.y);
			}
			jumpTo(tox, toy);
			sleep(1);
		}
		jumpTo(tox, toy);
		//tracer.printMsg(this, "< doTheMove + " + tox + "," + toy + " dist=" + dist + " nSteps=" + nSteps);
	}

	/**
	 * The actor moves the given distance in its current movement direction. 
	 * Movement is done in incremental movement steps. 
	 * The size of each step is determined by the actor's step size.
	 * The actor calls <code>sleep(1)</code> in between steps. 
	 * </p> 
	 * <p> 
	 * If the actor's trail visibility is set to <code>true</code> it draws a line 
	 * along its movement path. 
	 * </p>
	 * @param dist the total  distance to move
	 * 
	 * @see Actor#sleep(int)
	 */
	public void move(double dist) {
		moveTo(gotoPos(dist));
	}

	/** 
	 * The actor moves to the position given by the <code>tox</code>, <code>toy</code> coordinates. 
	 * Movement is done in incremental movement steps. 
	 * The size of each step is determined by the actor's step size.
	 * The actor calls <code>sleep(1)</code> in between steps. 
	 * @param tox the x coordinate of the movement's destination 
	 * @param toy the y coordinate of the movement's destination 
	 */
	public void moveTo(double tox, double toy) {
		if (tracer.doTraceLevel(traceLevel))
			tracer.traceMsg(this, "moveTo (" + tox + "," + toy + ")");
		doTheMove(tox, toy);
		//sleep(stepWait);
	}

	/**
	 * This method has the same effect as moveTo(to.x, to.y).
	 * 
	 * @param to the position to move to 
	 */
	public void moveTo(Point to) {
		moveTo(to.x, to.y);
	}

	/**
	 * Computes the number of clock ticks needed to cover the given distance. 
	 * 
	 * getMoveDelay computes the number of ticks on the stage's clock that need to 
	 * pass for this actor to cover the given distance using its current step size.
	 * 
	 * @param dist movement distance for which to compute the delay
	 * @return dist / stepSize if the given distance is a multiple of the actor's stepSize; otherwise 1 + dist / stepSize
	 */
	public int getMoveDelay(double dist) {
		double delay = dist / getStepSize();
		if ((int) delay == delay) {
			return (int) delay;
		} else {
			return (int) delay + 1;
		}
	}

	//-----------------------------------------------------------------------------------------
	private StagePoint lineToFrom = new StagePoint();

	private StagePoint ineToTo = new StagePoint();

	/**
	 * Sets the body's position to point <code>(tox, toy)</code> and 
	 * always leaves a trail along the jumped distance.
	 * @param tox the destination point's x coordinate  
	 * @param toy the destination point's y coordinate  
	 */
	public void lineTo(double tox, double toy) {
		if (tracer.doTraceLevel(traceLevel))
			tracer.traceMsg(this, "lineTo (" + tox + "," + toy + ")");

		testForDeath();
		Point pos = getPos();
		lineToFrom.transPos(stage, pos.x, pos.y);
		ineToTo.transPos(stage, tox, toy);
		actorGraphics.drawLine(stage, lineToFrom.x, lineToFrom.y, ineToTo.x,
				ineToTo.y);
		jumpTo(tox, toy);
	}

	/**
	 * Sets the body's position to the given point and 
	 *  always leaves a trail along the jumped distance.
	 * @param to the body's new position 
	 */
	public void lineTo(Point to) {
		lineTo(to.x, to.y);
	}

	/**
	 * Jump the given distance from the current position in the current movement direction and 
	 * always leaves a trail along the jumped distance.
	 * The body's position is set to the point at the 'end of the jump'.
	 */
	public void line(double dist) {
		lineTo(gotoPos(dist));
	}

	/** 
	 * Returns the body's trail color.
	 * @return the trail color.
	 */
	public Color getTrailColor() {
		testForDeath();
		return actorGraphics.fgColor;
	}

	/** 
	 * Returns  the body's trail width. 
	 * @return the body's trail width
	 */
	public int getTrailWidth() {
		testForDeath();
		return actorGraphics.getLineWidth();
	}

	/** 
	 * Tests whether the body's trail visibility is set to <code>true</code>.
	 * @return <code> true</code> if the actor paints a line along its path; <code>false</code> otherwise. 
	 * 
	 * @see Actor#move(double)
	 */
	public boolean isTrailVisible() {
		return doPaintTrail;
	}

	/** 
	 * Sets  the body's trail color. 
	 * @param color  the new  color 
	 */
	public void setTrailColor(Color color) {
		testForDeath();
		this.actorGraphics.fgColor = color;
	}

	/**
	 * Sets the body's trail visibility to the given parameter.
	 * A body paints a line along their movement paths if their trail visibility is set to 
	 * <code>true</code>. Otherwise they move without drawing a line along their paths.
	 * 
	 * @param mode
	 *            the trail painting mode
	 * 
	 * @see Actor#move
	 */
	public void setTrailVisible(boolean mode) {
		testForDeath();
		this.doPaintTrail = mode;
	}

	/** 
	 * Sets  the body's trail width. 
	 * @param width  the new  width
	 */
	public void setTrailWidth(int width) {
		testForDeath();
		this.actorGraphics.setLineWidth(width);
	}

	//	/** 
	//	 * overwrites the default body point transformation behaviour 
	//	 */
	//	private AffineTransform actorTransform; 

	/** 
	 * Actor's transformation takes stage mode into account.
	 * 
	 * @see Body#getTransform()
	 */
	protected AffineTransform getTransform() {
		if (shapeTransform == null) {
			StagePoint transPos = new StagePoint(getPos());
			transPos.transPos(stage);
			shapeTransform = new AffineTransform();
			shapeTransform.translate(transPos.x, transPos.y);
			if (rotatesShape()) {
				shapeTransform.rotate(getDirectionRad());
			}
		}
		return shapeTransform;
	}

	/**
	 * Returns a clone of this actor
	 */
	Actor getClone() {
		try {
			Actor a =  (Actor) this.clone();
			a.copyProps(this);
			return a;
		} catch (Exception e) {
			return new ErrorActor(getClass().getName()
					+ " has no default constructor");
		}
	}

	/** 
	 * This is a singleton, only one instance !
	 */
	static class ErrorActor extends ShowShape {
		static private ErrorActor singleton = null; 
		
		String msg = "Generic Error";

		ErrorActor(String msg) {
			Assert.check(singleton == null); 
			this.msg = msg;
		}

		public Object clone() {
			return this; 
		}

		public void act() {
			setShape(new TextShape(msg, getStage()));
			super.act();
		}
	}
	
	public String toString() {
		String s = ""; 
		if (thread != null && !thread.getScheduled()) {
			s = " interactive";
		}
		if (isInActing) {
			return super.toString() + "(" + s + ")";
		} else {
			return super.toString() + "( inactive" + s + ")"; 
		}
	}

}
