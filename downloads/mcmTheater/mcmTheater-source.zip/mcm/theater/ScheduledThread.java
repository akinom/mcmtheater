package mcm.theater;

import mcm.theater.ActorDeath;
import mcm.utils.Assert;
import mcm.utils.MCMRuntimeException;
import mcm.utils.Trace;

/**
 * ScheduledThreads are controlled by a round robin scheduler. 
 * 
 * Whenever a thread calls the sleep() method it finishes the current scheduler round 
 * and waits for the scheduler to wake it up again.
 * Once all threads registered with the same scheduler have finished the current round 
 * a new round may be started by the scheduler. 
 * 
 * The round robin scheduler trusts the threads it controls in that it expects them to 
 * frequently call {@link ScheduledThread#sleep}.
 */
class ScheduledThread extends Thread {

   /**
    * number of instances finalized
    */
   static private volatile int nFinalized = 0;

   /**
    * number of instances constructed
    */
   static private volatile int nInstances = 0;

   /**
    * @return number of <code>Actor</code> instances not yet finalzed
    */
   static int nOnHeap() {
      synchronized (ScheduledThread.class) {
         return nInstances - nFinalized;
      }
   }

   /**
    * the Actor that this thread represents
    */
   private final Actor actor;

   Actor getActor() { return actor; } 
  
   /** 
    * indicates whether actor is to be run under be scheduler 
    */
   private boolean scheduled; 
   void setUnscheduled() { scheduled = false; }
   boolean  getScheduled() { return scheduled; } 
   
   /**
    * indicates whether thread should exit (via throwing ActorDeath Excaption 
    */
   private volatile boolean mustDie;

   /**
    *  instance receive increasing id when they are started 
    */
   private static int startId = 0; 
   int myId;   // used in assertion about scheduling order, see Scheduler
   
   /**
    * indicates which round is the next this thread needs to work on
    */
   private volatile int curRound;

   /** 
    * the Scheduler responsible for threads notifications 
    * set once in start()
    */
   private Scheduler scheduler;

   boolean hasStarted() { return scheduler != null; }
   /** 
    * used to synchronize with scheduler 
    */
   Scheduler.WaitInfo waitInfo; 
   
    /**
    * number of ticks to wait before enetering stage 
    * set once in start, never changed afterwards 
    */
   private int startDelay;
 
   protected Trace tracer;

   public ScheduledThread(String name, Actor a) {
      super(name);
      synchronized (ScheduledThread.class) {
         nInstances++;
      }
      actor = a;
      scheduled = true;
      tracer = a.getTracer();
      curRound = -1;
      mustDie = false;
      waitInfo = new Scheduler.WaitInfo(this); 
   }

   public ScheduledThread(Actor a) {
      this(a.getName(), a);
   }

   protected void finalize() {
      synchronized (ScheduledThread.class) {
         nFinalized++;
         if (true || tracer.doTraceLevel(Scheduler.traceLevel))
            tracer.traceMsg(this, "finalize " + nFinalized);
      }
   }

   /**
    * Starts the execution of a new thread that calls doit() in its run() method
    */
   public void start(Scheduler s, int delay) {
      if (tracer.doTraceLevel(Scheduler.traceLevel))
         tracer.printMsg(this, " forked by "
               + Scheduler.info(Thread.currentThread()) + " delay="
               + delay + " nOnHeap=" + ScheduledThread.nOnHeap());
      if (hasStarted()) {
         throw new MCMRuntimeException("Can not start " + this
               + " more than once.");
      }
      if (delay < 0) {
         throw new MCMRuntimeException(
               "Start Delay must be greater equal zero");
      }
      if (Thread.currentThread() instanceof ScheduledThread) {
         ScheduledThread starter = (ScheduledThread) Thread.currentThread();
         starter.testForDeath(); // throws ActorDeath if called from thread
                           // that must Die
      }
      Assert.check(!isAlive());
      scheduler = s;
      startDelay = delay;
      synchronized (ScheduledThread.class) {
			myId = ++startId;
		}
		if (tracer.doTraceLevel(Scheduler.traceLevel)) {
			setName(getName() + "/ti=" + myId);
		} else {
			setName(getName());
		}
 
      
      scheduler.addThread(this);
      
      if (scheduled) { 
    	  super.start();
      } else {
    	  actor.doit(); 
      }
   }

   /**
    * A ScheduledThread's run() method is executed in its own thread.
    * Threads width scheduled != true do not start their own thread. 
    * This is for example usefull when they are created from the interactions 
    * pane in DrJava.
    * It surrounds the calls to the doit() and stop() methods with the necessary
    * book keeping code for the scheduler.
    */
   public void run() {
		try {
			Assert.check(Thread.currentThread() == this);
			Assert.check(scheduled);
			tracer.traceMsg(this, "start run ");

			this.waitInfo.doWait();
			curRound = scheduler.getRound();
			try {
				if (startDelay > 0)
					sleep(startDelay);
				actor.doit();
			} catch (ActorDeath e) {
				Assert.check(mustDie);
				if (tracer.doTraceLevel(Scheduler.traceLevel))
					e.printStackTrace(tracer.getStream());
			}
		} catch (Exception e) {
			tracer.println("Should never happen");
			Trace.report(e);
		}
      mustDie = true;
      waitInfo.dying();
      waitInfo.getNext().signal(waitInfo);
   }

   /**
    * Puts this ScheduledThread on hold for n ticks on the scheduler's clock
    */
   protected void sleep(int n) {
      if (n < 0) {
         throw new MCMRuntimeException("n must be greater equal zero");
      }
      if (this.scheduled && Thread.currentThread() != this) {
    	  throw new MCMRuntimeException("Can not force scheduled actor to sleep"); 
      }
      for (int delta = 0; delta < n; delta++) {
         sleep();
      }
   }
   
   // called from ScheduledThread
	private void sleep() {
		if (scheduled) {
			testForDeath();
			waitInfo.getNext().signal(waitInfo);
			waitInfo.doWait();
			curRound++;
			Assert.check(scheduler.getRound() == curRound);
		} else {
			try {
				Thread.sleep(30);
				// super.sleep(1);
			} catch (InterruptedException e) {
				// never mind
			}
		}
	}

   /**
	 * Request termination of this thread
	 */
   public void terminate() {
      synchronized (scheduler) {
         if (tracer.doTraceLevel(Scheduler.traceLevel))
            tracer.printMsg(this, "terminate " + info() + " nOnHeap="
                  + ScheduledThread.nOnHeap());
         mustDie = true;
      }
   }

   /**
    * Throws an ActorDeath exception if the ScheduledThread must terminate.
    * 
    * testForDeath is called implicitly by {@link #sleep}.
    */
   public void testForDeath() throws ActorDeath {
      if (hasStarted()) {
         mustDie = mustDie || scheduler.getAllMustDie();
         if (mustDie) {
            if (Thread.currentThread() == this) {
               throw new ActorDeath(this.getName());
            } else {
               if (tracer.doTraceLevel(Scheduler.traceLevel))
                  tracer.traceMsg(this, this + " needs to die");
            }
         }
      }
   }

   String info() {
		String info = "[" + toString() + " #=" + curRound + " "
				+ ((mustDie) ? "mustDie" : "alive") + " ";
		info += "next=";
		if (waitInfo.getName() == null) {
			info += "**ERROR**";
		} else {
			info += waitInfo.getNext().getName();
		}
		info += "]";
		return info;
	}
   
   public String toString() {
      return actor.toString();
   }


}
