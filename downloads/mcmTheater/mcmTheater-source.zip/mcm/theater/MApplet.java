package mcm.theater;

import java.awt.Graphics;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;

import javax.swing.JApplet;

import mcm.graphics.ImageShape;
import mcm.theater.Director;
import mcm.utils.Assert;
import mcm.utils.Utils;
import mcm.utils.Trace;

/**
 * An Applet animates a Stage, whose Actors are created by the Director given to
 * this Applet.
 * 
 * @author Monika Mevenkamp
 */
class MApplet extends JApplet implements Runnable, ComponentListener {

	/**
	 * used in serialization
	 */
	private static final long serialVersionUID = 8923520850277959463L;

	private String theDot;

	private Director director;

	private Arguments args;

	private Actor initialActor;

	/**
	 * Applet methods use this for tracing purposes.
	 */
	protected Trace tracer;

	int traceLevel = 2;
	int traceLevelDetail = 7;

	private int frameDelay;

	private Thread animator;

	private boolean animRunning;

	private final int id; 
	
	/**
	 * Constructs a new MApplet. Assigns {@link Trace#global}to its tracer
	 * field.
	 */
	public MApplet() {
		id = hashCode(); 
		theDot = "" + id + ".";
		initialActor = null;
		this.setName(Utils.shortClassName(this) + "#" + id);
		tracer = Trace.global;
		addComponentListener(this);
		animRunning = false; // no animation thread is running
		animator = null; // reference to animation thread
	}

	/**
	 * Constructs arguments using Applet's Parameter's
	 */
	protected Arguments getArgs() {
		return new Arguments(this);
	}

	/* one time inittialization run in Applet mode only */
	/**
	 * Called by the browser or applet viewer to inform this applet that it has
	 * been loaded into the system.
	 * 
	 * @see java.applet.Applet#init()
	 */
	public synchronized void init() {
		try {
			tracer.printMsg(this, "> init\n\tcodeBase=" + getCodeBase());
			if (args == null) {
				args = getArgs();
				//Arguments.newTheaterArgs(initialActor);
				tracer = args.getTracer();
				Trace.global = args.getTracer();
				args.trace(tracer);
				frameDelay = args.getInt(Arguments.FRAMEDELAY);
				if (frameDelay < 30)
					frameDelay = 30;
				director = new Director(this, initialActor, args, this);
				director.init();
				ImageShape.TheClassLoader = this.getClass().getClassLoader();
			}
			tracer.printMsg(this, "< init");
		} catch (Exception e) {
			System.err.println("Could not init the applet " + this);
			Trace.report(e);
		}
	}

	/**
	 * Called by the browser or applet viewer to inform this applet that it
	 * should start its execution.
	 * 
	 * @see java.applet.Applet#start()
	 */
	public synchronized void start() {
		try {
			tracer.printMsg(this, "> start ");
			if (animator == null) {
				// the animator has been stopped
				// but it may not have finished yet
				while (animRunning) {
					try {
						Thread.sleep(1);
					} catch (InterruptedException e) {
						// try again
					}
				}
				// now that the old animator is done start a new animator
				synchronized (MApplet.class) {
					animator = new Thread(this, "ANIMATOR#" + id);
				}

				animRunning = true;
				director.start(animator, true);
				Assert.check(director.getStage().isReady());
			}
			tracer.printMsg(this, "< start ");
		} catch (Exception e) {
			System.err.println("Could not start the applet " + this);
			Trace.report(e);
		}
	}

	/**
	 * Called by the browser or applet viewer to inform this applet that it
	 * should stop its execution.
	 * 
	 * @see java.applet.Applet#stop()
	 */
	public synchronized void stop() {
		try {
			tracer.printMsg(this, "> stop ");
			if (animator != null) {
				dump();
				animator = null; // indicate to animator that it needs to finish
			}
			tracer.printMsg(this, "< stop ");
		} catch (Exception e) {
			System.err.println("Could not stop the applet " + this);
			Trace.report(e);
		}
	}

	/**
	 * Invoked when the component has been made visible. This Play starts
	 * execution.
	 */
	public void componentShown(ComponentEvent e) {
		this.start();
	}

	/**
	 * Invoked when the component has been made invisible. This Play stops
	 * execution.
	 */
	public void componentHidden(ComponentEvent e) {
		this.stop();
	}

	/**
	 * Invoked when the component's position changes.
	 * 
	 * @see java.awt.event.ComponentListener#componentMoved(java.awt.event.ComponentEvent)
	 */
	public void componentMoved(ComponentEvent e) {
	}

	/**
	 * Invoked when the component has been made visible.
	 * 
	 * @see java.awt.event.ComponentListener#componentResized(java.awt.event.ComponentEvent)
	 */
	public void componentResized(ComponentEvent e) {
	}

	/**
	 * The run() method of the animator that drives the {@link Stage}and its
	 * {@link Actor}s.
	 */
	public void run() {
		try {
			tracer.printMsg(this, ">> run/animate");
			AnimatedStage stage = director.getStage();
			Scheduler scheduler = stage.getScheduler();
			while (Thread.currentThread() == animator) {
				long stepStart = System.currentTimeMillis();
				dots();
				scheduler.runThem();
				if (tracer.doTraceLevel(traceLevelDetail))
					tracer.printMsg(this, "runThem step "
							+ (System.currentTimeMillis() - stepStart));

				stage.updateGraphics();
				repaint();
				long delta = System.currentTimeMillis() - stepStart;
				if (tracer.doTraceLevel(traceLevelDetail))
					tracer.printMsg(this, "graphics step " + delta);
			
				if (delta < frameDelay) {
					try {
						if (tracer.doTraceLevel(traceLevel))
							tracer.traceln("fast round: " + (frameDelay - delta));
						Thread.sleep(frameDelay - delta);
					} catch (InterruptedException e) {
						// continue
					}
				} else {
					if (tracer.doTraceLevel(traceLevel))
						tracer.traceln("slow round: " + (frameDelay - delta));
				}
			}
			scheduler.stop();
			System.gc();
			animRunning = false; // indicate to applet that naimtor is done
			tracer.printMsg(this, "<< run/animate #actors="
					+ stage.getNumberOfActors());
		} catch (Exception e) {
			System.err.println("Animation thread croaked in applet " + this);
			Trace.report(e);
		}
	}

	static int nDots = 0;

	private void dots() {
		if (tracer.doTraceLevel(traceLevel)) {
			tracer.print(theDot);
			nDots++;
			if (nDots == 80) {
				tracer.print("\n");
				nDots = 0;
			}
		}
	}

	/** 
	 * @return null or the play's director 
	 */
	Director getDirector() {
		return director;
	}
	
	/**
	 * Repaints the Stage associated with this Applet
	 */
	public synchronized void paint(Graphics g) {
		if (director != null) {
			director.getStage().paint(g);
		}
	}

    /** 
     * Updates the applet by displaying the current stage contents. 
     */
    public void update(Graphics g) {
		paint(g);
	}

	synchronized void dump() {
		Scheduler scheduler = director.getStage().getScheduler();
		scheduler.listAll(tracer, scheduler.getName() + " All scheduled threads");
	}	
	
	/**
	 * Returns information about the parameters that are understood by this
	 * applet.
	 * 
	 * @see java.applet.Applet#getParameterInfo()
	 */
	public String[][] getParameterInfo() {
		return args.getParameterInfo();
	}

	/**
	 * Returns a string representation of this Applet
	 */
	public String toString() {
		return getName()
				+ ((animator == null) ? "" : ("(" + animator.getName()
						+ " delay=" + frameDelay + ")"));
	}
}