package mcm.theater.actor; 

import mcm.theater.*; 

public class DrJava extends Actor {
 
  public void act() {
  }
  
//  public void sleep(int n) {
//    for (int i = 0; i < n; i++) {
//      try {
//        Thread.sleep(30);
//        //super.sleep(1); 
//      } catch (InterruptedException e) {
//        //never mind 
//      } 
//    }
//  }
  
//  public static Play  start(int width, int height) {
//     return start(width, height, new DrJava()); 
//}
//
//  public static Play  start(int width, int height, Actor a) {
//    String[] argv = new String[4]; 
//    argv[0] = "-width"; 
//    argv[1] = "" + width; 
//    argv[2] = "-height"; 
//    argv[3] = "" + height;
//    Play play = Play.start(argv, a); 
//    return play;
//  }
}