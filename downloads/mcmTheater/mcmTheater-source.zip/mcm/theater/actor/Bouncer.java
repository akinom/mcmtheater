// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3)
// Source File Name: BouncingActor.java

package mcm.theater.actor;

import mcm.graphics.Point;
import mcm.theater.Actor;
import mcm.theater.Play;
import mcm.theater.Stage;
import mcm.utils.Dice;
import mcm.utils.Trace;

/**
 * Bouncer actors bounce off the stage's sides like 
 * billard balls do on a pool table. 
 * 
 * @author Monika Mevenkamp
 */
public class Bouncer extends Actor {
	
	/** 
     * The actor bounces off the stage's sides changing direction like billard 
	 * balls do on a pool table.
	 * It starts to move at its current position in its current direction. 
	 */
	public void act() {
		while (true) {
			bounce();
		}
	}

	public static void main(String argv[]) {
		Bouncer b = new Bouncer(); 
		b.setDirection(Dice.throwDouble(360));
		Play.main(argv, b); 
	}
	
	private double getScale(int min, double pos, double delta, double max) {
		double scale = 0.0D;
		if (delta < 0)
			scale = (double) (min - pos) / (double) delta;
		else if (delta > 0)
			scale = (double) (max - pos) / (double) delta;
		return scale;
	}

	private void bounce() {
		Stage stage = getStage(); 
		if (stage == null) return; 
		Point pos = getPos();
		Point to = new Point(pos); 
		double height = stage.getHeight();
		double width = stage.getWidth();
		Point direction = new Point(); 
		double rad = (Math.PI * (double) getDirection()) / 180D;
		direction.x = Math.cos(rad);
		direction.y = Math.sin(rad); 		
		try {
			if (direction.x == 0 && direction.y == 0) {
				// don't stay at same place 
				setDirection(Dice.throwInt(360)); 
				rad = (Math.PI * (double) getDirection()) / 180D;
				direction.x = Math.cos(rad);
				direction.y = Math.sin(rad); 		
				return;
			}
			if (direction.x == 0) {
				// go up or down to y == 0 or y == height
				to.y = direction.y <= 0 ? 0 : height; 
				direction.y = -direction.y;
				return;
			}
			if (direction.y == 0) {	
				// go left or right to x == 0 or x == width
				to.x = direction.x <= 0 ? 0 : width;
				direction.x = -direction.x;
				return;
			}
			
			// compute point on stage border to hyead towards 
			double sx = getScale(0, pos.x, direction.x, width);
			double sy = getScale(0, pos.y, direction.y, height);
			double scale = sx >= sy ? sy : sx;
			to.x = pos.x + (scale * direction.x);
			to.y = pos.y + (scale * direction.y);
			
			// change direction for the next bounce 
			if (to.y == 0 && direction.y < 0 || to.y == height && direction.y > 0)
				direction.y = -direction.y;
			if (to.x == 0 && direction.x < 0 || to.x == width && direction.x > 0)
				direction.x = -direction.x;
		} finally {
			if (Trace.global.doTraceLevel(2)) 
				tracer.traceMsg(this, "bounceTo (" + to.x + "," + to.y + ")");
			moveTo(to);
			setDirection(direction.x, direction.y);
		}
	}
}