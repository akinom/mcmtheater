package mcm.theater.actor;

import java.io.IOException;

import mcm.theater.Actor;
import mcm.utils.MCMRuntimeException;

/** 
 *  StageDump actors periodically write the Stage's contents  to an image file.
 * 
 * @author Monika Mevenkamp
 */
public class StageDump extends Actor {
	private String fileName;

	private int delay;

	private String format = "PNG";

	/**
	 * Constructs a new StageDump actor.
	 * The actor uses its name as the file name prefix. 
	 * Its act method  periodically writes its stage to image files in the 
	 * given format.
	 * 
	 * The actor receives a default name if <code>name</code> equals <code>null</code>.
	 * 
	 * @param name the new actor's name and prefix of all files written
	 * @param dumpDelay delay in stage clock ticks between writing image files
	 * @param format the format to use, actor writes "PNG" files if format equals <code>null</code> 
	 */
	public StageDump(String name, int dumpDelay, String format) {
		fileName = name;
		delay = dumpDelay;
		if (format == null)
			format = "PNG";
		this.format = format;
	}

	/**
	 * Constructs a StageDump actor. 
	 * 
	 * This constructor has the same effect as StageDump(name, dumpDelay, "PNG"). 
	 */
	public StageDump(String name, int dumpDelay) {
		this(name, dumpDelay, "PNG");
	}

	/** 
	 * Sets this actor's file name prefix to the given name. 
	 * The file prefix defaults to the actor's name. 
	 * 
	 * @param prefix the file prefix
	 */
	public void setFilePrefix(String prefix) {
		fileName = prefix;
	}

	/** 
	 * Returns this actor's file name prefix.  
	 */
	public String getFilePrefix() {
		return fileName;
	}

	/** 
	 * This actor writes the stage's image to a file every dumpDelay ticks on 
	 * the stage's clock. 
	 * The file written is called 
	 * <blockquote> 
	 * &lt;fileName&gt;&lt;id&gt;.&lt;format&gt;, 
	 * </blockquote>
	 * 
	 * where &lt;fileName&gt; is this actor's file name prefix, 
	 * which defaults to the actor's name, 
	 *  &lt;id&gt; is the current file number, 
	 * and &lt;format&gt; is the format given at construction. 
	 * File numbers start at 0 and continue 1, 2, 3, ...
	 */
	public void act() {
		setVisible(false);
		int fileNo = 0;
		try {
			while (true) {
				sleep(delay);
				getStage().write(format, fileName + fileNo + "." + format);
				fileNo++;
			}
		} catch (IOException e) {
			System.err.println("Could not dump stage image:\n");
			e.printStackTrace();
		}
	}

	/**
	 * Returns this actor's dumpDelay.
	 * @return Returns the delay.
	 */
	public int getDelay() {
		return delay;
	}

	/**
	 * Sets this actor's dumpDelay. 
	 * @param delay The delay to set.
	 */
	public void setDelay(int delay) {
		if (delay < 1) {
			throw new MCMRuntimeException("Delay must be greater 0");
		}
		this.delay = delay;
	}
}