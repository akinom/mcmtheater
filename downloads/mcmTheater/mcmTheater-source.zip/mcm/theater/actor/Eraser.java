package mcm.theater.actor;

import mcm.theater.Actor;
import mcm.theater.Stage;
import mcm.utils.MCMRuntimeException;

/** 
 * Eraser actors periodically clear the Stage. 
 * 
 * @author Monika Mevenkamp
 */
public class Eraser extends Actor {
	private int waitTicks = 100;

	/** 
	 * Construct a new Eraser actor. 
	 * 
	 * If the given name is <code>null</code> a default name is constructed in the 
	 * Actor constructor. 
	 * 
	 * @param ticks actor's wait ticks
	 */
	public Eraser(int ticks) {
		setVisible(false);
		waitTicks = ticks;
	}

	/** 
	 * Construct a new Eraser actor.
	 * This constructor has the same effect as Eraser(100, null). 
	 */
	public Eraser() {
		this(100);
	}

	/**
	 * Returns the number of stage clock ticks that the actor waits 
	 * between clearing the stage. 
	 * 
	 * @return the actor's wait ticks
	 */
	public int getWaitTicks() {
		return waitTicks;
	}

	/**
	 * Sets the number of stage clock ticks that 
	 * the actor waits between clearing the stage.
	 * 
	 * @param nTicks number of clock ticks 
	 */
	public void setWaitTicks(int nTicks) {
		if (nTicks < 1) {
			throw new MCMRuntimeException("Can set waitTicks to " + nTicks
					+ ", it i smaller than 1.");
		}
		this.waitTicks = nTicks;
	}

	/** 
	 * Erasers actors alternate between sleeping and clearing the stage. 
	 * The number of clock ticks they sleep is determined by their current 
	 * wait ticks.
	 * 
	 * @see Stage#clear()
	 */
	public void act() {
		Stage stage = getStage();
		while (true) {
			sleep(waitTicks);
			stage.clear();
		}
	}
}