package mcm.theater.actor;

import mcm.theater.Actor;
import mcm.theater.Play;

/**
 * ShowShape actors do nothing but show their shape.
 * Thus they never move, stay alive forever showing 
 * their shape at their location.
 * 
 * @author Monika Mevenkamp
 */
public class ShowShape extends Actor {

	/**
	 * Constructs a ShowShape actor and sets its visibility to <code>true</code>.
	 */
	public ShowShape() {
		setVisible(true);
	}

	/**
	 * Stay at the same position doing nothing. 
	 * The method is defined as: <pre> 
	 * while (true) { sleep(100000000);  } 
	 * </pre>
	 * 
	 * @see Actor#sleep(int)
	 */
	public void act() {
		while (true) {
			sleep(100000000);
		}
	}
	
	
	Play play;
	
	public void start() {
		String argv[] = new String[0]; 
		Actor a = new ShowShape(); 
		a.setDebugMode(true);
		play = Play.start(argv, a); 	
	}
	
	public static void main(String argv[]) {
		Play.main(argv, new ShowShape()); 
	}
}