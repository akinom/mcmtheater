/**
 * Created on Jul 22, 2005
 * 
 * RoundRobin Scheduler for Actors; The Actors use wait on themselves to wait
 * for their turn to run Actor's are assumed to supply a run method that in
 * short time intervals call Scheduler.yield to make way for another Actor to do
 * its work
 * 
 * @author Monika Mevenkamp
 */
package mcm.theater;

import java.lang.reflect.Array;
import java.util.LinkedList;
import java.util.ListIterator;

import mcm.utils.Assert;
import mcm.utils.MCMRuntimeException;
import mcm.utils.Trace;

class Scheduler {
	static Scheduler theScheduler;

	static final int traceLevel = 8;

	static String info(Thread a) {
		if (a instanceof ScheduledThread) {
			return ((ScheduledThread) a).info();
		} else {
			return "[" + a.getName() + "]";
		}
	}

	private WaitInfo waitInfo;

	private boolean allMustDie;

	private LinkedList threads; // list of WaitInfos

	private LinkedList unScheduledThreads; // list of WaitInfos

	private int curRound;

	private String name;

	protected Trace tracer;

	public Scheduler() {
		super();
		name = "VIRGIN";
		//Trace.global = new Trace("TRACESCHEDULER");
		tracer = Trace.global;
		curRound = 0;
		allMustDie = false;
		waitInfo = null;
		threads = new LinkedList();
		unScheduledThreads = new LinkedList();
		theScheduler = this;
	}

	protected void finalize() {
		tracer.traceMsg(this, "finalize ");
	}

	public synchronized void addThread(ScheduledThread thread) {
		Assert.check(waitInfo != null && waitInfo.thread != null);
		if (isNotScheduled(thread)) {
			unScheduledThreads.addLast(thread.waitInfo);
			return;
		}
		thread.setPriority(waitInfo.thread.getPriority());
		if (tracer.doTraceLevel(traceLevel))
			tracer.traceMsg(this, "addThread " + thread.getName());
		thread.waitInfo.setNext(this.waitInfo);
		if (!threads.isEmpty()) {
			((WaitInfo) threads.getLast()).setNext(thread.waitInfo);
		}
		threads.addLast(thread.waitInfo);
		thread.waitInfo.startResume = System.currentTimeMillis();
	}

	public synchronized WaitInfo getFirst(LinkedList list) {
		if (list.isEmpty())
			return null;
		WaitInfo wi = (WaitInfo) list.getFirst();
		return wi;
	}

	public static boolean isNotScheduled(Thread thread) {
		boolean isScheduled = false;
		try {
			isScheduled = ((ScheduledThread) thread).getScheduled();
		} catch (ClassCastException e) {
			isScheduled = true;
		}
		return !isScheduled;
	}


	synchronized ScheduledThread[] getThreads(ScheduledThread[] ts) {
		int len = threads.size() + unScheduledThreads.size();
		if (ts.length < len) {
			ts = (ScheduledThread[]) Array.newInstance(ScheduledThread.class,
					len);
		}
		int i = addThreads(ts, 0, threads);
		addThreads(ts, i, unScheduledThreads);
		return ts;
	}
	
	private int addThreads(ScheduledThread[] ts, int i, LinkedList threads) {
		ListIterator it = threads.listIterator();
		while (it.hasNext()) {
			WaitInfo wi = (WaitInfo) (it.next());
			if (wi.thread instanceof ScheduledThread) {
				ts[i] = (ScheduledThread) wi.thread;
				i++;
			}
		}
		if (i < ts.length) {
			ts[i] = null;
		}
		return i;
	}
	
	public synchronized int getThreadCount() {
		return threads.size() + unScheduledThreads.size();
	}

	public void startTicking(Thread thread, boolean doStart) {
		Assert.check(waitInfo == null);
		allMustDie = false;
		waitInfo = new WaitInfo(thread);
		waitInfo.startResume = System.currentTimeMillis();
		name = thread.getName();
		if (doStart)
			waitInfo.thread.start();
	}

	public void stop() {
		tracer.traceMsg(this, "> stop");
		allMustDie = true;
		runThem();
		Assert.check(getFirst(threads) == null);
		waitInfo = null;
		tracer.traceMsg(this, "< stop");
	}

	public void runThem() {
		if (tracer.doTraceLevel(traceLevel)) {
			tracer.traceMsg(this, "> runThem");
			listAll(tracer, "runThem:");
		}
		Assert.check(runThemInvariant());
		curRound++;
		// run all threads
		if (tracer.doTraceLevel(traceLevel))
			tracer.println("runThem nThreads=" + getThreadCount());
		WaitInfo first = getFirst(threads);
		if (first != null) {
			first.signal(waitInfo);
			waitInfo.doWait();
		}

		if (tracer.doTraceLevel(traceLevel))
			tracer.println("cleanThem nThreads=" + getThreadCount());
		// clean out those that died
		// none of the threads associated with waitInfos are executing right now
		// except for DrJava instances 
		WaitInfo lastAlive = null;
		WaitInfo ths = getFirst(threads);
		if (ths == null)
			return;
		while (ths != this.waitInfo) {
			if (!ths.isAlive()) {
				// clean it out
				if (lastAlive != null) {
					lastAlive.next = ths.next;
				}
				synchronized (this) {
					threads.remove(ths);
				}
				if (tracer.doTraceLevel(traceLevel))
					tracer.println(" clean up " + ths.name);
			} else {
				lastAlive = ths;
			}
			ths = ths.next;
		}
		if (tracer.doTraceLevel(traceLevel))
			tracer.println("nxtRound n=" + getThreadCount());
		Assert.check(runThemInvariant());
		if (tracer.doTraceLevel(traceLevel))
			tracer.traceMsg(this, "< runThem");
	}

	public boolean getAllMustDie() {
		return allMustDie;
	}

	public int getRound() {
		return curRound;
	}

	public String getName() {
		return name;
	}

	public String toString() {
		return getName() + " (#" + curRound + ")";
	}

	/**
	 * print info about all actors to tracer take care to either synchronize
	 * this call with other threads interacting with this Scheduler
	 */
	public synchronized void listAll(Trace tracer, String headline) {
		if (headline == null)
			headline = "";
		tracer.printMsg(this, headline + " size=" + getThreadCount()
				+ " curRound=" + curRound);

		int i = list(0, getFirst(threads));
		list(i, getFirst(unScheduledThreads));
	}

	private int list(int i, WaitInfo wi) {
		while (wi != null) {
			tracer.println("\t" + i + ": " + wi.toString());
			i++;
			wi = wi.getNext();
		}
		return i;
	}

	private String runThemInvariant() {
		if (waitInfo.thread == null) {
			return "Scheduler's waitInfo thread should never be null";
		}
		if (Thread.currentThread() != waitInfo.thread) {
			return "Invariant Check possible from Scheduler Thread only";
		}
		if (waitInfo.getNext() != null) {
			return "Scheduler thread must be last in queue";
		}
		if (waitInfo.waiting) {
			return "Scheduler runs; can't be in waiting mode";
		}

		WaitInfo li = null;
		WaitInfo wi = getFirst(threads);
		if (wi != null) {
			while (wi != waitInfo) {
				if (wi.thread == null) {
					return wi.name + " is dead and still in queue";
				}
				if (!(wi.thread instanceof ScheduledThread)) {
					return wi.name + " " + "is not a ScheduledThread";
				}
				if (li != null) {
					ScheduledThread lt = (ScheduledThread) li.thread;
					ScheduledThread wt = null;
					if (!(wi.thread instanceof ScheduledThread)) {
						return wi.name + " " + "is not a ScheduledThread";
					} else {
						wt = (ScheduledThread) wi.thread;
						if (lt.myId >= wt.myId) {
							return "ScheduledThreads are out of order:\n\t"
									+ lt.info() + "\n\t" + wt.info();
						}
					}
				}
				li = wi;
				wi = wi.getNext();
				if (wi == null) {
					return "Queue dos not loop back to Scheduler, ends after "
							+ li.name;
				}
			}
		}
		return null;
	}

	static class WaitInfo {
		private boolean waiting;

		private final Trace tracer;

		private Thread thread;

		private String name;

		private WaitInfo next;

		private long startWait;

		private long startResume;

		private long doSignal;

		private String signalWho;

		public WaitInfo(Thread t) {
			if (t == null) {
				throw new MCMRuntimeException("Internal Error: null thread");
			}
			thread = t;
			name = t.getName();
			waiting = false;
			next = null;
			if (t instanceof ScheduledThread) {
				tracer = ((ScheduledThread) t).tracer;
			} else {
				tracer = Trace.global;
			}
			startWait = -1;
			startResume = -1;
			doSignal = -1;
			signalWho = "NONE";
		}

		protected void doWait() {
			startWait = System.currentTimeMillis();
			if (Thread.currentThread() != thread) {
				if (Thread.currentThread() instanceof ScheduledThread) {
					throw new MCMRuntimeException(
							"May not suspend other threads/actors");
				} else {
					// This is called from a thread that is not part of the schduler's list
				}

			}

			synchronized (this) {
				waiting = true;
				while (waiting && thread != null) {
					// only non DrJava Actors and the scheduler itself actually
					// wait
					try {
						if (tracer.doTraceLevel(Scheduler.traceLevel))
							tracer.println("**WAIT** " + name);
						wait();
					} catch (InterruptedException ex) {
						if (tracer.doTraceLevel(traceLevel)) {
							Trace.report(thread.getName() + "WAIT interrupted");
							if (tracer.doTraceLevel(traceLevel + 1))
								Trace.report(ex);
						}
					}
				}
			}
			if (tracer.doTraceLevel(Scheduler.traceLevel))
				tracer.println("**RESUME** " + name);
			startResume = System.currentTimeMillis();
		}

		protected synchronized boolean isAlive() {
			return thread != null;
		}

		// called from thread to indicate that it is finishing
		protected void dying() {
			Assert.check(Thread.currentThread() == thread);
			if (tracer.doTraceLevel(traceLevel))
				tracer.traceln(thread + "I must die");
			Assert.check(Thread.currentThread() == thread);
			thread = null;
		}

		protected void signal(WaitInfo caller) {
			caller.doSignal = System.currentTimeMillis();
			caller.signalWho = this.getName();
			WaitInfo wi = this;
			while (true) {
				if (wi.thread == null) {
					if (tracer.doTraceLevel(traceLevel))
						tracer.println(Thread.currentThread().getName()
								+ " SKIP**DEAD**SIGNAL** " + name);
					wi = wi.next;
				} else {
					break;
				}
			}
			caller.signalWho = wi.getName();
			wi.signl();
		}

		private void signl() {
			Assert.check(thread != null);
			int nYields = 0;
			while (true) {
				synchronized (this) {
					if (waiting) {
						waiting = false;
						notify();
						break;
					}
				}

				// signalling failed the other end is not waiting yet
				try {
					if (tracer.doTraceLevel(traceLevel))
						tracer.println("**SIGNAL**MUST RETRY** " + name);
					Thread.sleep(1);
				} catch (InterruptedException e) {
					// try again
				}
				nYields++;
			}
			if (tracer.doTraceLevel(traceLevel))
				tracer.println("**SIGNAL**DONE #nYields" + nYields);
		}

		/**
		 * @return Returns the next.
		 */
		public WaitInfo getNext() {
			return next;
		}

		/**
		 * @param next
		 *            The next to set.
		 */
		public void setNext(WaitInfo next) {
			this.next = next;
		}

		/**
		 * @return name of associated thread
		 */
		public String getName() {
			return name;
		}

		synchronized public String toString() {
			String str = name + ":";
			if (thread == null) {
				str += " DEAD";
			}
			if (waiting) {
				str += " wait since " + (startWait % 10000);
			} else {
				str += " resumed at " + (startResume % 10000);
			}
			if (doSignal >= 0) {
				str += " last signal to " + signalWho + " at "
						+ (doSignal % 10000);
			}
			return str;
		}
	}

}
