package mcm.graphics;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;

import mcm.utils.Assert;
import mcm.utils.Utils;
import mcm.utils.MCMRuntimeException;

/**
 * Shape is the  base
 * class of all shapes used in mcm.graphics. They can be painted to Graphics contexts. 
 * {@link Body} objects use shapes to draw themselves at their current positions. 
 * <p>
 * Shapes have a width, height, color, line width, and hotSpot mode attribute.
 * Derived shapes are expected to be drawn within the rectangle defined by their width and height. 
 * </p>
 * <p>
 * Shape's have two drawing methods: paint and draw.
 * A shape's paint method draws its shape such that the lower left corner of its drawing rectangle 
 * lies at the origin 
 * of the coordinate system defined by the graphics context to which it is drawn. 
 * A shape's draw method draws its shape such that its hot spot point appears at  the 
 * origin of the coordinate system.
 * Derived shapes need to implement their own paint methods. They are expected to paint such 
 * that the lower left corner 
 * appears at (0,0) and the upper right corner at (getWidth(), getHeight()), 
 * and the shape's drawing stays within the 
 * rectangular area defined by these two points.
 * </p> 
 * <p> 
 * A shape's hot spot point is updated according to its width, height, and hot spot mode, 
 * whenever any of these are changed. If a shape's hotSpot mode, for example, equals
 * CENTER its hot spot point is kept at the point (getWidth()/2, geteEight()/2). 
 * If its mode equals LOWER_LEFT or UPPER_RIGHT) its hot spot point 
 * is set to (0,0) or (getWidth(), getHeight()) respectively, see 
 * {@link mcm.graphics.Shape#setHotSpot(int)}and
 * {@link mcm.graphics.Shape#setHotSpotPoint(Point)}.
 * </p>
 */
public class Shape {
	
	/**
	 * Ease-of-use constant for {@link #setHotSpot(int)}.
	 */
	public static final int CENTER = 0;

	/**
	 * Ease-of-use constant for {@link #setHotSpot(int)}.
	 */
	public static final int FIXED_POINT = 9;

	/**
	 * Ease-of-use constant for {@link #setHotSpot(int)}.
	 */
	public static final int LOWER_CENTER = 5;

	/**
	 * Ease-of-use constant for {@link #setHotSpot(int)}.
	 */
	public static final int LOWER_LEFT = 3;

	/**
	 * Ease-of-use constant for {@link #setHotSpot(int)}.
	 */
	public static final int LOWER_RIGHT = 4;

	/**
	 * Ease-of-use constant for {@link #setHotSpot(int)}.
	 */
	public static final int MIDDLE_LEFT = 7;

	/**
	 * Ease-of-use constant for {@link #setHotSpot(int)}.
	 */
	public static final int MIDDLE_RIGHT = 8;

	/**
	 * Ease-of-use constant for {@link #setHotSpot(int)}.
	 */
	static final int UNDEFINED = -1;

	/**
	 * Ease-of-use constant for {@link #setHotSpot(int)}.
	 */
	public static final int UPPER_CENTER = 6;

	/**
	 * Ease-of-use constant for {@link #setHotSpot(int)}.
	 */
	public static final int UPPER_LEFT = 1;

	/**
	 * Ease-of-use constant for {@link #setHotSpot(int)}.
	 */
	public static final int UPPER_RIGHT = 2;

	/**
	 * Returns a string representation of the given hotsSpotMode. 
	 */
	public static String toModeString(int hotSpotMode) {
		switch (hotSpotMode) {
		case CENTER:
			return "CENTER";
		case UPPER_LEFT:
			return "UPPER_LEFT";
		case UPPER_RIGHT:
			return "UPPER_RIGHT";
		case LOWER_LEFT:
			return "LOWER_LEFT";
		case LOWER_CENTER:
			return "LOWER_CENTER";
		case UPPER_CENTER:
			return "UPPER_CENTER";
		case LOWER_RIGHT:
			return "LOWER_RIGHT";
		case MIDDLE_LEFT:
			return "MIDDLE_LEFT";
		case MIDDLE_RIGHT:
			return "MIDDLE_RIGHT";
		case FIXED_POINT:
			return "FIXED_POINT";
		}
		return "UNKNOWN";
	}

	/** 
	 * the debug mode, see paint
	 */
	private boolean debug; 

	/**
	 * The shape's drawing attributes
	 */
	Color fgColor;

	/**
	 * The shape's current height.
	 */
	double height;

	/**
	 * The shape's current hotSpot point.
	 */
	Point hotSpot;

	/**
	 * The shape's current hotSpot mode
	 */
	int hotSpotMode = FIXED_POINT;
	
	/** 
	 * cached stroke for lineWidth 
	 */
	BasicStroke lineStroke = new BasicStroke(); 
	
	/** 
	 * width of stroke for drawing 
	 */
	int lineWidth;
	
	/**
	 * rect that describes shape's frame 
	 */
	private Rectangle2D.Double rect; 
	
	/** 
	 * hot spot translation 
	 */
	AffineTransform translate = new AffineTransform(); 
	
	/** 
	 * cached transformation for hot spot setting 
	 */
	AffineTransform translateInv = new AffineTransform(); 
	
	/**
	 * The shape's current width.
	 */
	double width;

	/**
	 * Constructs a new shape object. It has an undefined hotSpotMode and zero
	 * width and height
	 */
	protected Shape() {
		this.debug = false;
		this.width = 0;
		this.height = 0;
		hotSpot = new Point(0, 0);
		hotSpotMode = UNDEFINED;
		fgColor = new Color(1f, 0f, 0, 0.8f);
		lineWidth = 1;
		rect = new Rectangle2D.Double(0, 0, width, height);
	}
	
	/** 
	 * Constructs a newly shape object. 
	 * Its color is set to a slightly transparent red amd its lineWidth is 1. 
	 * 
	 * @param width  the new shape's width in pixels 
	 * @param height the new shape's height in pixels 
	 * @param alignment the new shape's alignment
	 */
	protected Shape(double width, double height, int alignment) {
		this(); 
		this.width = width;
		this.height = height;
		setHotSpot(alignment);
	}
	
    /** 
     * Creates and returns a copy of this shape.
     */
	protected Object clone() 
	{ 
		Shape s = new Shape(width, height, hotSpotMode);
		s.cloneProps(this); 
		return s; 
	}
	
	/** 
	 * Copy template's color and lineWidth properties into this object 
	 * @param template Shape from which to copy property values
	 */
	protected void cloneProps(Shape template) 
	{
		width = template.width;
		height = template.height;
		if (template.hotSpotMode == FIXED_POINT) {
			hotSpotMode = FIXED_POINT;
			hotSpot = new Point(hotSpot);
		} else {
			computeHotSpot(template.hotSpotMode); 
		}
		setColor(template.fgColor); 
		setLineWidth(template.getLineWidth()); 
		debug = template.debug;
	}
	
	/**
	 * Computes the shape's hotSpot in dependance of the given mode. Returns the
	 * computed hotSpot Point if the given hotSpot mode is valid.
	 * 
	 * @param mode
	 *            a hotSpot mode
	 */
	 protected void computeHotSpot(int mode) {
	 	hotSpot = getHotSpot(mode, hotSpot); 	
		hotSpotMode = mode;
		translate.setTransform(1, 0, 0, 1, -hotSpot.x, -hotSpot.y); 
		translateInv.setTransform(1, 0, 0, 1, hotSpot.x, hotSpot.y); 
		rect.x = -hotSpot.x; 
		rect.y = -hotSpot.y; 
		rect.width = width;; 
		rect.height = height; 
		
	}
	
	/** 
	 * Checks whether (x,y) lies in the interior of this shape. 
	 * The (x,y) coordinates are intepreted relative to the shape's hot spot.
	 * The shape is assumed to cover a rectangular area defined by the lower left point 
	 * (-hostSpot.x, -hotSpot.y)  and the shape's width and height. 
	 * 
	 * @param x x coordinate
	 * @param y  y coordinate
	 * @return <code>true</code> if (x,y) lies within the shape's area, <code>false</code> otherwise
	 */
	public boolean contains(double x, double y) 
	{		
		return getShape().contains(x + hotSpot.x , y + hotSpot.y); 
	}
	
	/**
	 * Retunrs a Rectangle2D.Double  shape describing this shape's drawing area. 
	 * The rectagle shape is defined by the lower left corner 
	 * (-hotspot.x, -hotSpot.y) and the shape's width and height. 
	 * 
	 * Derived classes should overwrite this method to return more suitable awtShapes.
	 */
	protected java.awt.Shape getShape() {
		return rect;
	}
	
	/** 
	 * Paints the given shape such that its hot spot appears at the given point. 
	 * 
	 * @param x x coordinate of point 
	 * @param y y coordinate of point
	 * @param gr  
	 * 			the graphics context to draw to
	 */
	public void draw(double x, double y, Graphics2D gr) {

		AffineTransform t = gr.getTransform(); 
		gr.translate(x, y); 
		gr.transform(translate);
		paint(gr); 
		gr.setTransform(t);
	}
	
	/** 
	 * Draws this shape such that its hotspot appears at (0,0) 
	 * 
	 * @param gr the graphics context to draw to 
	 */
    public void draw(Graphics2D gr)
	{
		gr.transform(translate);
		paint(gr);
		gr.transform(translateInv);
	}
	
	/** 
	 * Paints the given shape such that its hot spot appears at the given point. 
	 * 
	 * @param p    
	 * 			position of the shape's lower left corner 
	 * @param gr  
	 * 			the graphics context to draw to
	 */
	public void draw(Point p, Graphics2D gr)
	{
		draw(p.x, p.y, gr); 
	}
	
	/**
	 * Creates a clone of this Shape and returns it. 
	 * 
	 * @return a copy of this object 
	 */
	public Shape getClone() {
		return (Shape) clone(); 
	}
	 

	/**
	 * Returns the shape's color.
	 * 
	 * @return the pen color
	 */
	public Color getColor() {
		return fgColor;
	}
	
	/** 
	 * Returns the shape's debug mode. 
	 */
	public boolean getDebug()
	{
		return debug;
	}

	/**
	 * Returns the shape's current height in pixels.
	 * 
	 * @return the height
	 */
	public double getHeight() {
		return height;
	}

	/**
	 * Returns the shape's current hotSpot mode.
	 * 
	 * @return the current hotSpot mode
	 */
	public int getHotSpot() {
		return hotSpotMode;
	}
	 
	 private Point getHotSpot(int mode, Point global) 
	 {
	 	Point hp = global; 
	 	if (hp == null) 
	 		hp = new Point(); 
	 	
		switch (mode) {
		case CENTER:
			hp.setLocation(width / 2, height / 2);
			break;
		case UPPER_LEFT:
			hp.setLocation(0, height);
			break;
		case UPPER_RIGHT:
			hp.setLocation(width, height);
			break;
		case LOWER_LEFT:
			hp.setLocation(0, 0);
			break;
		case LOWER_CENTER:
			hp.setLocation(width / 2, 0);
			break;
		case UPPER_CENTER:
			hp.setLocation(width / 2, height);
			break;
		case LOWER_RIGHT:
			hp.setLocation(width, 0);
			break;
		case MIDDLE_LEFT:
			hp.setLocation(0, height / 2);
			break;
		case MIDDLE_RIGHT:
			hp.setLocation(width, height / 2);
			break;
		case FIXED_POINT:
			if (hotSpot == null) {
				throw new MCMRuntimeException("Must set hotSpot point by calling setHotSpotPoint()");
			}
			hp = hotSpot;
			break;
		default:
			throw new MCMRuntimeException("invalid hotSpot mode");
		}
		return hp; 
	 }

	/**
	 * Returns the shape's hotSpot point.
	 * 
	 * @return the hotSpot.
	 */
	public Point getHotSpotPoint() {
		return new Point(hotSpot);
	}

	/**
	 * Returns the shape's line width.
	 * 
	 * @return the pen width
	 */
	public int getLineWidth() {
		return lineWidth;
	}

	/**
	 * Returns the coordinates of the point at the given alignment position relative to this shape's hotSpot. 
	 * 
	 * The alignment value indicates which point's coordinates are requested.
	 * Returns the computed coordinates in <code>global</code> if non null or in a newly 
	 * allocated point. 
	 * 
	 * @param alignment all alignment values, except FIXED_POINT
	 * @param global  null or reference to a point 
	 * @return global, if not null, or newly allocated point	 
	 */
	public Point getPos(int alignment, Point global) {
		Point p = getHotSpot(alignment, global); 
		p.x = p.x -hotSpot.x; 
		p.y = p.y -hotSpot.y;
		return p;	
	}

	/** 
	 * Returns the BasicStroke for the current line width. 
	 * @return the BasicStroke for the current line width. 
	 */
	protected BasicStroke getStroke() { return lineStroke; } 
	
	/**
	 * Returns the shape's current width in pixels.
	 * 
	 * @return the current width
	 */
	public double getWidth() {
		return width;
	}
	
	/**
	 * Returns a string representation of this shape's hot spot mode.
	 * @return a string describing the hot spot mode
	 */
	public  String hotSpotToString() {
		if (hotSpotMode == FIXED_POINT) { 
			return toModeString(FIXED_POINT) + " " + hotSpot.toString(); 
		}
		return toModeString(hotSpotMode);
	}
	
  
	/**
	 * Paints this shape to the given graphics context.
	 * This implementation of paint simply draws a frame around the shape's drawing area. 
	 * Derived classes must implement this method, such that the shape is painted to
	 * the given graphics context in a way that (0,0) coincides with the lower left 
	 * of the shape's drawing. 
	 * 
	 * @param g2D
	 *            the graphics context to draw to
	 */
	public void paint(Graphics2D g2D)
	{
		Assert.check(g2D != null); 
        g2D.setColor(fgColor);
        g2D.setStroke(lineStroke); 
        if (debug)
        	g2D.draw(new Rectangle2D.Double(0, 0, width, height)); 
 	}

	/**
	 * Sets the shape's color.
	 * 
	 * @param color
	 *            the new color
	 */
	public void setColor(Color color) {
		fgColor = color;
	}
    
	/** 
	 * Sets the shape's debug mode. 
	 * Shapes draw a rectangle around their drawing area when debug is set to <code>true</code>.
	 * @param debug debug mode 
	 */
	public void setDebug(boolean debug) 
	{
		this.debug = debug; 
	}

	/**
	 * Sets the shape's height in pixels; height must be greater than 0. The
	 * same as calling setSize(getWidth(), height).
	 * 
	 * @param height
	 *            the new width; must be greater zero
	 */
	public void setHeight(double height) {
		setSize(this.width, height);
	}

	/**
	 * Sets the shape's hotSpot mode.
	 * <p>
	 * A shape's hotSpot mode determines how its lower left corner is positioned
	 * relative to a given paint position. A shape's hotSpot mode determines the
	 * value of a shape's hotSpot point which is adjusted whenever ths shape's
	 * size is changed.
	 * </p>
	 * <p>
	 * The available modes are: <BR>
	 * <DL>
	 * <DT>CENTER
	 * <DD>put the shape's center at the paint position
	 * <DT>UPPER_LEFT
	 * <DD>put the shape's upper left corner at the paint position
	 * <DT>UPPER_RIGHT
	 * <DD>put the shape's upper right corner at the paint position
	 * <DT>LOWER_LEFT
	 * <DD>put the shape's lower left corner at the paint position
	 * <DT>LOWER_RIGHT
	 * <DD>put the shape's lower right corner at the paint position
	 * <DT>LOWER_CENTER
	 * <DD>put the shape's midpoint on its lower side at the paint position
	 * <DT>UPPER_CENTER
	 * <DD>put the shape's midpoint on its upper side at the paint position
	 * <DT>MIDDLE_LEFT
	 * <DD>put the shape's midpoint on its left side at the paint position
	 * <DT>MIDDLE_RIGHT
	 * <DD>put the shape's midpoint on its right side at the paint position
	 * <DT>FIXED_POINT
	 * <DD>put the shape's hotSpot at the paint position.
	 * </DL>
	 * </p>
	 * 
	 * @param mode
	 *            the new hotSpot mode
	 *  
	 */
	public void setHotSpot(int mode) {
		if (mode != this.hotSpotMode) {
			if (mode == FIXED_POINT) {
				hotSpotMode = FIXED_POINT;
				// leave point as is
			}

			computeHotSpot(mode);
		}
	}

	/**
	 * Sets the shape's hotSpot point to the given point and its hotSpot mode to
	 * FIXED_POINT. When this shape is resized it's hotSpot point is <b>not </b>
	 * adjusted.
	 * 
	 * @param hotSpotPoint
	 *            the new hotSpot to set.
	 * 
	 * @link #setHotSpot(int)
	 */
	public void setHotSpotPoint(Point hotSpotPoint) {
		if (hotSpotPoint == null)
			throw new NullPointerException("null hotSpot Point");
		this.hotSpot = new Point(hotSpotPoint);
		computeHotSpot(FIXED_POINT); 
	}

	/**
	 * Sets the shape's line width.
	 * 
	 * @param lineWidth
	 *            the new width
	 */
	public void setLineWidth(int lineWidth) {
		this.lineWidth = lineWidth; 
		lineStroke = new BasicStroke(lineWidth);
	}

	/**
	 * Sets the new dimension to be width and height measured in pixels. Adjusts
	 * the hotSpot point as necessary. The hotSpot point remains unchanged if
	 * the hotSpot mode equals FIXED_POINT.
	 * 
	 * @param width
	 *            new width; must be greater zero
	 * @param height
	 *            new height; must be greater zero
	 */
	public void setSize(double width, double height) {
		if ((width < 0) || (height < 0)) {
			throw new RuntimeException("Width amd height must be greater 0.");
		}
		this.width = width;
		this.height = height;
		computeHotSpot(hotSpotMode);
	}

	/**
	 * Sets the shape's width in pixels; width must be greater than 0. The same
	 * as calling setSize(width, getHeight()).
	 * 
	 * @param width
	 *            the new width; must be greater zero
	 */
	public void setWidth(double width) {
		setSize(width, this.height);
	}

	/**
	 * Returns a string representation of this shape. 
	 * 
	 * The string constists of the
	 * shape's unqualified class name followed by its current width and height
	 * and hotSpot information.
	 */
	public String toString() {
		return Utils.shortClassName(this) + "(" + width + "," + height + ") "
				+ hotSpotToString();
	}
	
}
