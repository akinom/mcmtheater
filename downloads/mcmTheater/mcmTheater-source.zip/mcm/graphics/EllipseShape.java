package mcm.graphics;

import java.awt.geom.Ellipse2D;


/**
 * An ellipse shape.
 */
public class EllipseShape extends FillableShape {

	/**
	 * Constructs an elliptical shape. 
	 * It has the given width, height and fill status.  
	 * Its hotSpot mode is set to {@link Shape#CENTER}.
	 * 
	 * @param width the shape's width 
	 * @param height the shape's height
	 */
	public EllipseShape(double width, double height, boolean filled) {
		super(filled); 
		setHotSpot(CENTER); 
		setShape(new Ellipse2D.Double(0, 0, width, height)); 	
		setSize(width, height); 
	}
	
    /** 
     * Creates and returns a copy of this shape.
     */
	protected Object clone() 
	{ 
		Shape s = new EllipseShape(width, height, isFilled());
		s.cloneProps(this); 
		return s; 
	}

	public void setSize(double width, double height) 
	{
		Ellipse2D.Double rect = (Ellipse2D.Double) awtShape; 
		rect.setFrame(0, 0, width, height); 
		super.setSize(width, height); 
	}
}
