package mcm.graphics;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.NoninvertibleTransformException;
import java.lang.reflect.Constructor;
import java.text.DecimalFormat;

import mcm.utils.Assert;
import mcm.utils.Utils;
import mcm.utils.MCMRuntimeException;
import mcm.utils.Trace;

/**
 * <p>
 * Bodys are used to draw shapes to a graphics context. 
 * Bodys have a position, a rotation angle, and a reference to a {@link Shape}, 
 * </p>
 * <p>
 * A body's draw method draws its shape such that the shape's hot spot 
 * appears at its current position and the shape's baseline is oriented along its 
 * movement direction. More formually: Each body has its own coordinate system whith its 
 * origin at the body's current position. The coordinate system is rotated according to the 
 * body's direction angle. A body draws itself such that its shape's hotspot appears at the 
 * origin of its coordinate system. 
 * </p>
 */
public class Body {

	/** 
	 * Ease-of-use constant for {@link #setMapDirection(int)}.
	 */
	public static int EAST;

	/** 
	 * angles corresponding to NORTH, EAST, ... constants 
	 */
	private static int mapAngle[];

	/**
	 * number of instances constructed
	 */
	static private int nInstances = 0;

	/** 
	 * Ease-of-use constant for {@link #setMapDirection(int)}.
	 */
	public static int NORTH;

	/** 
	 * Ease-of-use constant for {@link #setMapDirection(int)}.
	 */
	public static int NORTHEAST;

	/** 
	 * Ease-of-use constant for {@link #setMapDirection(int)}.
	 */
	public static int NORTHWEST;

	/** 
	 * Ease-of-use constant for {@link #setMapDirection(int)}.
	 */
	public static int SOUTH;

	/** 
	 * Ease-of-use constant for {@link #setMapDirection(int)}.
	 */
	public static int SOUTHEAST;

	/** 
	 * Ease-of-use constant for {@link #setMapDirection(int)}.
	 */
	public static int SOUTHWEST;

	/** 
	 * The trace level at which movement/jump actions are traced. 
	 * The level is initialized to 4.
	 */
	static protected int traceLevel = 4;
	private static Point transFromLocalPoint = new Point(); 
	
	private static Point transToLocalPoint = new Point(); 

	/** 
	 * Ease-of-use constant for {@link #setMapDirection(int)}.
	 */
	public static int WEST;

	static {
		mapAngle = new int[8];
		int ndir = 0;
		mapAngle[ndir] = 45;
		NORTHEAST = ndir;
		ndir++;
		mapAngle[ndir] = 90;
		NORTH = ndir;
		ndir++;
		mapAngle[ndir] = 135;
		NORTHWEST = ndir;
		ndir++;
		mapAngle[ndir] = 180;
		WEST = ndir;
		ndir++;
		mapAngle[ndir] = 225;
		SOUTHWEST = ndir;
		ndir++;
		mapAngle[ndir] = 270;
		SOUTH = ndir;
		ndir++;
		mapAngle[ndir] = 315;
		SOUTHEAST = ndir;
		ndir++;
		mapAngle[ndir] = 0;
		EAST = ndir;
		ndir++;
	}
	
	private Point containsPoint = new Point(); 

	/**
	 * this <code>Body</code>'s movement direction
	 * 
	 * @see #move
	 * @see #moveTo
	 *  
	 */
	volatile Point direction;

	/**
	 * this <code>Body</code>'s movement direction expressed as an Angle in
	 * degrees
	 */
	volatile double directionAngle;

	/**
	 * this <code>Body</code>'s movement direction expressed in radians
	 */
	volatile double directionAngleRad;

	/**
	 * indicates whether shapes are rotated according to body's direction
	 */
	private boolean doesRotateShape;


	/** 
	 * Returns the inverse of this body's transformation. 
	 */
	AffineTransform invTransform; 

	/** 
	 * this <code>Body</code>'s name
	 */
	private String name;

	/**
	 * this <code>Body</code>'s current position on its
	 * @link Stage
	 */
	volatile Point pos;

	/**
	 * this <code>Body</code>'s 
	 * @link Shape
	 */
	volatile Shape shape;


	/** 
	 * a cached transformation corresponding to the body's current position and
	 * direction
	 */
	protected volatile AffineTransform shapeTransform;

	/**
	 * May be used for tracing purposes.
	 * By default tracer refers to {@link Trace#global}.
	 */
	protected Trace tracer;

	/**
	 * <code>visible</code> indicates whether this <code>Body</code>'s 
	 * 
	 * @link shape is visible
	 */
	private volatile boolean visible;

	/**
	 * Constructs a new body object. 
	 * This constructor has the same effect as Body(null).
	 */
	public Body() {
		this(null);
	}


	/**
	 * <p> 
	 * Constructs a new body object. 
	 * </p><p>
	 * The new body receives a default name of the form 
	 * &lt;Class&gt;#&lt;id&gt;, where 
	 * &lt;Class&gt; is the body's unqualified class name and 
	 * &lt;id&gt; a unique positive integer number. 
	 * </p><p>
	 * If <code>template</code> equals <code>null</code> 
	 * default values are used to initialize properties:
	 * <blockquote>
	 * <TABLE cellspacing=4px>
	 *      <TR><TD> position </TD><TD> (0,0)</TD><TD> see {@link  Body#jumpTo(Point)} </TD></TR>
	 *      <TR><TD> direction </TD><TD> 0</TD><TD> see {@link  #setDirection(double)}  </TD></TR> 
	 * 		<TR><TD> visibility </TD><TD> <code>true</code> </TD><TD> see {@link  #setVisible(boolean)}  </TD></TR>
	 *      <TR><TD> shape rotation mode </TD><TD> <code>true</code> </TD><TD> see {@link  Body#jumpTo(Point)} </TD></TR>
	 * 	    <TR><TD> shape </TD><TD> {@link DirectionShape}(20,20) </TD><TD> see {@link  #setShape}  </TD></TR>
	 * </TABLE>
	 * </blockquote>
	 * If a non null 
	 * <code>template</code>  is given properties are copied from the given <code>template</code> body.
	 * The new body receives a copy of (not a reference to) the template's shape.
	 * </p>
	 * 
	 * @param template
	 *            the body from which to template properties
	 */
	public Body(Body template) {
		synchronized (Body.class) {
				name = Utils.shortClassName(this) + "#" + nInstances;
				nInstances++;
		}
		tracer = Trace.global;
		// tracer = new Trace("TRACE" + ScheduledThread.getNumInstances());
		// tracer.setOptions(Trace.global);
		if (tracer.doTraceLevel(traceLevel)) 
			tracer.traceln(this.getName() + " Body.Body()"); 
		copyProps(template); 
	}

	/** 
	 * Creates a copy of this body by calling the default constructor. 
	 * The copy's name is set to <code>this.getName() + "*"</code>.
	 * The cloned body has the same type and properties as this body. 
	 * Its shape is a copy of (not a reference) to this object's shape. 
	 */
	protected Object clone() 
	{
		Constructor constr;
		Body b = null;
		
		for (Class cls = getClass(); cls != Body.class; cls = cls
				.getSuperclass()) {
			try {
				constr = getClass().getConstructor(null);
				b = (Body) constr.newInstance(null);
				break;	
			} catch (Exception e) {
				// try superclass
			}
		}
		if (b == null) {
			b = new Body(); 
		}
		b.copyProps(this);
		b.setName(getName() + "*");
		return b; 	     
	}
	/** 
	 * Checks whether the interior of this body's shape contains the point (x,y). 
	 * Assumes that the shape is positioned according to this body's current position, 
	 * direction, and shape rotation mode.
	 * 
	 * @param x  x coordinate
	 * @param y  y coordinate
	 * @return <code>true</code> if (x,y) lies within the shape's area, <code>false</code> otherwise
	 */
	public boolean contains(double x, double y) 
	{
		transToLocal(x, y, containsPoint); 
		return getShape().contains(containsPoint.x, containsPoint.y); 
	}
	
	/** 
	 * The same as contains(pos.x, pos.y)
	 */
	public boolean contains(Point pos) 
	{
		return contains(pos.x, pos.y); 
	}

	/** 
	 * Copies template's properties into this body. 
	 * The copied properties are: position, direction, visibility, and shape rotation mode. 
	 * This body receives a copy of (not a reference to) the template's shape. 
	 * 
	 * @param template a non null body 
	 */
	public void copyProps(Body template) {
		pos = new Point(0.0, 0.0);
		direction = new Point();
		setDirection(0); 
		
		if (template == null) {
			visible = true;
			doesRotateShape = true;
			DirectionShape s = new DirectionShape(20, 20);
			setShape(s);
			s.setColor(new Color(1.0f, 0.0f, 0.0f, 0.8f));
			s.setLineWidth(1);			
			tracer = Trace.global;
		} else {
			pos.setLocation(template.pos.x, template.pos.y);
		    direction.setLocation(template.direction);
			directionAngle = template.directionAngle;
			visible = template.visible;
			doesRotateShape = template.doesRotateShape;
			shape = template.shape.getClone();
		}
		if (tracer.doTraceLevel(traceLevel))
			tracer.traceMsg(this, "Body.copyProps(" + template +")"); 
	}

	/** 
	 * Draws this body's shape to the given graphics context at the current position.
	 * 
	 * draw first transforms the given graphics context's coordinate system 
	 * according to this body's position, direction, and 
	 * shape rotation mode so that the hotSpot point of its shape is mapped to the 
	 * point (0,0). It then calls paint, and finally restores the graphics context to its
	 * orignal coordinate transformation. 
	 * 
	 * @param g the graphics context to draw to 
	 */
	public void draw(Graphics2D g) {
		AffineTransform f = g.getTransform();
		g.transform(getTransform());
		paint(g);
		g.setTransform(f);
	}

	/**
	 * Returns the body's current direction angle.
	 * 
	 * @return the current direction as angle in degrees.
	 */
	public double getDirection() {
		return directionAngle;
	}

	/**
	 * Returns a point corresponding to the body's current direction. 
	 * @return  delta.x, delta.y, so that delta.y/delta.x is the slope of body's movement direction
	 * @see Body#setDirection(double, double)
	 */
     Point getDirectionPoint() {
		Point dir = new Point();
		dir.setLocation(direction);
		return dir;
	}

	/**
	 * Returns the body's current direction angle. 
	 * 
	 * @return the current direction as angle in radians.
	 */
	public double getDirectionRad() {
		return directionAngleRad;
	}
	
	/**
	 * Returns the inverse of this shape's current transformation. 
	 * 
	 *  @return the inverse of getTransform() 
	 */
	protected AffineTransform getInvTransform() 
	{
		if (invTransform == null) {
			AffineTransform f = getTransform();
			try {
				invTransform = f.createInverse();
			} catch (NoninvertibleTransformException e) {
				e.printStackTrace();
				throw new MCMRuntimeException("Should never happen");
			}
		}
		return invTransform;
	}

	/**
	 * Returns the body's name. 
	 */
	public String getName() {
		return name;
	}

	/**
	 * Returns the body's current position.
	 * @return the current position
	 */
	public Point getPos() {
		return (Point) pos.clone();
	}


	/**
	 * Returns the x coordinate of the current position.
	 * @return the x coordinate of this body's current position 
	 */
	public double getPosX() {
		return pos.x;
	}
	
	/**
	 * Returns the y coordinate of the current position.
	 * @return the x coordinate of this body's current position 
	 */
	public double getPosY() {
		return pos.y;
	}


	/**
	 * Returns a reference to the body's shape. 
	 * 
	 * @return the body's shape.
	 */
	public Shape getShape() {
		return shape;
	}

	/**
	 * Returns a reference to this body's Trace object.
	 * @return this body's Trace object
	 */
	public Trace getTracer() {
		return tracer;
	}

	/** 
	 * Returns this body's transformation.
	 * 
	 * Each body has its own coordinate system with the origin at its current position.
	 * If the body's shape rotation mode is set to <code>true</code> its coordinate system 
	 * is rotated according to its direction. 
	 * getTransform() returns a transformation that transforms points into the logical 
	 * coordinates of this body's coordinate system.
	 * 
	 * @return this body's tranformation
	 */
	protected AffineTransform getTransform() {
		if (shapeTransform == null) {
			double tx = getPosX();
			double ty = getPosY();
			shapeTransform = new AffineTransform();
			shapeTransform.translate(tx, ty);
			if (doesRotateShape) {
				shapeTransform.rotate(directionAngleRad);
			}
		}
		return shapeTransform;
	}

	//---------------------------------------------------------------------------------------------------

	/** 
	 * Retunrs the point dist away from the body's current position. 
	 * The returned point is computed as: 
	 * <blockquote>
	 *   newx = curx + dist * cos(angle) <BR> 
	 *   newy = cury + dist * sin(angle) <BR> 
	 * </blockquote>
	 * where angle is the angle of this body's current moevement direction.
	 * 
	 * @return the point (newx, newy) 
	 */
	public Point gotoPos(double dist) {
		Point gotoPos = new Point();
		double dx = dist * direction.x;
		double dy = dist * direction.y;
		gotoPos.setLocation((pos.x + dx), (pos.y + dy));
		return gotoPos;
	}
	
	/**
	 * Checks whether the body's shape is visible. 
	 * 
	 * @return <code> true</code> if shape is visisble; <code>false</code> otherwise. 
	 */
	public boolean isVisible() {
		return visible;
	}

	/**
	 * Jump the given distance from the current position in the current movement direction. 
	 * The body's position is set to the point at the 'end of the jump'.
	 */
	public void jump(double dist) {
		jumpTo(gotoPos(dist));
	}

	/**
	 * Sets the body's position to point <code>(tox, toy)</code>. 
	 * @param tox the destination point's x coordinate  
	 * @param toy the destination point's y coordinate  
	 */
	public void jumpTo(double tox, double toy) {
		if (tracer.doTraceLevel(traceLevel))
			tracer.traceMsg(this, "jumpTo (" + tox + "," + toy + ")");

		Assert.check(pos != null);
		setPos(tox, toy);
	}

	/**
	 * Sets the body's position to the given point. 
	 * @param to the body's new position 
	 */
	public void jumpTo(Point to) {
		jumpTo(to.x, to.y);
	}

	/** 
	 * Changes movement direction by turning <code>angle</code> degrees to the left. 
	 * <BR>This has the same effect as setDirection(getDirection() + angle).
	 * 
	 * @param angle the turning angle in degrees 
	 */
	public void left(double angle) {
		setDirection(directionAngle + angle);
	}

	/** 
	 * Paints the body's shape such that its hotSpot appears at (0,0). 
	 * 
	 * @param g the graphics context to draw to 
	 */
	public void paint(Graphics2D g) {
		shape.draw(g);
	}

	/** 
	 * Changes movement direction by turning <code>angle</code> degrees to the right. 
	 * <BR>This has the same effect as setDirection(getDirection() - angle).
	 * 	 
	 * @param angle the turning angle in degrees 
	 */
	public void right(double angle) {
		setDirection(directionAngle - angle);
	}

	/**
	 * Checks whether shape is rotated according to movement direction.
	 * 
	 * @return <code> true</code> if shape is rotated; <code>false</code> otherwise. 
	 */
	public boolean rotatesShape() {
		return doesRotateShape;
	}

	//-----------------------------------------------------------------------------------------
	/*
	 * setting the body's movement direction
	 */
	/** 
	 * Sets the body's movement direction in degrees. 
	 * <p>
	 * A movement angle of
	 * <UL>
	 * <LI> 0 -- means movement direction is to the right. </LI>
	 * <LI> 90 -- means movement direction is up wards. </LI>
	 * <LI> 180 -- means movement direction is to the left. </LI>
	 * <LI> 270 -- means movement direction is down wards. </LI>
	 * </UL> 
	 * All values in between are interpreted as acccordingly. 
	 * </p> 
	 * @param angle the movement angle given in degrees 
	 */
	public void setDirection(double angle) {

		directionAngle = angle;
		angle = angle % 360;
		if (angle < 0) {
			angle = 360 + angle;
		}
		directionAngleRad = (Math.PI * (double) angle) / 180D;
		double x = Math.cos(directionAngleRad);
		double y = Math.sin(directionAngleRad);
		direction.setLocation(x, y);
		shapeTransform = null;
		invTransform = null;
	}

	/** 
	 * Sets the direction angle so that the body moves along a line with slope dx / dy.
	 * The body is directed towards the point defined by (currentPos.x + dx, currentPos.y + dy), 
	 * where currentPos is the body's current position.
	 * 
	 * @param dx delta x for slope definition 
	 * @param dy delta y for slope definition 
	 */
	protected void setDirection(double dx, double dy) {
		double sqr = dx * dx + dy * dy;
		if (sqr == 0) {
			throw new MCMRuntimeException("Can not set direction: "
					+ "dx and dy are zero.");
		}

		double rad = Math.acos(dx / Math.sqrt(sqr));
		double directionAngle = ((180D * rad) / Math.PI);
		if (dy < 0) {
			directionAngle = 360 - directionAngle;
		}
		setDirection(directionAngle);
	}

	/**
	 * Sets the body's movement direction. 
	 * 
	 * The avaailable modes are: <BR>
	 * <DL> 
	 * 	<DT> NORTH  <DD> movement direction to the North/up wards. 
	 * 	<DT> EAST  <DD> movement direction to the East/right. 
	 * 	<DT> SOUTH  <DD> movement direction to the South/down wards. 
	 * 	<DT> WEST  <DD> movement direction to the West/left. 
	 * 	<DT> NORTHEAST <DD> movement direction to the Northeast.
	 * 	<DT> SOUTHEAST <DD> movement direction to the Southeast.
	 * 	<DT> NORTHWEST <DD> movement direction to the Northwest.
	 * 	<DT> SOUTHWEST <DD> movement direction to the Southwest.
	 * </DL>  
	 */
	public void setMapDirection(int dir) {
		if (dir < 0)
			dir = -dir + 7;
		setDirection(mapAngle[dir % 8]);
	}

	
	/**
	 * Sets the body's name. 
	 */
	public void setName(String name) {
		this.name = name;
	}

	private void setPos(double x, double y) {
		pos.x = x;
		pos.y = y;
		shapeTransform = null;
		invTransform = null;
	}

	/**
	 * Sets whether the body's shape is rotated according to this shape's movement direction.
	 * @param rot <code> true</code> or <code>false</code>.
	 */
	public void setRotatesShape(boolean rot) {

		if (rot != doesRotateShape) {
			this.doesRotateShape = rot;
			shapeTransform = null;
			invTransform= null;
		}
	}

	/**
	 * Sets the body's shape to the given <code>shape</code>.
	 * 
	 * @param shape non <code>null</code> shape. 
	 */
	public void setShape(Shape shape) {

		if (shape == null) {
			throw new MCMRuntimeException("Can't set shape to null");
		} else {
			this.shape = shape;
			shapeTransform = null;
			invTransform = null;
		}
	}
	
	/**
	 * Sets the height of this body's shape to the given height in pixels; 
	 * The same as calling setSize(getWidth(), height).
	 * 
	 * @param height
	 *            the new height; must be greater zero
	 */
	public void setHeight(double height) {
		shape.setSize(shape.getWidth(), height);
	}


	/**
	 * Sets the hot spot mode of this body's shape.
	 * <p>
	 * The shape's hotSpot mode determines how its lower left corner is positioned
	 * relative to the body's current position. 
	 * </p>
	 * <p>
	 * The available modes are: <BR>
	 * <DL>
	 * <DT>Shape.CENTER
	 * <DD>put the shape's center at the body's current position
	 * <DT>Shape.UPPER_LEFT
	 * <DD>put the shape's upper left corner at the body's current position
	 * <DT>SHape.UPPER_RIGHT
	 * <DD>put the shape's upper right corner at the body's current position
	 * <DT>Shape.LOWER_LEFT
	 * <DD>put the shape's lower left corner at the body's current position
	 * <DT>Shape.LOWER_RIGHT
	 * <DD>put the shape's lower right corner at the body's current position
	 * <DT>Shape.LOWER_CENTER
	 * <DD>put the shape's midpoint on its lower side at the body's current position
	 * <DT>Shape.UPPER_CENTER
	 * <DD>put the shape's midpoint on its upper side at the body's current position
	 * <DT>Shape.MIDDLE_LEFT
	 * <DD>put the shape's midpoint on its left side at the body's current position
	 * <DT>Shape.MIDDLE_RIGHT
	 * <DD>put the shape's midpoint on its right side at the body's current position
	 * <DT>Shape.FIXED_POINT
	 * <DD>put the shape's hotSpot at the body's current position.
	 * </DL>
	 * </p>
	 * 
	 * @param mode
	 *            the new hotSpot mode
	 *  
	 */
	public void setHotSpot(int mode) {
		shape.setHotSpot(mode); 
	}

	/**
	 * Sets the hot spot of this body's shape to the given point;
	 * as well as the shape's  hotSpot mode to
	 * Shape.FIXED_POINT. 
	 * 
	 * The hot spot point is interpreted relative to the lower left corner 
	 * of the body's shape. When the body is drawn its shape is positioned such that the hotspot point 
	 * appears at the body's current position. When the shape is resized it's hotSpot point is <b>not </b>
	 * adjusted.
	 * 
	 * @param hotSpotPoint
	 *            the new hotSpot to set.
	 * 
	 * @link Shape#setHotSpot(int)
	 */
	public void setHotSpotPoint(Point hotSpotPoint) {
		shape.setHotSpotPoint(hotSpotPoint);
	}

	/**
	 * Set's the linewidth of this body's shape. 
	 * 
	 * The same as getShape().setLineWidth(lineWidth)
	 * 
	 * @param lineWidth
	 *            the new width
	 */
	public void setLineWidth(int lineWidth) {
		shape.setLineWidth(lineWidth); 
	}

	/**
	 * Set's the color of this body's shape. 
	 * 
	 * The same as getShape().setColor(color)
	 * 
	 * @param color
	 *            the new color
	 */
	public void setColor(Color color) {
		shape.setColor(color);
	}

	/**
	 * Returns the color of this body's shape.
	 * 
	 * @return color of this body's shape
	 */
	public Color getColor() {
		return shape.getColor();
	}
	

	/**
	 * Returns the height of this body's shape.
	 * 
	 * @return height of this body's shape
	 */
	public double getHeight() {
		return shape.getHeight();
	}
	
	/**
	 * Returns the width of this body's shape.
	 * 
	 * @return width of this body's shape
	 */
	public double getWidth() {
		return shape.getWidth();
	}

	/**
	 * Returns the hot spot mode of this body's shape.
	 * 
	 * @return hot spot mode of this body's shape
	 */
	
	public int getHotSpot() {
		return shape.getHotSpot();
	}
	
	/**
	 * Returns the linewidth of this body's shape. 
	 * The same as  getShape().getLineWidth();
	 *
	 */
	public int getLineWidth() {
		return shape.getLineWidth();
	}

	/**
	 * The same as getShape().setWidth(width)
	 */
	public void setSize(double width, double height) {
		shape.setSize(width, height); 
	}

	/**
	 * Sets the shape's width in pixels; width must be greater than 0. The same
	 * as calling setSize(width, getHeight()).
	 * The same as getShape().setSize(width, shape.getHeight())
	 * @param width
	 *            the new width; must be greater zero
	 */
	public void setWidth(double width) {
		shape.setSize(width, shape.getHeight());
	}

	/**
	 * Sets the visibility of the body's shape. 
	 * @param visible <code> true</code> or <code>false</code>.
	 */
	public void setVisible(boolean visible) {

		this.visible = visible;
	}


	/*********************************************************
	 * methods
	 **********************************************************/

	/**
	 * Returns  a string with detailed information  about this actor. 
	 */
	public String toDetailString() {
		DecimalFormat f = new DecimalFormat("###.##");
		return (pos == null ? "" : "pos=(" + f.format(pos.x) + ","
				+ f.format(pos.y) + ")")
				+ " "
				+ (direction == null ? "" : "dir=(" + f.format(direction.x)
						+ "," + f.format(direction.y) + ")")
				+ " "
				+ (shape == null ? "no-shape" : Utils.shortClassName(shape));

	}

	/**
	 * Returns the body's name.
	 */
	public String toString() {
		return getName();
	}

	/** 
	 * The same as transFromLocal(x,y,null). 
	 * @return a newly allocated point
	 */
	public Point transFromLocal(double x, double y) {
		return transFromLocal(x, y, null);
	}
	
	/**
	 * Returns the global coordinates for the point (x,y).
	 * Interpretes as (x,y) as coordinates in this body's coordinate system and 
	 * transforms them to global coordinates. 
	 * Returns the computed coordinates in <code>global</code> if non null or in a newly 
	 * allocated point. 
	 *  
	 * @param x  x ccordinate 
	 * @param y  y coordinate 
	 * @param global  null or reference to a point 
	 * @return global, if not null, or newly allocated point
	 */
	public Point transFromLocal(double x, double y, Point global) {
		AffineTransform f = getTransform();
		if (global == null)
			global = new Point();
		transFromLocalPoint.x = x; 
		transFromLocalPoint.y = y;
		f.transform(transFromLocalPoint, global);
		return global;
	}
	
	/**
	 * The same as transToGlobal(alignment, null)
	 * @return a newly allocated point	 
	 */
	public Point transToGlobal(int alignment) 
	{
		return transToGlobal(alignment, null); 
	}
	
	/**
	 * Returns the global coordinates of the point at the given alignment position in this body's shape. 
	 * The alignment value indicates which point's coordinates are requested.
	 * Returns the computed coordinates in <code>global</code> if non null or in a newly 
	 * allocated point. 
	 * 
	 * @param alignment any alignment value from {@link Shape} except Shape.FIXED_POINT
	 * @return global, if not null, or newly allocated point
	 * @see Shape#getPos(int, Point)
	 */
	public Point transToGlobal(int alignment, Point global) 
	{
		Point p = getShape().getPos(alignment, global); 
		transFromLocal(p.x, p.y, p); 
		return p;	
	}
	
	
	/** 
	 * The same as transToLocal(x,y,null). 
	 * @return a newly allocated point
	 */
	public Point transToLocal(double x, double y) {
		return transToLocal(x, y, null);
	}
	
	/**
	 * Returns the local coordinates for the point (x,y).
	 * Computes the coordinates for the point (x,y) in this body's coordinate system. 
	 * Returns the computed coordinates in <code>local</code> if non null or in a newly 
	 * allocated point. 
	 *  
	 * @param x  x ccordinate 
	 * @param y  y coordinate 
	 * @param local  null or reference to a point 
	 * @return local, if not null, or newly allocated point
	 */
	public Point transToLocal(double x, double y, Point local) {
		AffineTransform f = getInvTransform();
		if (local == null)
			local = new Point();
		transToLocalPoint.x = x; 
		transToLocalPoint.y = y;
		f.transform(transToLocalPoint, local);
		return local;
	}

}

