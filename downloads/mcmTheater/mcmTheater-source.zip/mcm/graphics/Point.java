
package mcm.graphics;

import java.awt.geom.*;


/**
 * Point is a wrapper for the {@link java.awt.geom.Point2D}.Double class. 
 * It provides various convenient constructors.
 *
 * @author Monika Mevenkamp
 * 
 */
public class Point extends Point2D.Double {
	
	/**
	 * Constructs and initializes a point with coordinates (0, 0).
	 */
	public Point() {
		this(0.0, 0.0);
	}

	/**
	 * Constructs and initializes a point with coordinates (x, y)
	 */
	public Point(double x, double y) {
		super(x, y);
	}

	/**
	 * Constructs and initializes a point with coordinates (x, y)
	 */
	public Point(float x, float y) {
		super(x, y);
	}

	/**
	 * Constructs and initializes a point with coordinates (x, y)
	 */
	public Point(int x, int y) {
		super(x, y);
	}

	/**
	 * Constructs and initializes a point with coordinates (p.x, p.y)
	 */
	public Point(Point p) {
		super(p.x, p.y);
	}
	
	/**
	 * Returns a String that represents the x and y coordinate values 
	 * of this point. 
	 * Coordinates values sare shown with at most two digits after the 
	 * decimal point.
	 * 
	 * @return the x and y coordinate values in braces
	 */
	public String toString() 
	{
		double xd  = ((int) x * 100) / 100; 
		double yd  = ((int) y * 100) / 100; 	
		return "(" + xd + "," + yd + ")"; 
	}
}
