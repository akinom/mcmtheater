package mcm.graphics;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.*;

import mcm.utils.Assert;
import mcm.utils.Trace;
import mcm.utils.Utils;

/**
 * A Drawable provides a double buffered drawing area. 
 * <p>
 * A drawable is associated with a Component. 
 * It provides a coordinate system with the origin (0,0) at its lower
 * left corner. The coordinates of its upper right corner are (width-1 ,
 * height-1).
 * </p>
 * 
 * @author Monika Mevenkamp
 */
public class Drawable {

	/**
	 * default color used in constructor
	 */
	static final Color DEFAULT_COLOR = Color.WHITE;

	/** 
	 * default fill color for double buffer 
	 * @see Drawable#clear()
	 */
	private Graphics2D bufferGraphics;

	private Image doubleBuffer;

	private int width, height;
	
	private Color color; 

	private Component component;

	/**
	 * Constructs a new Drawable object for the given Component. 
	 * 
	 * The drawable provides a double buffer (image and assciated graphics context) that 
	 * can be used to draw to. The graphics context is defined 
	 * such that (0, 0) is at the lower left of the image.
	 * 
	 * @param c
	 *            the component to draw to 
	 */
	public Drawable(Component c) {
		Assert.check(c != null); 
		color = DEFAULT_COLOR;
		component = c;
		width = -1;
		height = -1;
		doubleBuffer = null;
		bufferGraphics = null;
		resize();
	}

	/**
	 * Resizes this drawable according to the dimension's of its associated Component. 
	 */
	public boolean resize() {
		int w = component.getWidth();
		int h = component.getHeight();
		if (w <= 0 || h <= 0) 
			return false;
		if (w != width || h != height) {
			Trace.global.traceMsg(this, "resize: " + w + "x" + h); 
			width = w;
			height = h;
			doubleBuffer = component.createImage(width, height);
			bufferGraphics = (Graphics2D) doubleBuffer.getGraphics();
			bufferGraphics.setTransform(getFlipTrans());
			((Graphics2D) bufferGraphics).setRenderingHint(
					RenderingHints.KEY_ANTIALIASING,
					RenderingHints.VALUE_ANTIALIAS_ON);
			bufferGraphics.setColor(color); 
			bufferGraphics.fillRect(0, 0, width, height);
			return true;
		}
		return false;
	}

	/** 
	 * Return the double buffer image 
	 * @return null or the current double buffer image 
	 */
	public Image getImage() {
		return doubleBuffer;
	}

	/** 
	 * Return the graphics context of the double buffer image 
	 * @return null or the current double buffer image 
	 */
	public Graphics2D getGraphics() {
		return bufferGraphics;
	}

	/**
	 * Clears the given graphics context by filling it with this Drawable's color
	 */
	public void clear(Graphics2D graphics) {
		if (graphics != null) {
			// clear the whole thing in bgcolor
			graphics.setColor(color);
			graphics.fillRect(0, 0, width, height);
		}
	}
	
	/**
	 * The same as clear(getGraphics())
	 */
	public void clear() {
		clear(getGraphics()); 
	}

	/**
	 * Returns the center point of this drawable.
	 * 
	 * @return the center point
	 */
	public Point getCenter() {
		Point ctr = new Point(0.5 * width, 0.5 * height);
		return ctr;
	}

	/**
	 * Returns this Drawable's background color.
	 * 
	 * @return the background color
	 */
	public Color getColor() {
		return color;
	}

	/**
	 * Returns the component that this drawable uses as drawing surface. 
	 * 
	 * @return this drawable's component
	 */
	public Component getComponent() {
		return component;
	}

	/**
	 * Returns the current height of this drawable.
	 * 
	 * @return the height
	 */
	public int getHeight() {
		return height;
	}

	/**
	 * Returns the current width of this drawable.
	 * 
	 * @return the width
	 */
	public int getWidth() {
		return width;
	}

	private AffineTransform getFlipTrans() {
		AffineTransform f = new AffineTransform(1, 0, 0, -1, 0, height);
		return f;
	}

	/**
	 * Determines whether the given point (x,y) lies within this drawable's boundaries. A
	 * point inside the drawable must have an x coordinate greater or equal zero
	 * and smaller than the drawable's current width. Its y coordinate must be
	 * greater equal zero and smaller than the drawable's current height.
	 * 
	 * @return <code>true</code> if <code>pt</code> lies within this drawable's
	 *         boundaries; <code>false</code> otherwise
	 */
	public boolean isInside(double x, double y) {
		return (x >= 0) && (x < width) && (y >= 0) && (y < height);
	}

	/**
	 * The same as isInsize(pt.x, pt.y)
	 */
	public boolean isInside(Point pt) {
		return isInside(pt.x, pt.y);
	}

/**
 * Paints the contents of the double buffer to the given graphics context.
 * @param g the graphics context to which the double buffer is drawn
 */
	public void paint(Graphics g) {
		if (null != doubleBuffer) {
			g.drawImage(doubleBuffer, 0, 0, component);
		}
	}

	/**
	 * Sets the drawable's background color. 
	 * 
	 * @param c
	 *            the new background color
	 */
	public void setColor(Color c) {
		color = c;
	}

	private AffineTransform identity = new AffineTransform(); 
	/**
	 * Copy the given drawable onto this drawable. 
	 * The given drawable is drawn such that its lower left corner appears at (x,y).
	 * @param image 
	 * @param x
	 * @param y
	 */	
	public void draw(Drawable image, int x, int y) {
		image.draw(bufferGraphics, x, y); 
//		
//		Graphics2D g = bufferGraphics;
//		g.setTransform(identity);
//		g.drawImage(image.doubleBuffer, x, y, width, height, getComponent()); 
//		g.setTransform(getFlipTrans()); 		
//	}
	}

	
	/**
	 * Copy this drawable's double buffer to the given graphics context. 
	 * Draw it so that the double buffer is positioned at (x,y).
	 * 
	 * @param g the graphics copntect to draw to
	 * @param x x coordinate of lower left corner 
	 * @param y y coordinate of lower left corner 
	 */	
	public void draw(Graphics2D g, int x, int y) {
		AffineTransform f = g.getTransform();
		g.setTransform(identity);
		g.drawImage(doubleBuffer, x, y, width, height, getComponent()); 
		g.setTransform(f); 		
	}

	
	/**
	 * Get RGB color of given pixel location in double buffer
	 * @param x pixel's x coordinate 
	 * @param y pixel's y coordinate 
	 * @return pixel's rgb color 
	 */
	public Color getPixelColor(int x, int y) {
		BufferedImage img = getBufferedImage(); 
		int rgb = img.getRGB(x, img.getHeight() -1 - y); 
		return new Color(rgb); 
	}
	
	
	/**
	 * The same as getPixelColor(Math.rint(x), Math.rint(y))
	 */
	public Color getPixelColor(double x, double y) {
		return getPixelColor((int) Math.rint(x), (int) Math.rint(y)); 
	}
	
	/**
	 * Writes this drawable's contents to the given file in the given format. Uses
	 * {@link ImageIO#write(java.awt.image.RenderedImage, java.lang.String, java.io.File)}
	 * to do so.
	 * 
	 * @param format
	 *            image file's format
	 * @param file
	 *            name of output file
	 * @throws IOException
	 *             if an error occurs in writing
	 */
	public synchronized void write(String format, String file)
			throws IOException {
		BufferedImage img = getBufferedImage();
		if (img != null && 
				!ImageIO.write(img, format, new File(file))) {
			throw new IOException("Don't know how to write " + format
					+ " format files.");
		}
	}

	/** 
	 * Return this Drawable's  double buffer as BufferedImage 
	 */
	public BufferedImage getBufferedImage() 
	{
		Assert.check(doubleBuffer != null);
		try {
			return (BufferedImage) doubleBuffer;
		} catch (Exception e) {
			System.err.println("Do not know how to write "
					+ doubleBuffer.getClass().getName() + "\n");
			return null;
		}
	}

	/**
	 * Returns a string representation for this drawable. 
	 * @return a short string representation
	 */
	public String toString() {
		return Utils.shortClassName(this) + " : " + width + "x" + height;
	}

}