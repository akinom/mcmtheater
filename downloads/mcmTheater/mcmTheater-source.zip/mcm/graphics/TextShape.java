/*
 * Created on Jan 9, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package mcm.graphics;

import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;

import mcm.utils.Assert;
import mcm.utils.MCMRuntimeException;

/**
 * TextShapes serve to display one line Strings
 * 
 * @author Monika Mevenkamp
 *
 */
public class TextShape extends Shape {

	public static final Font DEFAULT = new Font("Serif", Font.BOLD, 14);

	private String text;

	private Font font;

	private Drawable stage;

	double scalex, scaley;

	float ascent;

	/** 
	 * Creates a TextShape object with the given text and the default font. 
	 * @see TextShape#TextShape(String, Font, Drawable) 
	 */
	public TextShape(String text, Drawable stage) {
		this(text, null, stage);
	}

	/** 
	 * Creates a TextShape object with the given text and font.
	 * Its width and height is computed on the basis of the given font and stage.
	 * Its hotSpot mode is set to {@link Shape#CENTER}. 
	 * Sets the font to a default font if a <code>null</code> font is passed.
	 * 
	 * @param text the string to use as text 
	 * @param font the font to use when displaying this TextShape
	 * @param stage the stage on which this shape will be painted 
	 */
	public TextShape(String text, Font font, Drawable stage) {
		super(0, 0, Shape.CENTER);
		if (stage == null) {
			throw new RuntimeException(
					"May not pass null Stage to TextShape constructor");
		}
		this.text = checkText(text);
		this.stage = stage;
		scalex = 1.0;
		scaley = 1.0;
		setFont(font);
	}

	private String checkText(String text) {
		if (text == null) {
			text = "**EMPTY**";
		}
		return text;
	}

	/**
	 * Creates and returns a copy of this shape.
	 */
	public Object clone() 
	{
		TextShape s = new TextShape(text, font, stage); 
		s.cloneProps(this); 
		return s; 
	}
	
	
	/** 
	 * Sets this shape's font to the given font.
	 * Sets the font to a default font if the given font equals <code>null</code>.
	 * 
	 * @param fnt <code>null</code> or the new font 
	 */
	public void setFont(Font fnt) {
		if (fnt == null) {
			fnt = DEFAULT;
		}
		font = fnt;
		updateSize();
	}

	private void updateSize() {
		Graphics2D g2d = stage.getGraphics();
		Assert.check(g2d != null);
		g2d.setFont(font);
		Rectangle2D rect = g2d.getFontMetrics().getStringBounds(text, g2d);
		width = rect.getWidth();
		height = rect.getHeight();
		ascent = g2d.getFontMetrics().getAscent();
		super.computeHotSpot(hotSpotMode);
	}

	/** 
	 * Sets this shape's font to the given font.
	 * Sets the font to a default font if the given font equals <code>null</code>.
	 * 
	 * @param txt  the shape's new text
	 */
	public void setText(String txt) {
		text = checkText(txt);
		updateSize();
	}

	
	/** 
	 * Returns the shape's text string.
	 */
	public String getText() {
		return text;
	}

	
	/**
	 * Sets the new dimension to be width and height measured in pixels. 
	 * @see Shape#setSize(double, double)
	 * 
	 * @param width
	 *            new width; must be greater zero
	 * @param height
	 *            new height; must be greater zero
	 */
	public void setSize(double width, double height) {
		if (width <= 0 || height <= 0) {
			throw new MCMRuntimeException("width and height must be greater than zero"); 
		}
		scalex = scalex * width / this.width;
		scaley = scaley * height / this.height;
		this.width = width;
		this.height = height;
		super.computeHotSpot(hotSpotMode);
	}

	private AffineTransform flip = new AffineTransform(1, 0, 0, -1, 0, 0);

	/** 
	 * Paints this shape's text
	 * 
	 * @see Shape#paint(Graphics2D)
	 */
	public void paint(Graphics2D g2d) {
		AffineTransform f = g2d.getTransform();
		flip.setTransform(1, 0, 0, -1, 0, height);
		g2d.transform(flip);
		g2d.scale(scalex, scaley);
		g2d.setFont(font);
		g2d.setColor(getColor());
		g2d.drawString(text, 0f, ascent);
		g2d.setTransform(f);
		if (getDebug()) super.paint(g2d); 
	}

}