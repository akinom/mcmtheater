package mcm.graphics;
 
import java.awt.Graphics2D;
import mcm.utils.Assert;

/**
 * SizedShapes wrap awt shapes that may be rendered by draw calls. 
 * 
 * SizedShape is an abstract base class which expects that 
 * derived classes define their awt shapes so that they are fully contained 
 * by the rectangle defined by the points (0,0) and (shape_width, shape_height). 
 * Derived classes must therefore overwrite the setSize method to continuously 
 * update their awt shapes according to size. 
 */
public abstract class SizedShape extends Shape {

	java.awt.Shape awtShape = null;
		
	protected  SizedShape() 
	{}
	
	/**
	 * Constructs a new SizedShape object with the given java.awt.Shape. 
	 * The awtShape is expected to fully fit into the area defined by (0,0) and this
	 * shape's width and height.
	 */
	protected void setShape(java.awt.Shape shape) {
		awtShape = shape; 
	}
	
	/**
	 * Retunrs this Shape's java.awt.Shape 
	 */
	protected java.awt.Shape getShape() {
		return awtShape;
	}

	/** 
	 * Paints this shape's java.awt.Shape. 
	 * Paint adjusts the graphic context's color and stroke 
	 * according to its own color and line width and then draws 
	 * its java.awt.Shape.
	 * 
	 * @see Shape#paint(Graphics2D)
	 */
	public void paint(Graphics2D g2D) {
		Assert.check(g2D != null);
		g2D.setStroke(getStroke());
		g2D.setColor(getColor());
		Assert.check(awtShape != null);
		g2D.draw(awtShape);
		if (getDebug()) super.paint(g2D); 
	}

}