package mcm.graphics;

import java.applet.Applet;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.net.URL;

import javax.swing.ImageIcon;

import mcm.utils.MCMRuntimeException;
import mcm.utils.Trace;

/**
 * ImageShape objects wrap an ImageIcon.
 * 
 * @author Monika Mevenkamp
 */
public class ImageShape extends Shape 
{
	
	/** 
     * reference to a class loader 
     */
	public static ClassLoader TheClassLoader = null; 
	public static Applet theApplet; 
	
    private String fileName;
	private ImageIcon imageIcon;
	private Drawable component; 

	/** Constructs a new ImageShape object.
	 * This constructor has the same effect as ImageShape(imageFile, stage, CENTER).
	 * 
	 * @param imageFile image file used to construct the image for this shape
	 */
	public ImageShape(String imageFile, Drawable c) {
		this(imageFile, CENTER, c);
	}

	/** Constructs a new ImageShape object.
	 * This constructor reads image information from the given file.
	 * If the constructor encounters a problem reading the image information it prints 
	 * an error message and assumes a rectangular filled shape.
	 * The constructed shape object uses the given hotSpot mode.
	 * 
	 * @param imageFile image file used to construct the image for this shape
	 * @param hotSpotMode the shape's hotSpotMode
	 * @param drawable  a drawable that may be used as image observer when painting
	 * 
	 * @see ImageIcon#paintIcon(java.awt.Component, java.awt.Graphics, int, int)
	 * @see Shape#setHotSpot(int)
	 */
	public ImageShape(String imageFile, int hotSpotMode, Drawable drawable) {
		super(-1, -1, Shape.UNDEFINED);
		fileName = imageFile;
		setImageIconFromFile();
		setHotSpot(hotSpotMode);
		component = drawable; 
	}
	
	/** Constructs a new ImageShape object from the given ImageIcon.
	 * The constructed shape object uses the given hotSpot mode.
	 * 
	 * @param icon  the imageIcon to be used by the new shape
	 * @param hotSpotMode  the new shape's hotSpotMode
	 * @param drawable  a drawable that may be used as image observer when painting
	 * 
	 * @see Shape#setHotSpot(int)
	 * @see ImageIcon#paintIcon(java.awt.Component, java.awt.Graphics, int, int)
	 */
	public ImageShape(ImageIcon icon, int hotSpotMode, Drawable drawable) {
		super(-1, -1, Shape.UNDEFINED);
		if (icon == null) {
			Exception e = 
			new MCMRuntimeException("Can not create ImageShape from null image icon"); 
			Trace.report(e);
		}
		fileName = "<UNKNOWN>";
		//setImageIconFromFile();
		imageIcon= icon; 
		component = drawable; 
		setHotSpot(hotSpotMode);
	}
	
	/**
	 * Creates and returns a copy of this shape.
	 */
	public Object clone() 
	{
		ImageShape s = new ImageShape(imageIcon, hotSpotMode, component); 
		s.cloneProps(this); 
		return s; 
	}
	
	/** 
	 * Returns the image icon associated with this shape. 
	 * 
	 * @return this shape's image icon
	 */
	public ImageIcon getImageIcon() {
		return imageIcon;
	}

	private void setImageIconFromFile() {
		if (imageIcon != null) {
			return;
		}
		URL imgURL = null; 
		if (theApplet != null) {
			Trace.global.traceMsg(this, "theApplet: " + theApplet.getClass()); 	
			imgURL = theApplet.getClass().getResource(fileName); 
		} 
		if (TheClassLoader != null && imgURL == null) {
			Trace.global.traceMsg(this, "TheClassLoad: " + TheClassLoader); 	
			if (TheClassLoader != null) 
				imgURL = TheClassLoader.getResource(fileName); 
		}
		Trace.global.traceMsg(this, "\n\tpath=" + fileName + "==>\n\turl=" + imgURL);
		try {
			if (imgURL != null) {
				imageIcon = new ImageIcon(imgURL);
			} else {
				imageIcon = new ImageIcon(fileName);
			}
			if (imageIcon.getImageLoadStatus() != MediaTracker.COMPLETE) {
				throw new RuntimeException("Could not find " + fileName);
			}
			super.height = imageIcon.getIconHeight();
			super.width = imageIcon.getIconWidth();
		} catch (Exception e) {
			Trace.report("Could not load image " + fileName);
			imageIcon = null; // Ah well could read it
			super.height = 20;
			super.width = 20;
		}
	}

	private AffineTransform paintFlip = new AffineTransform(1, 0, 0, -1, 0, 10);
	
	/** 
	 * Paints this shape's image.
	 * @see Shape#paint(Graphics2D)
	 */
	public void paint(Graphics2D g2D) {
		// super.paint(g2D, a, stage); 
		if (imageIcon != null) {
			AffineTransform f = g2D.getTransform(); 
			paintFlip.setTransform(1, 0, 0, -1, 0, height);
			g2D.transform(paintFlip);
			imageIcon.paintIcon(component.getComponent(), g2D, 0, 0);
			g2D.setTransform(f); 
			if (getDebug()) super.paint(g2D); 
		} else {
		       g2D.setStroke(getStroke()); 
		       g2D.setColor(getColor());
		       g2D.fill(new Rectangle2D.Double(0, 0, width, getHeight()));
		}
	}

	/**
	 * Scales the image to be width by height pixels. <code>width</code> and
	 * <code>height</code> are rounded to the nearest integer value.
	 * 
	 * @param width
	 *            width of the scaled image; must be greater zero
	 * @param height
	 *            height of the scaled image; must be greater zero
	 *  
	 */
	public void setSize(double width, double height) {
		int h = (int) Math.rint(height);
		int w = (int) Math.rint(width);
		imageIcon = new ImageIcon(imageIcon.getImage().getScaledInstance(w, h, Image.SCALE_DEFAULT));
		super.setSize(w, h);
	}

	/**
	 * Returns a string representation of this shape.  
	 */
	public String toString() {
		return super.toString() + "(\"" + fileName + "\")";
	}

}
