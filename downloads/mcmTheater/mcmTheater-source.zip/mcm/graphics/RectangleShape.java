
package mcm.graphics;

import java.awt.geom.Rectangle2D;


/**
 * A rectangle shape.
 *
 * @author Monika Mevenkamp
 */
public class RectangleShape extends FillableShape {

	/**
	 * Constructs a rectangular shape. 
	 * It has the given width, height and fill status.  
	 * Its hotSpot mode is set to {@link Shape#CENTER}.
	 * 
	 * @param width the shape's width 
	 * @param height the shape's height
	 */
	public RectangleShape(double width, double height, boolean filled) {
		super(filled); 
		setShape(new Rectangle2D.Double(0, 0, width, height)); 
		setHotSpot(CENTER); 
		setSize(width, height); 
	}

   /** 
     * Creates and returns a copy of this shape.
     */
	protected Object clone() 
	{ 
		Shape s = new RectangleShape(width, height, isFilled());
		s.cloneProps(this); 
		return s; 
	}
	
	public void setSize(double width, double height) 
	{
		Rectangle2D.Double rect = (Rectangle2D.Double) awtShape; 
		rect.setFrame(0, 0, width, height); 
		super.setSize(width, height); 
	}
}
