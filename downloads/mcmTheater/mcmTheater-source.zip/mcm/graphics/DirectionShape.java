
package mcm.graphics;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;

/**
 * An elliptical shape that shows its orientation.
 */
public class DirectionShape extends EllipseShape {
	Line2D.Double line;
	
	/**
	 * The same as DirectionShape(width, height, true)
	 * @param width the width the new shape
	 * @param height the height of the new shape 
	 */
	public DirectionShape(double width, double height) {
		super(width, height, true);
	}
	
	/**
	 * Creates a DirectionShape with the given filled status.
	 * Its hotSpot mode is set to {@link Shape#CENTER}.
	 *
	 * @param width the width the new shape
	 * @param height the height of the new shape 
	 * @param filled indicates hwther the shape is filled 
	 */
	public DirectionShape(double width, double height, boolean filled) {
		super(width, height, filled);
		setSize(width, height);
	}

	/** 
     * Creates and returns a copy of this shape.
     */
	protected Object clone() 
	{ 
		Shape s = new DirectionShape(width, height, isFilled());
		s.cloneProps(this); 
		return s; 
	}
	
	public void setSize(double width, double height) {
		super.setSize(width, height); 
		if (line == null) {
			line = new Line2D.Double();
		}
		line.x1 = width / 2; 
		line.y1 = height/ 2; 
		line.x2 = width; 
		line.y2 = height / 2; 	
	}
	
	/** 
	 * Paints an ellipse and a line from the ellipse's center to its right extreme point.
	 * 
	 * @see FillableShape#paint(Graphics2D)
	 */
	public void paint(Graphics2D g2D) {
		super.paint(g2D); 
		if (isFilled()) {
			g2D.setXORMode(Color.BLACK);
		}
		g2D.draw(line);
		if (isFilled()) {
			g2D.setPaintMode();
		}
	}
}
