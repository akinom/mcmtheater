package mcm.graphics;

import java.awt.Graphics2D;

import mcm.utils.Assert;


/**
 * FillableShapes wrap awt shapes that may be rendered by draw or fill calls. 
 */
public abstract class FillableShape extends SizedShape {
	
	/** 
	 * the filled state
	 */
	private boolean filled;

	/**
	 * Constructs an empty object with the given fill mode. 
	 */
	public FillableShape(boolean filled) {
		this.filled = filled;
	}
	

	/**
	 * Returns the shape's filled mode.
	 * 
	 * @return Returns <code>true</code> if the shape is filled,
	 *         <code>false</code> otherwise
	 */
	public boolean isFilled() {
		return filled;
	}

	/** 
	 * Paints this shape's java.awt.Shape by calling its draw or fill method.
	 * 
	 * @see SizedShape#paint(Graphics2D)
	 */
	public void paint(Graphics2D g2D) {
		if (filled) {
			Assert.check(g2D != null);
			g2D.setStroke(getStroke());
			g2D.setColor(getColor());
			Assert.check(awtShape != null);
			g2D.fill(awtShape);
			if (getDebug()) super.paint(g2D); 
		} else {
			super.paint(g2D);
		}
	}

	/**
	 * Sets the shape's filled mode.
	 * 
	 * @param filled
	 *            the shape becomes filled if filled is <code>true</code>,
	 *            otherwise it becomes hollow
	 */
	public void setFilled(boolean filled) {
		this.filled = filled;
	}

}