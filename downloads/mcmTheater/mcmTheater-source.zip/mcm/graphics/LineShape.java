
package mcm.graphics;

import java.awt.geom.Line2D;


/**
 * A line shape.
 */
public class LineShape extends SizedShape {

	/**
	 * Constructs a line with the slope deltay / deltax. 
	 * It runs across the diagonal of the rectangle with the width and height 
	 * given by the absolute values of deltax and deltay.
	 * 
	 * The shape's hot spot is set to 
	 * <UL> 
	 * <LI> LOWER_LEFT 		if (deltax >= 0 && deltay >= 0) </LI> 
	 * <LI> UPPER_LEFT    	if (deltax >= 0 && deltay < 0) </LI> 
	 * <LI> LOWER_RIGHT 	if (deltax < 0 && deltay >=0) </LI> 
	 * <LI> UPPER_RIGHT  		otherwise </LI> 
	 * </UL> 
	 * 
	 */
	public LineShape(double deltax, double deltay) {
		setHotSpot(CENTER); 
		setShape(new Line2D.Double()); 
		setSlope(deltax, deltay); 
	}

   /** 
     * Creates and returns a copy of this shape.
     */
	protected Object clone() 
	{ 
		Shape s = new LineShape(width, height);
		s.cloneProps(this); 
		return s; 
	}
	
	public void setSize(double width, double height) 
	{
		Line2D.Double line = (Line2D.Double) awtShape;
		if (line.x1 != 0) {
			line.x1 = ((line.x1 < 0) ? -1 : 1) * width; 
		}
		if (line.x2 != 0) {
			line.x2 = ((line.x2 < 0) ? -1 : 1) * width; 
		}
		if (line.y1 != 0) {
			line.y1 = ((line.y1 < 0) ? -1 : 1) * height; 
		}
		if (line.y2 != 0) {
			line.y2 = ((line.y2 < 0) ? -1 : 1) * height; 
		}
		super.setSize(width, height); 
	}
	
	/**
	 * Sets the line's slope to deltay / deltax so that it 
	 * runs across the diagonal of the rectangle with the width and height 
	 * given by the absolute values of deltax and deltay.
	 * 
	 * The shape's hot spot is set to 
	 * <UL> 
	 * <LI> LOWER_LEFT 		if (deltax >= 0 && deltay >= 0) </LI> 
	 * <LI> UPPER_LEFT    	if (deltax >= 0 && deltay < 0) </LI> 
	 * <LI> LOWER_RIGHT 	if (deltax < 0 && deltay >=0) </LI> 
	 * <LI> UPPER_RIGHT  		otherwise </LI> 
	 * </UL> 
	 *
	 */
	public void setSlope(double deltax, double deltay) {
		Line2D.Double line = (Line2D.Double) awtShape;
		if (deltax >= 0 && deltay >= 0) {
			setHotSpot(LOWER_LEFT); 
			line.setLine(0, 0, deltax, deltay); 
			super.setSize(deltax, deltay); 
			return;
		}
		if (deltax >= 0 && deltay < 0) {
			setHotSpot(UPPER_LEFT); 
			line.setLine(0, -deltay, deltax, 0); 
			super.setSize(deltax, -deltay); 
			return;
		}
		if (deltax < 0 && deltay >=0) {
			setHotSpot(LOWER_RIGHT);
			line.setLine(0, deltay, -deltax, 0); 
			super.setSize(-deltax, deltay); 
			return;
		}
		setHotSpot(UPPER_RIGHT); 
		line.setLine(0, 0, -deltax, -deltay); 
		super.setSize(-deltax, -deltay); 
	}

}
