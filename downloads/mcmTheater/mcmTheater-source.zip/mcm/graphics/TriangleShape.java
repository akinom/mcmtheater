package mcm.graphics;

import java.awt.Rectangle;
import java.awt.geom.GeneralPath;

import mcm.utils.MCMRuntimeException;

/**
 * An triangle shape.
 */
public class TriangleShape extends FillableShape {

	private double x[] = new double[3];

	private double y[] = new double[3];

	/**
	 * Constructs a triangular shape. 
	 * It connects the points (0,0), (0, height), and (width, height/2), where 
	 * the coordinates are interpreted relative to the shape's lower left corner.
	 * 
	 * The shape's hotSpot mode is set to {@link Shape#CENTER}.
	 * 
	 * @param width the shape's width 
	 * @param height the shape's height
	 */
	public TriangleShape(double width, double height, boolean filled) {
		this(0, 0, 0, height, width, height / 2, filled);
	}

	/**
	 * Constructs a triangular shape. 
	 * It creates a triangle that is congruent to the triangle defined by the 
	 * three points (x1, y1), (x2, y2), and (x3, y3). 
	 * The triangles coordinates are shifted so that it fits into a rectangle 
	 * whith a lower left corner at (0,0). The  rectangle's width and height are 
	 * defined so that the triangle fits tightly inside the rectangle. 
	 * 
	 * The shape's hot spot is set to {@link Shape#CENTER}.
	 * 
	 * @param x0  x coordinate of first point 
	 * @param y0  y coordinate of first point 
	 * @param x1  x coordinate of second point 
	 * @param y1  y coordinate of second point 
	 * @param x2  x coordinate of third  point 
	 * @param y2  y coordinate of third point 
	 */
	public TriangleShape(double x0, double y0, double x1, double y1, double x2, double y2, boolean filled) {
		super(filled);
		setShape(new GeneralPath());
		x[0] = x0;
		x[1] = x1;
		x[2] = x2;
		y[0] = y0;
		y[1] = y1;
		y[2] = y2;
		setTriangle();
		Rectangle rect = getShape().getBounds();
		for (int i = 0; i < 3; i++) {
			x[i] -= rect.x;
			y[i] -= rect.y;
		}
		setTriangle();
		setHotSpot(CENTER);
		super.setSize(rect.width, rect.height);
	}

	/** 
	 * Creates and returns a copy of this shape.
	 */
	protected Object clone() {
		Shape s = new TriangleShape(width, height, isFilled());
		s.cloneProps(this);
		return s;
	}

	public void setSize(double width, double height) {
		double xscale = width / this.width;
		double yscale = height / this.height;
		for (int i = 0; i < 3; i++) {
			x[i] *= xscale;
			y[i] *= yscale;
		}
		setTriangle();
		super.setSize(width, height);
	}

	private void setTriangle() {
		GeneralPath triangle = (GeneralPath) awtShape;
		triangle.reset();
		triangle.moveTo((float) x[0], (float) y[0]);
		triangle.lineTo((float) x[1], (float) y[1]);
		triangle.lineTo((float) x[2], (float) y[2]);
		triangle.closePath();
	}

	/** 
	 * Returns the x coordinate of one of the triangle's points. 
	 * The coordinate is given relative to the shape's hotSpot. 
	 * @param i must be 0, 1, or 2
	 * @return x coordinate of first, second, or third corner point 
	 */
	public double getPointX(int i) {
		if (i < 0 || i > 2) {
			throw new MCMRuntimeException("Must pass index value 0, 1, or 2");
		}
		return x[i] - hotSpot.x;
	}

	/** 
	 * Returns the y coordinate of one of the triangle's points. 
	 * The coordinate is given relative to the shape's hotSpot. 
	 * 
	 * @param i must be 0, 1, or 2
	 * @return y coordinate of first, second, or third corner point 
	 */
	public double getPointY(int i) {
		if (i < 0 || i > 2) {
			throw new MCMRuntimeException("Must pass index value 0, 1, or 2");
		}
		return y[i] - hotSpot.y;
	}
}