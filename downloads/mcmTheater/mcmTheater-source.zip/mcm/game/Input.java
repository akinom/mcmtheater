package mcm.game;

import java.awt.Component;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Vector;

import mcm.graphics.Point;
import mcm.utils.MCMRuntimeException;
import mcm.utils.Trace;
import mcm.utils.Utils;

/**
 * Keeps track of unicode character input as well as input from a select list of
 * virtual keys.
 */
public class Input {

	static final int UP = 0;

	/**
	 * Ease of use Input constant
	 */
	public static final Input KEY_UP = new Input(UP);

	static final int DOWN = 1;

	/**
	 * Ease of use Input constant
	 */
	public static final Input KEY_DOWN = new Input(DOWN);

	static final int LEFT = 2;

	/**
	 * Ease of use Input constant
	 */
	public static final Input KEY_LEFT = new Input(LEFT);

	static final int RIGHT = 3;

	/**
	 * Ease of use Input constant
	 */
	public static final Input KEY_RIGHT = new Input(RIGHT);

	static final int ENTER = 4;

	/**
	 * Ease of use Input constant
	 */
	public static final Input KEY_ENTER = new Input(ENTER);

	static final int F1 = 5;

	/**
	 * Ease of use Input constant
	 */
	public static final Input KEY_F1 = new Input(F1);

	static final int F2 = 6;

	/** 
	 * Ease of use Input constant 
	 */
	public static final Input KEY_F2 = new Input(F2);

	static final int F3 = 7;

	/**
	 * Ease of use Input constant
	 */
	public static final Input KEY_F3 = new Input(F3);

	static final int F4 = 8;

	/**
	 * Ease of use Input constant
	 */
	public static final Input KEY_F4 = new Input(F4);

	static final int F5 = 9;

	/**
	 * Ease of use Input constant
	 */
	public static final Input KEY_F5 = new Input(F5);

	static final int F6 = 10;

	/**
	 * Ease of use Input constant
	 */
	public static final Input KEY_F6 = new Input(F6);

	static final int F7 = 11;

	/**
	 * Ease of use Input constant
	 */
	public static final Input KEY_F7 = new Input(F7);

	static final int F8 = 12;

	/**
	 * Ease of use Input constant
	 */
	public static final Input KEY_F8 = new Input(F8);

	static final int F9 = 13;

	/**
	 * Ease of use Input constant
	 */
	public static final Input KEY_F9 = new Input(F9);

	static final int F10 = 14;

	/**
	 * Ease of use Input constant
	 */
	public static final Input KEY_F10 = new Input(F10);

	static final int F11 = 15;

	/**
	 * Ease of use Input constant
	 */
	public static final Input KEY_F11 = new Input(F11);

	static final int F12 = 16;

	/**
	 * Ease of use Input constant
	 */
	public static final Input KEY_F12 = new Input(F12);

	static final int CHAR = 17;

	static final int BUTTON1 = 18;

	/**
	 * Ease of use Input constant
	 */
	public static final Input.Mouse MOUSE_BUTTON1 = new Input.Mouse(BUTTON1);

	static final int BUTTON2 = 19;

	/**
	 * Ease of use Input constant
	 */
	public static final Mouse MOUSE_BUTTON2 = new Mouse(BUTTON2);

	static final int BUTTON3 = 20;

	/**
	 * Ease of use Input constant
	 */
	public static final Mouse MOUSE_BUTTON3 = new Mouse(BUTTON3);

	public static final int NINPUT = 21;

	public static Char getChar(char c) {
		return new Char(c);
	}

	public static Input getKey(int key) {
		return new Input(key);
	}

	/**
	 * the input type: 0<= type < NINPUT
	 */
	protected int type;

	Input(int type) {
		this.type = type;
		if (type < 0 || type >= NINPUT) {
			throw new MCMRuntimeException("" + type
					+ " is not a valid input type");
		}
	}

	/** 
	 * equal if both Input, same type, and in case of CHAR-type, same character
	 */
	public boolean equals(Object p) {
		if (p == null)
			return false;
		if (!getClass().equals(p.getClass()))
			return false;
		Input in = (Input) p;
		if (in.type != this.type)
			return false;
		if (this instanceof Char) {
			return ((Char) this).equals((Char) p);
		}
		return true;
	}

	/**
	 * Returns a string representation of this object
	 */
	public String toString() {
		String str = getKeyText(type);
		return str;
	}

	/**
	 * Character Input 
	 */
	public static class Char extends Input {
		private char theChar;

		public Char(char c) {
			super(CHAR);
			theChar = c;
		}

		public boolean equals(Char c) {
			return (c != null) && (c.theChar == theChar);
		}

		/**
		 * Returns a string representation of this object
		 */
		public String toString() {
			String str = getKeyText(type) + "(" + theChar + ")";
			return str;
		}
	}

	/**
	 * Button input objects track input through button clicks. 
	 * Their key indicates which button was or is pressed.
	 * They contain a point. It is set to the last position at which the mouse button was pressed or to which the mouse 
	 * was dragged while the button was held down. 
	 */
	public static class Mouse extends Input {
		private Point pos;

		public Mouse(int key) {
			super(key);
			if (key != BUTTON1 && key != BUTTON2 && key != BUTTON3) {
				throw new MCMRuntimeException("" + key
						+ " is not a button type");
			}
			pos = null;
		}

		public Point getPos() {
			return pos;
		}

	}

	static String getKeyText(int key) {
		switch (key) {
		case UP:
			return "UP";
		case DOWN:
			return "DOWN";
		case LEFT:
			return "LEFT";
		case RIGHT:
			return "RIGHT";

		case ENTER:
			return "ENTER";

		case F1:
			return "F1";
		case F2:
			return "F2";
		case F3:
			return "F3";
		case F4:
			return "F4";
		case F5:
			return "F5";
		case F6:
			return "F6";
		case F7:
			return "F7";
		case F8:
			return "F8";
		case F9:
			return "F9";
		case F10:
			return "F10";
		case F11:
			return "F11";
		case F12:
			return "F12";

		case CHAR:
			return "CHAR";

		case BUTTON1:
			return "BUTTON1";
		case BUTTON2:
			return "BUTTON2";
		case BUTTON3:
			return "BUTTON3";

		default:
			return "UNKNOWN";
		}
	}

	public static class Listener implements KeyListener, MouseListener,
			MouseMotionListener {
		Vector pressed;

		Vector isDown;

		Point mousePos;

		boolean inside;

		Component component;

		int height;

		Trace tracer;

		public static int traceLevel = 2;

		Listener(Trace tracer, Component c) {
			component = c;
			height = component.getHeight();
			this.tracer = tracer;
			pressed = new Vector();
			isDown = new Vector();
			component.addKeyListener(this);
			component.addMouseListener(this);
			component.addMouseMotionListener(this);
			mousePos = null;
			inside = false;
		}

		synchronized void deactivate() {
			component.removeKeyListener(this);
			component.removeMouseListener(this);
			component.removeMouseMotionListener(this);
		}

		synchronized void reset() {
			if (pressed.size() > 0) {
				if (tracer.doTraceLevel(traceLevel))
					tracer.traceMsg(this, "reset");
			}
			pressed.clear();
		}

		public synchronized Point getMousePos() {
			return mousePos;
		}

//		synchronized Input getPressed(Input in) {
//			int i = find(pressed, in);
//			if (i != -1) {
//				return (Input) pressed.get(i);
//			}
//			return null;
//		}

		/** 
		 * Returns whether the given Input event occured since last reset. 
		 * @return <code>true</code> if the event occured, <code>false</code> otherwise.
		 */
		public synchronized boolean wasPressed(Input in) {
			int i = find(pressed, in);
			return i != -1;
		}

		public synchronized boolean isDown(Input in) {
			int i = find(isDown, in);
			if (tracer.doTraceLevel(traceLevel))
				tracer.traceMsg(this, "isDown " + in + " " + (i != -1));
			return i != -1;
		}

		public synchronized void keyPressed(KeyEvent evt) {
			press(getInput(evt));
		}

		public synchronized void keyReleased(KeyEvent evt) {
			release(getInput(evt));
		}

		public void keyTyped(KeyEvent arg0) {
		}

		synchronized void press(Input in) {
			if (in == null)
				return;
			int i = find(isDown, in);
			if (i == -1) {
				isDown.add(in);
				pressed.add(in);
				if (tracer.doTraceLevel(traceLevel))
					tracer.traceMsg(this, "press " + in);
			}
		}

		synchronized void release(Input in) {
			if (in == null)
				return;
			int i = find(isDown, in);
			if (i != -1) {
				isDown.set(i, null);
			}
			if (tracer.doTraceLevel(traceLevel))
				tracer.traceMsg(this, "release " + in);
		}

		synchronized int find(Vector vec, Input in) {
			if (in == null)
				return -1;
			for (int i = 0; i < vec.size(); i++) {
				Input p = (Input) vec.get(i);
				if (p != null && p.equals(in)) {
					return i;
				}
			}
			return -1;
		}

		public synchronized String toString() {
			String str = Utils.shortClassName(this);
			if (isDown.size() > 0) {
				str += " down:";
				for (int i = 0; i < isDown.size(); i++) {
					Input p = (Input) isDown.get(i);
					if (p != null) {
						str += p.toString();
					}
				}
			}
			if (pressed.size() > 0) {
				str += " pressed:";
				for (int i = 0; i < pressed.size(); i++) {
					Input p = (Input) pressed.get(i);
					if (p != null) {
						str += p.toString();
					}
				}
			}
			return str;
		}

		static Input getInput(KeyEvent evt) {
			int key = convertKey(evt.getKeyCode());
			if (key != -1) {
				return Input.getKey(key);
			}
			if (evt.getKeyChar() != KeyEvent.CHAR_UNDEFINED) {
				return Input.getChar(evt.getKeyChar());
			}
			return null;
		}

		static Mouse getInput(MouseEvent evt, double height) {
			int key;
			switch (evt.getButton()) {
			case MouseEvent.BUTTON1:
				key = BUTTON1;
				break;
			case MouseEvent.BUTTON2:
				key = BUTTON2;
				break;
			case MouseEvent.BUTTON3:
				key = BUTTON3;
				break;
			default:
				key = -1;
			}

			if (key != -1) {
				Mouse m = new Mouse(key);
				m.pos = new Point();
				m.pos.setLocation(evt.getPoint().x, height - evt.getPoint().y);
				return m;
			}
			return null;
		}

		static int convertKey(int key) {
			switch (key) {
			case KeyEvent.VK_UP:
				return UP;
			case KeyEvent.VK_DOWN:
				return DOWN;
			case KeyEvent.VK_LEFT:
				return LEFT;
			case KeyEvent.VK_RIGHT:
				return RIGHT;
			case KeyEvent.VK_ENTER:
				return ENTER;
			case KeyEvent.VK_F1:
				return F1;
			case KeyEvent.VK_F2:
				return F2;
			case KeyEvent.VK_F3:
				return F3;
			case KeyEvent.VK_F4:
				return F4;
			case KeyEvent.VK_F5:
				return F5;
			case KeyEvent.VK_F6:
				return F6;
			case KeyEvent.VK_F7:
				return F7;
			case KeyEvent.VK_F8:
				return F8;
			case KeyEvent.VK_F9:
				return F9;
			case KeyEvent.VK_F10:
				return F10;
			case KeyEvent.VK_F11:
				return F11;
			case KeyEvent.VK_F12:
				return F12;
			}
			return -1;
		}

		private void mouseSetPos(MouseEvent evt) {
			if (mousePos == null)
				mousePos = new Point();
			mousePos.setLocation(evt.getPoint().x, height - evt.getPoint().y);
		}

		public void mouseClicked(MouseEvent arg0) {
		}

		public void mouseEntered(MouseEvent evt) {
			inside = true;
		}

		public void mouseExited(MouseEvent arg0) {
			inside = false;
		}

		public void mousePressed(MouseEvent evt) {
			press(getInput(evt, height));
			mouseSetPos(evt);
		}

		public void mouseReleased(MouseEvent evt) {
			release(getInput(evt, height));
			mouseSetPos(evt);
		}

		public void mouseDragged(MouseEvent evt) {
			mouseSetPos(evt);
		}

		public void mouseMoved(MouseEvent evt) {
			//mouseSetPos(evt);
		}
	}

}

