
package mcm.game;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JApplet;
import javax.swing.JFrame;
import javax.swing.WindowConstants;

import mcm.graphics.*;
import mcm.utils.*;

/**
 * A Game may be executed as an Applet or as a Application. 
 * 
 * It drives a game by creating an initial board and executing the 
 * game loop in its own thread. The game loop continuously calls
 * the current boards update and display methods, swapping boards 
 * when necessary. 
 * 
 * @author Monika Mevenkamp
 */
public class Game extends JApplet implements Runnable, ComponentListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7210258831931906422L;

	/** 
	 * indicates whether Game is run as applet or application 
	 */
	private JFrame frameContainer; 
	
	/** 
	 * Applet's parameter. 
	 * Appelts use it to determine the fully qualified name 
	 * of the initial Board that should be instantiated to start 
	 * this game.  
	 */
	public static final String BOARD = "BOARD";
	
	/** 
	 * Appelts may be started and stopped. 
	 * instId numbers consecutive animation threads started in 
	 * the applet's start method. 
	 */
	private static int instId = 0;

	/**
	 * Game methods use this for tracing purposes.
	 */
	protected Trace tracer;

	/** 
	 * The default traceLevel is 1.
	 */
	public static int traceLevel = 1;

	/** 
	 * The delay in milliseconds between consecutive updateBoard/displayBoard calls 
	 * in the main game loop.
	 */
	protected int frameDelay;

	/** 
	 * The currently active game board.
	 */
	private Board board;

	/*
	 * Whether game is driven by starting thread 
	 */
	private boolean interactive; 
	
	/*
     * The animation thread that runs the main game loop.
	 */
	private Thread animator;

	/** 
	 * indicates that an animator is currently executing.
	 */
	private boolean animRunning;

	/** 
	 * The same as Game("Game") 
	 */
	public Game() {
		this("Game");
	}

	/**
	 * Constructs a new Game applet with the given name and a null Board. 
	 * The board is initialized later by a call to initBoard. 
	 * 
	 * Assigns  {@link Trace#global} to its tracer field. 
	 */
	public Game(String name) {
		if (name == null)
			name = Utils.shortClassName(getClass());
		synchronized (Game.class) {
			this.setName(name + "#" + instId);
			instId++;
		}
		tracer = Trace.global;
		board = null;
		addComponentListener(this);
		animRunning = false; // no animation thread is running 
		animator = null; // reference to animation thread 		
		frameContainer = null; 
		interactive = false;
		ImageShape.theApplet = this;
	}

	/**
	 * Called by the browser/applet viewer or main method  to inform this applet 
	 * that it has been loaded into the system. This method should contain one time
	 * inittialization code. 
	 * 
	 * @see java.applet.Applet#init()
	 */
	public void init() {
		tracer.traceMsg(this, "* init: applet codebase=");
		init(true); 
	}
	
	/**
	 * init is used by frame version as well 
	 *
	 */
	private synchronized void init(boolean isApplet) {
		tracer.traceMsg(this, "init");
		frameDelay = 30;
		ImageShape.TheClassLoader = this.getClass().getClassLoader();
		board = null;
		tracer.traceMsg(this, "* init: TheClassLoader " +  ImageShape.TheClassLoader);
	}

	/**
	 * Called by the browser/applet viewer or main method 
	 * to inform this applet that it should start its execution.
	 * It starts the main game loop in its own thread.
	 * 
	 * start calls getInitBoard to set the game's initial board if it is null. 
	 * Deriving classes can either make sure to call setBoard before start executes 
	 * or they can overwrite getInitBoard to supply the initial game board. 
	 * Beware that some Security Managers refuse to open files in the folder 
	 * tree of a derived Applet/Game if getInitBoard is called from Game's start 
	 * method. 
	 * 
	 * @see java.applet.Applet#start()  
	 */
	public synchronized void start() {
		if (board == null) {
			board = getInitBoard(); 
		}
		if (board == null) {
			throw new RuntimeException(this.toString() + " has a null game board");
		}
		board.resize();
		if (animator == null) {
			tracer.traceMsg(this, "> start " + board);
		
			// the applet may have been stopped 
			// but the animator Thread may not have have finished yet 
			while (animRunning) {
				try {
					Thread.sleep(3);
				} catch (InterruptedException e) {
					// try again
				}
			}
			// now that the old animator is done start a new animator 
			synchronized (Game.class) {
				if (interactive) { 
					animator =  Thread.currentThread();
				} else {
				    animator = new Thread(this, "ANIMATOR#." + getName());
				}
				if (board == null) {
					board = new EmptyBoard(this, "Must supply a game.Board"); 
				}
			    board.start(); 
				board.activateInput();
				if (!interactive) {
					animator.start();
				}
			}

			animRunning = true;
			tracer.traceMsg(this, "< start " + board);
		}
	}

	/**
	 * Called by the browser/applet viewer to inform this applet that it should 
	 * stop its execution. 
	 * The thread running the main game loop is forced to exit and the current 
	 * board's stop method is called. 
	 * 
	 * @see java.applet.Applet#stop()  
	 */
	public synchronized void stop() {
		tracer.println();
		tracer.traceMsg(this, "> stop " + board);
		animator = null; // indicate to animator that it needs to finish 
		tracer.traceMsg(this, "< stop " + board);
	}

	/**
	 * Invoked when the component has been made visible. 
	 * This Game starts execution.
	 */
	public void componentShown(ComponentEvent e) {
		this.start();
	}

	/**
	 * Invoked when the component has been made invisible.
	 * This Game stops execution.
	 */
	public void componentHidden(ComponentEvent e) {
		this.stop();
	}

	/**
	 * Invoked when the component's position changes.
	 * No action is taken.
	 * 
	 * @see java.awt.event.ComponentListener#componentMoved(java.awt.event.ComponentEvent)
	 */
	public void componentMoved(ComponentEvent e) {
	}

	/**
	 * Invoked when the component has been made visible.
	 * No action is taken.
	 *  
	 * @see java.awt.event.ComponentListener#componentResized(java.awt.event.ComponentEvent)
	 */
	public void componentResized(ComponentEvent e) {
	}

	/** 
	 * The run method supplies the game's main loop. 
	 * It is executed in its own Thread. 
	 * The loop is structured as follows: 
	 * <blockquote>
	 * <pre>
	 * while (true) {
	 *    updateBoard(); 
	 *    board.resetInput();
	 *    displayBoard(); 
	 *    suspend for a bit
	 * }
	 * </pre>
	 * </blockquote>
	 * The game loop suspends its execution so that each update/display cycle takes 
	 * (at least) frameDelay millisecond.  
	 */
	public void run() {
		tracer.traceMsg(Thread.currentThread().getName(), ">> run/animate " + getName());
		try {
			while (Thread.currentThread() == animator) {
				doRound(1); 
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			tracer.printMsg(this, "> stop " + board); 
			board.stop();
			tracer.printMsg(this, "< stop " + board); 
			System.gc();
			animRunning = false; // indicate to applet that animator is done
		}
		tracer.println();
		tracer.traceMsg(Thread.currentThread().getName(), "<< run/animate " + getName());
	}

	public void doRound(int n) {
		for (int i = 0; i < n; i++) {
			long stepStart = System.currentTimeMillis();
			if (board != null) {
				Graphics g = getGraphics();
				if (g != null) {
					updateBoard();
					board.resetInput();
					displayBoard();
					paint(g);
				}
			}
			long delta = System.currentTimeMillis() - stepStart;
			if (delta < frameDelay) {
				try {
					Thread.sleep(frameDelay - delta);
				} catch (InterruptedException e) {
					// never mind
				}
			}
		}
	}
	
	/**
	 * Calls current board's display method.
	 */
	public void displayBoard() {
		board.display(board.getGraphics());
	}

	/**
	 * Calls the current board's update method. 
	 *
	 * The game staops if the current boards update method returns null. 
     * Otherwise it takes the following actions: 
	 * <blockquote> 
	 * <pre> 
	 *     board = current-board.update(); 
	 *     if (board != current-board) {
     *           current-board.stop(); 
     *           current-board = board; 
     *           current-board.start(); 
     *     }
	 *     new-board becomes current-board
	 * </pre>
	 * </blockquote> 
	 */
	public void updateBoard() {
		//dots(); 
		Board b = board.update();
		if (b != board) {
			tracer.traceln();
			tracer.traceMsg(this, "* updateBoard.switch " + board + " to " + b);
			tracer.printMsg(this, "> stop " + board); 
			board.stop();
			tracer.printMsg(this, "< stop " + board); 			board.deactivateInput();
			if (b != null) {
				board = b;
				tracer.printMsg(this, "> start " + board); 
				board.start();
				tracer.printMsg(this, "< start " + board); board.activateInput();
			} else {
				stop();
				if (frameContainer != null) {
					frameContainer.setVisible(false);
					frameContainer.dispose(); 
				}
			}
		}
	}

	/** 
	 * Uses the current boards double buffer to repaint 
	 */
	public void paint(Graphics g) {
		if (getWidth() == 0 || getHeight() == 0)
			return;
		if (board != null) {
			Image doubleBuffer = board.getImage(); // may not renew

			if (null != doubleBuffer) {
				if (tracer.doTraceLevel(traceLevel + 2)) {
					tracer.traceMsg(this, "paint " + board);
				}
				g.drawImage(doubleBuffer, 0, 0, this);
			}
		}
	}

	/**
	 * Assigns the game's board, so it is used as its current board. 
	 * 
	 * This method can set a game's board only once. 
	 * It is typically called from the init() method.
	 * If setBoard is called multiple times it throws a RuntimeException.
	 */
	public void setBoard(Board b) {
		tracer.printMsg(this, "setBoard " + b); 
		if (board == null) {
			board = b;
		} else {
			throw new RuntimeException("Game has a valid board; can't overwrite");
		}
	}
	/** 
	 * getInitBoard is expected to return a 
	 * reference to a Board instance that is used as the game's initial board. 
	 * 
	 * This default implementation returns an empty board with an 
	 * error message.
	 * 
	 */
	public Board getInitBoard() {
		return emptyBoard(); 
	}
	
	private Board emptyBoard() {
		if (board == null) {
			tracer.printMsg(this, "emptyBoard"); 
			board = new EmptyBoard(this, "initBoard method did not supply a valid Board"); 
		}
		return board;
	}		
	

	/**
	 *  Calls {@link Game#paint(Graphics)}.
	 */
	public void update(Graphics g) {
		paint(g);
	}

	/**
	 * Returns information about the parameters that are understood by this applet.
	 * @see java.applet.Applet#getParameterInfo()  
	 */
	public String[][] getParameterInfo() {
		return  new String[][] { { BOARD, "fully qualified class name",
					"class name of this game's game board" }, };
	
	}

	/**
	 * Returns a string representation of this Applet
	 */
	public String toString() {
		return getName();
	}

	/**
	 * @param className
	 * @return
	 */
	private Object newInst(String className) {
		Object o = null;
		try {
			if (className == null)
				throw new NullPointerException();
			ClassLoader c = Game.class.getClassLoader();
			Class cls = c.loadClass(className);
			Class types[] = { Component.class };
			Constructor constr = cls.getConstructor(types);
			Object params[] = { this };
			o = constr.newInstance(params);
		} catch (Exception e) {
			throw new MCMRuntimeException("Could not instantiate " + className,
					e);
		}
		return o;
	}

	/** 
	 * Derived classes use main to start a game as an application. 
	 * The game reference supplied must supply its own implementation of 
	 * initBoard.
	 * 
	 * @param argv  command line arguments 
	 * @param width the frame's width in pixels 
	 * @param height the frame's width in pixels 
	 * @param game a non null game reference 
	 */
	public static void main(String argv[], int width, int height, Game game) {
		final JFrame f = new JFrame();
		try {
		f.setContentPane(game);

		f.setSize(width, height);
		f.setTitle(game.getName());
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
		game.frameContainer = f; 
		f.setVisible(true);
		
		game.init(false);
		game.start();
		} catch (Exception e) {
			System.err.println("Failed with Exception: " + e); 
			e.printStackTrace(System.err); 
			f.setVisible(false); 
			f.dispose();
		}
		
	}

	private int nDots = 0; 
	private void dots() {
		if (tracer.doTraceLevel(traceLevel)) {
			tracer.print("."); 
			nDots++; 
			
			if (nDots == 80) {
				nDots = 0; 
				tracer.println(); 
			}
		}
	}

	public Board getBoard() {
		return board;
	}
	
	public void setInteractive() {
		interactive = true; 
	}
	
//	public InputStream getFileInputStream(String fileName) throws IOException {
//		if (frameContainer == null) { // it's an APPLET 
//			URL url = getClass().getClassLoader().getResource(fileName); 
//			// Trace.global.println("URL=" + url); 
//			// URL url = new URL (getDocumentBase(), fileName ); 
//			Trace.global.println("URL=" + url);
//
//			return url.openStream();
//		} else {
//			return new FileInputStream(fileName);
//		}
////		URL loader = getCodeBase();
////		if (loader != null) {
////			URL imgURL = loader.getResource(fileName); 
////			InputStream in=imgURL.openStream();
////			return in;
////		} else {
////			
////		}
//	}

	public InputStream getFileInputStream(URL codeBase, String fname) throws IOException {
		URL url = new URL(codeBase, fname); 
		Trace.global.println(": getFileInputStream==" + url);
		return url.openStream();
	}
}

class EmptyBoard extends Board {

	Body empty; 
	Body msg; 
	
	EmptyBoard(Component c, String error) 
	{
		super(c); 
		
	    empty = new Body(); 
	    empty.setShape(new TextShape("Must Supply a Game Board", this)); 
	    empty.setHotSpot(Shape.LOWER_CENTER); 
	    empty.jumpTo(getCenter()); 
	    
	    msg = new Body(); 
	    msg.setShape(new TextShape(error, this));
	    msg.setHotSpot(Shape.UPPER_CENTER); 
	    msg.jumpTo(getCenter()); 
	    
	}


	public void display(Graphics2D db) {
		empty.draw(db); 
		msg.draw(db); 
		
	}

	public Board update() {
		return this;
	}
	
}