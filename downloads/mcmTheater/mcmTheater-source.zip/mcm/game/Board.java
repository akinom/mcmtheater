
package mcm.game;

import java.awt.Component;
import java.awt.Graphics2D;

import mcm.graphics.Drawable;
import mcm.graphics.Point;
import mcm.utils.Utils;
import mcm.utils.Trace;

/**
 * Board objects update and display a game's state.
 * 
 * Games are driven by the game's main loop, {@link  mcm.game.Game}, which 
 * alternates between calling its current board's update and display methods. 
 * It expects the board's update method to take care of updating the game state 
 * and its display method to paint a represntation of its current state to the 
 * given graphics context.  
 * 
 * A game's main loop switches between boards whenever a board's update method returns 
 * a pointer to another board. The game loop calls the old board's stop method 
 * and the new board's start method, {@link Game}. 
 * 
 * @author Monika Mevenkamp
 */
public abstract class Board extends Drawable  {
	/** 
	 * Keeps track of inputs
	 */
	private Input.Listener inputs; 
	
	/** 
	 *  Board methods may use this for tracing purposes.
	 */
	protected Trace tracer; 
	
	/** 
	 * Creates a new Board associated with  the given Component.
	 * @param c the Component that this board uses for its display 
	 */
	public Board(Component c) {
		super(c);
		inputs = null; 
		tracer = Trace.global;
		c.requestFocus();
	}	
	
	public void resetInput() {
		if (inputs != null) inputs.reset(); 
	}
	
	/** 
	 * Paints this board. 
	 * Display is called from the main game loop.
	 *  
	 * @param db the graphics context to use for painting
	 */
	public abstract void display(Graphics2D db);

	/** 
	 * Updates this board. 
	 * Update is called from the main game loop.
	 */
	public abstract Board update();
	
	/** 
	 * Starts this board. 
	 * Start is called before a board is updates for the first time or 
	 * before it is updated for the first time after the main game loop switches back to processing 
	 * this board. 
	 */
	public void start() {}
	
	/** 
	 * Stops this board. 
	 * Stop is called whenever the main game loop switches from this board to 
	 * another board. 
	 */
	public void stop() {}
	
	public void activateInput() {
		if (inputs == null) {
			tracer.traceMsg(this, "activateInput"); 
			inputs = new Input.Listener(tracer, this.getComponent());
		}
	}

	public void deactivateInput() {
		if (inputs != null) {
			tracer.traceMsg(this, "deactivateInput"); 
			inputs.deactivate(); 
			inputs = null;
		}
	}
	
	public boolean wasPressed(Input in) {
		if (inputs != null) {
			return inputs.wasPressed(in); 
		}
		return false; 
	}
	
//	public Input getPressed(Input in) {
//		if (inputs != null) {
//			return inputs.getPressed(in); 
//		}
//		return null; 
//	}
	
	public boolean isDown(Input in) {
		if (inputs != null) {
			return inputs.isDown(in); 
		}
		return false; 
	}
	
	public Point getMousePos() 
	{
		if (inputs != null) 
			return inputs.getMousePos();
		return null;
	}
	
	/**
	 * Returns a string representation of this board.
	 */
	public String toString() {
		return Utils.shortClassName(this); 
	}
	
}
