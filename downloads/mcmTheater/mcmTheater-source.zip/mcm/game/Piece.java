/*
 * Created on Jan 17, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package mcm.game;

import mcm.graphics.Body;
import mcm.utils.Utils;

/**
 *  Pieces are 'move'd on a game's Board. 
 */
public class Piece extends Body  {
	
	protected Board board; 
	protected int id; 
	protected static int idCounter = 0; 
	
	public Piece(Board b) 
	{
		board = b; 
		jumpTo(board.getCenter());
		id = idCounter++;
		setName(Utils.shortClassName(this) + "#" + id);
	}
	
	
	public Board getBoard() 
	{
		return board; 
	}
	
	public void setBoard(Board b) 
	{
		board = b; 
	}
	
	/** 
	 * A piece's update method is typically called by a Board's 
     * update method.  
     *
     * @see Board#update()
	 */
	public Piece update() {
		return this;
	}
	
	public Piece containsPiece(PieceList list)  
	{
		Piece c = null;
		if (list == null || list.size() == 0) return null;
		for (int i = 0; i < list.size(); i++) {
			c = list.getPiece(i);
			if (this.contains(c.getPosX(), c.getPosY())) {  
				return c;
			}
		}
		return null; 
	}
}