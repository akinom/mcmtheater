package mcm.game;

public interface GameInit {

}
