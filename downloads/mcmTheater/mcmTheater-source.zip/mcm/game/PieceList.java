
package mcm.game;

import java.awt.Graphics2D;
import java.io.PrintStream;
import java.util.*;


/** 
 * Wraps a Vector of Pieces
 */
public class PieceList extends Vector {
	
	private static final long serialVersionUID = 1L;

	public PieceList(int initialSize) {
		super(initialSize);
	}
	
	public PieceList() {
		this(20);
	}
	
	public Piece getPiece(int i) {
	   	return (Piece) this.get(i);	   	
	 }
	 	 	 
	 public Enumeration getEnum() 
	 {
	 	return new Enumeration(this.elements());
	 }
	 
	//@SuppressWarnings("unchecked")
	public boolean add(Piece p) {
		return super.add((Object) p);
	 }
	 
	 public void draw(Graphics2D g) 
	 {
		for (int i = 0; i < size(); i++) {
			if (get(i) != null)
				getPiece(i).draw(g);
		}
	}
	 
	//@SuppressWarnings("unchecked")
	public void update() 
	 {
		for (int i = 0; i < size(); i++) {
			if (get(i) != null) {
				Piece p = getPiece(i).update(); 	
				set(i, (Object) p); 
			}
		}
	}
	 
	 public void print(PrintStream s, String headline) 
	 {	 	
	 	s.println(headline); 
	 	for (int i = 0; i < size(); i++) {
	 		s.print(", " + i + " -> " + get(i)); 
	 	}
	 	s.println();
	 }
	 
	 public class Enumeration {
		 
	 	java.util.Enumeration enumerate; 
	 	
	 	public Enumeration(java.util.Enumeration enumerate) {
	 		this.enumerate = enumerate;
	 	}
	 	
	 	public boolean hasMoreElements() {
	 		return enumerate.hasMoreElements();
	 	}
       
	 	public Piece 	nextElement() {
	 		return (Piece) enumerate.nextElement();
	 	}
	 	
	 }

}
